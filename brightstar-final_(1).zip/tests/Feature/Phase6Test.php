<?php

namespace Tests\Feature;

use App\Mail\NewsletterMail;
use App\Models\NewsletterSubscriber;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class Phase6Test extends TestCase
{
    use RefreshDatabase;

    public function test_campaign_skips_unsubscribed_and_includes_token(): void
    {
        Mail::fake();
        NewsletterSubscriber::create(['email' => 'a@x.test']);
        NewsletterSubscriber::create(['email' => 'b@x.test']);
        NewsletterSubscriber::create(['email' => 'gone@x.test', 'unsubscribed_at' => now()]);

        $m = new User(['name' => 'm', 'email' => 'm@x.test', 'password' => 'secret-pass']);
        $m->forceFill(['role' => 'manager', 'email_verified_at' => now()])->save();
        $this->actingAs($m)->post('/admin/newsletter/send', ['subject' => 'Sale', 'body' => 'Hello'])->assertSessionHas('status');

        Mail::assertQueued(NewsletterMail::class, 2);
        Mail::assertNotQueued(NewsletterMail::class, fn ($mail) => $mail->hasTo('gone@x.test'));
    }

    public function test_unsubscribe_link_works_and_resubscribe_clears_it(): void
    {
        $s = NewsletterSubscriber::create(['email' => 'a@x.test']);
        $this->get('/newsletter/unsubscribe/'.$s->token)->assertRedirect('/');
        $this->assertNotNull($s->fresh()->unsubscribed_at);

        $this->post('/newsletter', ['email' => 'a@x.test']);
        $this->assertNull($s->fresh()->unsubscribed_at);
    }

    public function test_invalid_unsubscribe_token_is_harmless(): void
    {
        $this->get('/newsletter/unsubscribe/nope')->assertRedirect('/');
    }

    public function test_customer_cannot_open_newsletter_admin(): void
    {
        $c = new User(['name' => 'c', 'email' => 'c@x.test', 'password' => 'secret-pass']);
        $c->forceFill(['role' => 'customer', 'email_verified_at' => now()])->save();
        $this->actingAs($c)->get('/admin/newsletter')->assertForbidden();
    }
}
