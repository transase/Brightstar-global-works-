<?php

namespace Tests\Feature;

use App\Models\CartItem;
use App\Models\Category;
use App\Models\Collection;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Setting;
use App\Services\CartService;
use App\Services\Search\ProductSearch;
use App\Services\WhatsAppService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\URL;
use Tests\TestCase;

class SpecCoverageTest extends TestCase
{
    use RefreshDatabase;

    private function product(array $over = []): Product
    {
        return Product::create(array_merge(['name' => 'Chair '.uniqid(), 'sku' => 'S'.uniqid(), 'price' => 100000, 'stock_quantity' => 9, 'status' => 'published'], $over));
    }

    private function order(array $over = []): Order
    {
        return Order::create(array_merge(['number' => 'BGF-SC-'.rand(1000, 9999), 'first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '08000000000',
            'shipping_address' => ['address' => 'x'], 'subtotal' => 100000, 'total' => 100000, 'payment_method' => 'whatsapp'], $over));
    }

    public function test_default_navigation_has_every_item_from_the_brief(): void
    {
        $html = $this->get('/')->assertOk()->getContent();
        foreach (['Home', 'Shop Furniture', 'Living Room', 'Bedroom', 'Dining Room', 'Office Furniture', 'Outdoor Furniture', 'Collections', 'New Arrivals', 'Best Sellers', 'Offers', 'About Us', 'Contact Us'] as $label) {
            $this->assertStringContainsString($label, $html, "Missing nav item: $label");
        }
    }

    public function test_collections_list_only_active_and_filter_the_shop(): void
    {
        $in = $this->product(['name' => 'Scandi Sofa']);
        $out = $this->product(['name' => 'Other Sofa']);
        $c = Collection::create(['name' => 'Scandinavian', 'slug' => 'scandi', 'is_active' => true]);
        $c->products()->attach($in->id);
        Collection::create(['name' => 'Hidden', 'slug' => 'hidden', 'is_active' => false]);

        $this->get('/collections')->assertOk()->assertSee('Scandinavian')->assertDontSee('Hidden');
        $this->get('/collections/scandi')->assertOk()->assertSee('Scandi Sofa')->assertDontSee('Other Sofa');
        $this->get('/collections/hidden')->assertNotFound();
        $this->get('/shop?collection=scandi')->assertOk()->assertSee('Scandi Sofa')->assertDontSee('Other Sofa');
    }

    public function test_quick_view_serves_published_products_only(): void
    {
        $p = $this->product(['name' => 'Quick Table']);
        $d = $this->product(['status' => 'draft']);
        $this->get(route('product.quick', $p))->assertOk()->assertSee('Quick Table');
        $this->get(route('product.quick', $d))->assertNotFound();
    }

    public function test_product_card_offers_add_to_cart_whatsapp_and_quick_view(): void
    {
        Setting::put('whatsapp_phone', '+2348012345678');
        $this->product(['name' => 'Card Chair', 'is_featured' => true]);
        $this->get('/')->assertSee('Add to cart')->assertSee('Order on WhatsApp')->assertSee('Quick view');
    }

    public function test_shop_shows_active_filter_chips_list_view_and_suggestions(): void
    {
        $this->product(['name' => 'Oak Table', 'material' => 'Oak']);
        $this->get('/shop?material=Oak&view=list')->assertOk()->assertSee('Active filters')->assertSee('Material: Oak')->assertSee('Oak Table');
        $this->get('/shop?q=zzzz-nothing')->assertOk()->assertSee('No furniture matches');
    }

    public function test_search_treats_percent_and_underscore_literally(): void
    {
        $this->product(['name' => 'Sofa 50% off']);
        $this->product(['name' => 'Sofa regular']);
        $names = fn (string $t) => app(ProductSearch::class)->apply(Product::query(), $t)->pluck('name')->all();
        $this->assertSame(['Sofa 50% off'], $names('50%'));
        $this->assertCount(2, $names('Sofa'));
        $this->assertSame([], $names('_ofa'));
    }

    public function test_cart_can_switch_variation_and_merges_duplicate_lines(): void
    {
        $p = $this->product();
        $a = ProductVariant::create(['product_id' => $p->id, 'colour' => 'Grey', 'stock_quantity' => 5]);
        $b = ProductVariant::create(['product_id' => $p->id, 'colour' => 'Navy', 'stock_quantity' => 5]);
        $this->post(route('cart.add', $p), ['variant_id' => $a->id, 'quantity' => 1]);
        $this->post(route('cart.add', $p), ['variant_id' => $b->id, 'quantity' => 1]);
        $item = CartItem::where('variant_id', $a->id)->first();

        $this->patch(route('cart.update', $item->id), ['variant_id' => $b->id])->assertRedirect();

        $this->assertSame(1, CartItem::count());
        $this->assertSame(2, CartItem::first()->quantity);
        $this->assertSame($b->id, CartItem::first()->variant_id);
    }

    public function test_billing_address_is_required_only_when_different_and_is_saved(): void
    {
        Setting::put('whatsapp_phone', '+2348012345678');
        $p = $this->product();
        $this->post(route('cart.add', $p), ['quantity' => 1]);
        $base = ['first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '08000000000', 'address' => '1 Road', 'city' => 'Lagos', 'state' => 'Lagos', 'country' => 'Nigeria', 'payment_method' => 'whatsapp'];

        $this->post(route('checkout.store'), $base + ['billing_same' => 0])->assertSessionHasErrors('billing.address');
        $this->post(route('checkout.store'), $base + ['billing_same' => 0, 'billing' => ['address' => '9 Billing St', 'city' => 'Abuja', 'state' => 'FCT', 'country' => 'Nigeria']])->assertRedirect();
        $this->assertSame('9 Billing St', Order::latest('id')->first()->billing_address['address']);
    }

    public function test_unpaid_order_can_be_paid_online_later_and_signed_link_grants_access(): void
    {
        config(['services.paystack.secret' => 'sk_test_x']);
        Http::fake(['api.paystack.co/*' => Http::response(['status' => true, 'data' => ['authorization_url' => 'https://pay.test/checkout']])]);
        $o = $this->order(['payment_status' => 'unpaid']);

        $this->post(route('order.pay', [$o->number, 'paystack']))->assertNotFound();               // no access without session/link
        $signed = URL::temporarySignedRoute('order.show', now()->addDay(), ['number' => $o->number]);
        $this->get($signed)->assertOk()->assertSee('Pay online');                                  // staff-sent link works
        $this->post(route('order.pay', [$o->number, 'paystack']))->assertRedirect('https://pay.test/checkout');
        $this->assertSame('pending', $o->fresh()->payment_status);
    }

    public function test_paid_or_cancelled_orders_cannot_start_another_payment(): void
    {
        config(['services.paystack.secret' => 'sk_test_x']);
        Http::fake();
        foreach ([['payment_status' => 'paid'], ['fulfilment_status' => 'cancelled']] as $state) {
            $o = $this->order($state);
            $this->withSession(['order_access.'.$o->number => true])->post(route('order.pay', [$o->number, 'paystack']))->assertStatus(409);
        }
    }

    public function test_bank_transfer_details_are_shown_to_the_customer(): void
    {
        Setting::put('bank_transfer_details', 'Bank X, Acct 0123456789');
        $o = $this->order(['payment_method' => 'bank_transfer']);
        $this->withSession(['order_access.'.$o->number => true])->get(route('order.show', $o->number))->assertOk()->assertSee('Acct 0123456789')->assertSee($o->number);
    }

    public function test_whatsapp_cart_template_and_greeting_settings_are_used(): void
    {
        Setting::put('wa_greeting', 'Salam, Brightstar team!');
        $wa = app(WhatsAppService::class);
        $totals = ['lines' => [['name' => 'Sofa', 'variant_label' => 'Grey', 'quantity' => 2, 'line_total' => 200000]], 'subtotal' => 200000, 'discount' => 0, 'delivery_fee' => 0, 'tax' => 0, 'total' => 200000];

        $this->assertStringStartsWith('Salam, Brightstar team!', $wa->cartMessage($totals, 'https://x.test/cart'));

        Setting::put('wa_cart_template', "ORDER:\n{items}\nPAY {total}\n{url}");
        $msg = $wa->cartMessage($totals, 'https://x.test/cart');
        $this->assertStringContainsString('Sofa (Grey) x2', $msg);
        $this->assertStringContainsString('PAY ₦2,000.00', $msg);
        $this->assertStringNotContainsString('Salam', $msg); // custom template replaces the default layout
    }

    public function test_specs_are_parsed_saved_and_shown_on_the_product_page(): void
    {
        $this->assertSame(['Seats' => '3', 'Frame' => 'Solid wood: kiln dried'], Product::parseSpecs("Seats: 3\nnonsense line\nFrame: Solid wood: kiln dried"));
        $p = $this->product(['name' => 'Spec Sofa', 'specs' => ['Seats' => '3'], 'brand' => 'Acme']);
        $this->get(route('product.show', $p))->assertOk()->assertSee('Seats')->assertSee('Acme');
    }

    public function test_homepage_shows_featured_categories_benefits_and_testimonials_only_when_configured(): void
    {
        $this->get('/')->assertDontSee('Why shop with us?')->assertDontSee('Customer reviews');

        Category::create(['name' => 'Sofas', 'slug' => 'sofas', 'is_featured' => true]);
        \App\Models\Benefit::create(['title' => 'Secure payment options']);
        $p = $this->product();
        \App\Models\Review::create(['product_id' => $p->id, 'author_name' => 'Ada', 'rating' => 5, 'body' => 'Lovely sofa', 'status' => 'approved']);
        \App\Models\Review::create(['product_id' => $p->id, 'author_name' => 'Pending Person', 'rating' => 5, 'body' => 'Not approved', 'status' => 'pending']);

        $this->get('/')->assertSee('Sofas')->assertSee('Why shop with us?')->assertSee('Secure payment options')->assertSee('Lovely sofa')->assertDontSee('Not approved');
    }

    public function test_category_move_swaps_sort_order(): void
    {
        $u = new \App\Models\User(['name' => 'm', 'email' => 'm@x.test', 'password' => 'secret-pass-123']);
        $u->forceFill(['role' => 'manager', 'email_verified_at' => now()])->save();
        $a = Category::create(['name' => 'A', 'slug' => 'a', 'sort_order' => 0]);
        $b = Category::create(['name' => 'B', 'slug' => 'b', 'sort_order' => 1]);
        $this->actingAs($u)->post(route('admin.categories.move', $b), ['dir' => 'up']);
        $this->assertTrue($b->fresh()->sort_order < $a->fresh()->sort_order);
    }

    public function test_media_urls_follow_the_configured_disk(): void
    {
        config(['store.media_disk' => 'uploads']);
        $this->assertStringContainsString('/uploads/products/x.webp', \App\Support\Media::url('products/x.webp'));
        config(['store.media_disk' => 'public']);
        $this->assertStringContainsString('/storage/products/x.webp', \App\Support\Media::url('products/x.webp'));
    }
}
