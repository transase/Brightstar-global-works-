<?php

namespace Tests\Feature;

use App\Http\Controllers\InstallController;
use Tests\TestCase;

class InstallerTest extends TestCase
{
    private string $lock;
    private string $code;

    protected function setUp(): void
    {
        parent::setUp();
        $this->lock = storage_path('app/installed.lock');
        $this->code = storage_path('app/INSTALL-CODE.txt');
        @unlink($this->lock);
        @unlink($this->code);
    }

    protected function tearDown(): void
    {
        @unlink($this->lock);
        @unlink($this->code);
        parent::tearDown();
    }

    public function test_wizard_is_shown_with_requirement_checks_before_install(): void
    {
        $this->get('/install')->assertOk()->assertSee('Server check')->assertSee('PHP 8.2 or newer');
    }

    public function test_installer_returns_404_once_locked(): void
    {
        file_put_contents($this->lock, 'x');
        $this->get('/install')->assertNotFound();
        $this->post('/install', [])->assertNotFound();
    }

    public function test_wrong_install_code_is_rejected_before_touching_the_database(): void
    {
        file_put_contents($this->code, 'right-code-123');
        $this->post('/install', $this->payload(['install_code' => 'wrong']))->assertSessionHas('error');
        $this->assertFileDoesNotExist($this->lock);
    }

    public function test_unreachable_database_gives_a_friendly_error_and_no_lock(): void
    {
        $this->post('/install', $this->payload(['db_host' => '127.0.0.1', 'db_port' => 1]))->assertSessionHas('error');
        $this->assertFileDoesNotExist($this->lock);
    }

    public function test_weak_admin_password_is_rejected(): void
    {
        $this->post('/install', $this->payload(['admin_password' => 'short', 'admin_password_confirmation' => 'short']))->assertSessionHasErrors('admin_password');
    }

    public function test_env_writer_updates_adds_and_quotes_values(): void
    {
        $env = base_path('.env');
        $backup = file_exists($env) ? file_get_contents($env) : null;
        file_put_contents($env, "APP_NAME=Old\nDB_PASSWORD=\n");
        try {
            InstallController::writeEnv(['APP_NAME' => 'My Shop', 'DB_PASSWORD' => 'p@ss w"rd$1', 'NEW_KEY' => 'x']);
            $out = file_get_contents($env);
            $this->assertStringContainsString('APP_NAME="My Shop"', $out);
            $this->assertStringContainsString('DB_PASSWORD="p@ss w\"rd\$1"', $out);
            $this->assertStringContainsString("NEW_KEY=x", $out);
            $this->assertMatchesRegularExpression('/^APP_KEY=base64:/m', $out); // generated when missing
        } finally {
            $backup === null ? @unlink($env) : file_put_contents($env, $backup);
        }
    }

    private function payload(array $over = []): array
    {
        return array_merge([
            'app_url' => 'https://shop.test', 'db_host' => '127.0.0.1', 'db_port' => 3306, 'db_name' => 'x', 'db_user' => 'x', 'db_pass' => 'x',
            'store_name' => 'Shop', 'admin_name' => 'Owner', 'admin_email' => 'o@x.test',
            'admin_password' => 'a-long-password-1', 'admin_password_confirmation' => 'a-long-password-1',
        ], $over);
    }
}
