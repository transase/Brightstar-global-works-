<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class Phase8Test extends TestCase
{
    use RefreshDatabase;

    private function pending(): Payment
    {
        config(['services.stripe.secret' => 'sk_test_x', 'services.stripe.webhook_secret' => 'whsec_x']);
        $o = Order::create(['number' => 'BGF-S-1', 'first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '0800000000',
            'shipping_address' => ['address' => 'x'], 'subtotal' => 250000, 'total' => 250000, 'payment_method' => 'stripe', 'payment_status' => 'pending']);
        return Payment::create(['order_id' => $o->id, 'gateway' => 'stripe', 'reference' => 'S1', 'amount' => 250000, 'currency' => 'NGN', 'meta' => ['session_id' => 'cs_test_1']]);
    }

    private function session(array $over = []): array
    {
        return array_merge(['id' => 'cs_test_1', 'payment_status' => 'paid', 'amount_total' => 250000, 'currency' => 'ngn', 'client_reference_id' => 'S1', 'payment_intent' => 'pi_1'], $over);
    }

    private function signed(string $body, ?int $time = null, string $secret = 'whsec_x'): array
    {
        $t = $time ?? time();
        return ['HTTP_STRIPE_SIGNATURE' => "t={$t},v1=".hash_hmac('sha256', $t.'.'.$body, $secret), 'CONTENT_TYPE' => 'application/json'];
    }

    public function test_paid_session_settles_and_stores_payment_intent(): void
    {
        $p = $this->pending();
        Http::fake(['api.stripe.com/v1/checkout/sessions/*' => Http::response($this->session())]);
        app(PaymentService::class)->verifyAndSettle('stripe', 'S1');
        $this->assertSame('paid', $p->order->fresh()->payment_status);
        $this->assertSame('pi_1', $p->fresh()->gateway_transaction_id);
    }

    public function test_unpaid_or_wrong_amount_is_not_settled(): void
    {
        $p = $this->pending();
        Http::fake(['api.stripe.com/v1/checkout/sessions/*' => Http::sequence()->push($this->session(['payment_status' => 'unpaid']))->push($this->session(['amount_total' => 100]))]);
        $svc = app(PaymentService::class);
        $svc->verifyAndSettle('stripe', 'S1');
        $this->assertNotSame('paid', $p->order->fresh()->payment_status);
        $svc->verifyAndSettle('stripe', 'S1');
        $this->assertNotSame('paid', $p->order->fresh()->payment_status);
    }

    public function test_webhook_signature_rules(): void
    {
        $this->pending();
        Http::fake(['api.stripe.com/v1/checkout/sessions/*' => Http::response($this->session())]);
        $body = json_encode(['id' => 'evt_1', 'type' => 'checkout.session.completed', 'data' => ['object' => ['client_reference_id' => 'S1']]]);

        $this->call('POST', '/webhooks/stripe', [], [], [], $this->signed($body, null, 'wrong'), $body)->assertStatus(401);
        $this->call('POST', '/webhooks/stripe', [], [], [], $this->signed($body, time() - 4000), $body)->assertStatus(401); // replayed/stale
        $this->call('POST', '/webhooks/stripe', [], [], [], $this->signed($body), $body)->assertOk();
        $this->assertSame('paid', Order::where('number', 'BGF-S-1')->value('payment_status'));
    }

    public function test_refund_uses_payment_intent(): void
    {
        $p = $this->pending();
        $p->update(['status' => 'successful', 'gateway_transaction_id' => 'pi_1']);
        Http::fake(['api.stripe.com/v1/refunds' => Http::response(['status' => 'succeeded'])]);
        app(PaymentService::class)->refund($p->fresh(), 50000, null);
        Http::assertSent(fn ($r) => str_contains($r->url(), '/refunds') && $r['payment_intent'] === 'pi_1' && $r['amount'] === 50000);
        $this->assertSame('partially_refunded', $p->order->fresh()->payment_status);
    }
}
