<?php

namespace Tests\Feature;

use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use App\Services\CartService;
use App\Services\Credentials;
use App\Services\Payments\PaystackGateway;
use App\Support\Branding;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class Phase9Test extends TestCase
{
    use RefreshDatabase;

    private function user(string $role, string $email = null): User
    {
        $u = new User(['name' => $role, 'email' => $email ?? $role.'@x.test', 'password' => 'secret-pass-123']);
        $u->forceFill(['role' => $role, 'email_verified_at' => now()])->save();
        return $u;
    }

    private function settingsPayload(array $over = []): array
    {
        return array_merge(['currency' => 'NGN'], $over);
    }

    public function test_secret_is_stored_encrypted_and_enables_the_gateway(): void
    {
        config(['services.paystack.secret' => null]);
        $this->assertFalse((new PaystackGateway)->isEnabled());

        $this->actingAs($this->user('admin'))->put('/admin/settings', $this->settingsPayload(['secret_paystack_secret' => 'sk_live_SUPERSECRET']))->assertSessionHas('status');

        $raw = DB::table('settings')->where('key', 'secret.paystack_secret')->value('value');
        $this->assertNotNull($raw);
        $this->assertStringNotContainsString('SUPERSECRET', $raw);
        $this->assertSame('sk_live_SUPERSECRET', Credentials::get('paystack_secret'));
        $this->assertTrue((new PaystackGateway)->isEnabled());
    }

    public function test_settings_page_never_prints_saved_secrets_and_blank_keeps_them(): void
    {
        $admin = $this->user('admin');
        Setting::putSecret('stripe_secret', 'sk_test_HIDDEN123');

        $this->actingAs($admin)->get('/admin/settings')->assertOk()->assertDontSee('HIDDEN123')->assertSee('Saved (hidden)');
        $this->actingAs($admin)->put('/admin/settings', $this->settingsPayload(['secret_stripe_secret' => '']));
        $this->assertSame('sk_test_HIDDEN123', Setting::secret('stripe_secret'));

        $this->actingAs($admin)->put('/admin/settings', $this->settingsPayload(['clear_stripe_secret' => '1']));
        $this->assertNull(Setting::secret('stripe_secret'));
    }

    public function test_only_admin_can_open_settings_users_and_zone_pages_follow_roles(): void
    {
        $this->actingAs($this->user('manager'))->get('/admin/settings')->assertForbidden();
        $this->actingAs($this->user('manager'))->get('/admin/users')->assertForbidden();
        $this->actingAs($this->user('manager'))->get('/admin/zones')->assertOk();
        $this->actingAs($this->user('staff'))->get('/admin/zones')->assertForbidden();
    }

    public function test_brand_colours_validate_and_render_as_css(): void
    {
        $admin = $this->user('admin');
        $this->actingAs($admin)->put('/admin/settings', $this->settingsPayload(['brand_red' => 'red;}</style><script>']))->assertSessionHasErrors('brand_red');

        $this->actingAs($admin)->put('/admin/settings', $this->settingsPayload(['brand_red' => '#c8102e']));
        $this->assertStringContainsString('--color-brand-red:#C8102E', Branding::css());

        $this->actingAs($admin)->put('/admin/settings', $this->settingsPayload(['reset_colors' => '1']));
        $this->assertStringContainsString('--color-brand-red:#E51B23', Branding::css());
    }

    public function test_logo_upload_is_used_and_svg_is_rejected(): void
    {
        Storage::fake('public');
        $admin = $this->user('admin');
        $this->actingAs($admin)->put('/admin/settings', $this->settingsPayload(['logo' => UploadedFile::fake()->create('logo.svg', 5, 'image/svg+xml')]))->assertSessionHasErrors('logo');

        $this->actingAs($admin)->put('/admin/settings', $this->settingsPayload(['logo' => UploadedFile::fake()->image('logo.png', 300, 100)]))->assertSessionHasNoErrors();
        $this->assertStringContainsString('/storage/branding/', Branding::logo());
    }

    public function test_tax_and_free_delivery_thresholds_apply_to_totals(): void
    {
        $p = Product::create(['name' => 'Sofa', 'sku' => 'S1', 'price' => 1000000, 'stock_quantity' => 5, 'status' => 'published']);
        $this->post(route('cart.add', $p), ['quantity' => 1]);
        Setting::put('tax_rate', '7.5');
        Setting::put('free_delivery_min', '500000');
        $zone = \App\Models\DeliveryZone::create(['name' => 'Lagos', 'fee' => 250000]);

        $t = app(CartService::class)->calculate($zone);
        $this->assertSame(75000, $t['tax']);         // 7.5% of 1,000,000 kobo
        $this->assertSame(0, $t['delivery_fee']);    // subtotal above the free-delivery minimum
        $this->assertSame(1075000, $t['total']);

        Setting::put('free_delivery_min', '0');
        $this->assertSame(250000, app(CartService::class)->calculate($zone)['delivery_fee']);
    }

    public function test_last_admin_cannot_be_demoted_or_deleted_and_staff_can_be_created(): void
    {
        $admin = $this->user('admin');
        $this->actingAs($admin)->put(route('admin.users.update', $admin), ['role' => 'staff'])->assertSessionHas('error');
        $this->actingAs($admin)->delete(route('admin.users.destroy', $admin))->assertSessionHas('error');
        $this->assertSame('admin', $admin->fresh()->role);

        $this->actingAs($admin)->post('/admin/users', ['name' => 'New Staff', 'email' => 'new@x.test', 'role' => 'staff', 'password' => 'a-long-password-1'])->assertSessionHas('status');
        $this->assertSame('staff', User::where('email', 'new@x.test')->value('role'));
        $this->actingAs($admin)->post('/admin/users', ['name' => 'Weak', 'email' => 'weak@x.test', 'role' => 'staff', 'password' => 'short'])->assertSessionHasErrors('password');
    }

    public function test_order_prefix_is_sanitised(): void
    {
        Setting::put('order_prefix', 'my-shop!');
        $this->assertStringStartsWith('MYSHOP-', \App\Models\Order::generateNumber());
    }
}
