<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Services\OrderService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminTest extends TestCase
{
    use RefreshDatabase;

    private function user(string $role): User
    {
        $u = new User(['name' => $role, 'email' => $role.'@x.test', 'password' => 'secret-pass']);
        $u->forceFill(['role' => $role, 'email_verified_at' => now()])->save();
        return $u;
    }

    public function test_customers_cannot_open_admin(): void
    {
        $this->actingAs($this->user('customer'))->get('/admin')->assertForbidden();
        $this->get('/admin')->assertRedirect('/login');
    }

    public function test_staff_can_see_orders_but_not_products_or_settings(): void
    {
        $staff = $this->user('staff');
        $this->actingAs($staff)->get('/admin/orders')->assertOk();
        $this->actingAs($staff)->get('/admin/products')->assertForbidden();
        $this->actingAs($staff)->get('/admin/settings')->assertForbidden();
    }

    public function test_manager_cannot_change_settings(): void
    {
        $this->actingAs($this->user('manager'))->get('/admin/settings')->assertForbidden();
        $this->actingAs($this->user('admin'))->get('/admin/settings')->assertOk();
    }

    public function test_cancelling_an_order_restores_stock_once(): void
    {
        $p = Product::create(['name' => 'Desk', 'sku' => 'D1', 'price' => 100000, 'stock_quantity' => 3, 'status' => 'published']);
        $o = Order::create([
            'number' => 'BGF-T-2', 'first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '0800000000',
            'shipping_address' => ['address' => 'x'], 'subtotal' => 200000, 'total' => 200000, 'payment_method' => 'cod',
        ]);
        $o->items()->create(['product_id' => $p->id, 'name' => 'Desk', 'sku' => 'D1', 'unit_price' => 100000, 'quantity' => 2, 'line_total' => 200000]);

        $svc = app(OrderService::class);
        $svc->update($o, ['fulfilment_status' => 'cancelled'], 1);
        $svc->update($o->fresh(), ['fulfilment_status' => 'cancelled'], 1);

        $this->assertSame(5, $p->fresh()->stock_quantity);
    }

    public function test_gateway_order_cannot_be_hand_marked_paid(): void
    {
        $o = Order::create([
            'number' => 'BGF-T-3', 'first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '0800000000',
            'shipping_address' => ['address' => 'x'], 'subtotal' => 100, 'total' => 100, 'payment_method' => 'paystack',
        ]);
        $this->expectException(\InvalidArgumentException::class);
        app(OrderService::class)->update($o, ['payment_status' => 'paid'], 1);
    }

    public function test_csv_import_reports_bad_rows(): void
    {
        $csv = "sku,name,price,sale_price\nA1,Good chair,100.50,\nA2,Bad sale,50,60\n,No sku,10,\n";
        $file = \Illuminate\Http\UploadedFile::fake()->createWithContent('p.csv', $csv);
        $this->actingAs($this->user('manager'))->post('/admin/products/import', ['file' => $file])->assertSessionHas('import_errors');
        $this->assertSame(10050, Product::where('sku', 'A1')->value('price'));
        $this->assertNull(Product::where('sku', 'A2')->first());
    }
}
