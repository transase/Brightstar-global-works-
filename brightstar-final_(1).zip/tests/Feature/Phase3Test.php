<?php

namespace Tests\Feature;

use App\Mail\OrderMail;
use App\Models\Order;
use App\Models\Product;
use App\Models\Setting;
use App\Models\Slide;
use App\Services\OrderService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class Phase3Test extends TestCase
{
    use RefreshDatabase;

    private function order(string $method = 'cod', string $created = 'now'): Order
    {
        $o = Order::create([
            'number' => 'BGF-P3-'.rand(100, 999), 'first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '0800000000',
            'shipping_address' => ['address' => 'x'], 'subtotal' => 100, 'total' => 100, 'payment_method' => $method,
        ]);
        $o->forceFill(['created_at' => now()->modify($created)])->save();
        return $o;
    }

    public function test_status_change_queues_customer_email(): void
    {
        Mail::fake();
        app(OrderService::class)->update($this->order(), ['fulfilment_status' => 'shipped'], null);
        Mail::assertQueued(OrderMail::class, fn ($m) => $m->kind === 'status' && $m->status === 'shipped');
    }

    public function test_gateway_orders_do_not_email_until_paid(): void
    {
        Mail::fake();
        app(\App\Services\OrderNotifier::class)->placed($this->order('paystack'));
        Mail::assertNothingQueued();
    }

    public function test_offline_order_emails_customer_and_store(): void
    {
        Mail::fake();
        Setting::put('store_email', 'shop@brightstar.test');
        app(\App\Services\OrderNotifier::class)->placed($this->order('cod'));
        Mail::assertQueued(OrderMail::class, 2);
    }

    public function test_stale_unpaid_gateway_order_is_cancelled_and_stock_returned(): void
    {
        Mail::fake();
        config(['services.paystack.secret' => 'sk_test_x']);
        \Illuminate\Support\Facades\Http::fake(['api.paystack.co/*' => \Illuminate\Support\Facades\Http::response(['data' => ['status' => 'abandoned']])]);
        $p = Product::create(['name' => 'Bed', 'sku' => 'B1', 'price' => 100, 'stock_quantity' => 1, 'status' => 'published']);
        $o = $this->order('paystack', '-5 hours');
        $o->items()->create(['product_id' => $p->id, 'name' => 'Bed', 'sku' => 'B1', 'unit_price' => 100, 'quantity' => 2, 'line_total' => 200]);

        $this->artisan('orders:release-stale')->assertSuccessful();

        $this->assertSame('cancelled', $o->fresh()->fulfilment_status);
        $this->assertSame(3, $p->fresh()->stock_quantity);
    }

    public function test_only_live_slides_are_shown(): void
    {
        Slide::create(['type' => 'hero', 'heading' => 'Live one']);
        Slide::create(['type' => 'hero', 'heading' => 'Expired', 'ends_at' => now()->subDay()]);
        Slide::create(['type' => 'hero', 'heading' => 'Future', 'starts_at' => now()->addDay()]);
        Slide::create(['type' => 'hero', 'heading' => 'Hidden', 'is_active' => false]);

        $this->assertSame(['Live one'], Slide::live('hero')->pluck('heading')->all());
    }

    public function test_sitemap_lists_published_products_only(): void
    {
        Product::create(['name' => 'Shown', 'sku' => 'S1', 'price' => 1, 'status' => 'published']);
        Product::create(['name' => 'Secret', 'sku' => 'S2', 'price' => 1, 'status' => 'draft']);
        $this->get('/sitemap.xml')->assertOk()->assertSee('/product/shown', false)->assertDontSee('/product/secret', false);
    }

    public function test_slide_url_rejects_javascript_scheme(): void
    {
        $u = new \App\Models\User(['name' => 'm', 'email' => 'm@x.test', 'password' => 'secret-pass']);
        $u->forceFill(['role' => 'manager', 'email_verified_at' => now()])->save();
        $this->actingAs($u)->post('/admin/slides', ['type' => 'hero', 'heading' => 'x', 'url' => 'javascript:alert(1)'])->assertSessionHasErrors('url');
    }
}
