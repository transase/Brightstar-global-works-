<?php

namespace Tests\Feature;

use App\Models\NavItem;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Services\ImageStore;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class Phase4Test extends TestCase
{
    use RefreshDatabase;

    private function user(string $role = 'customer', string $email = 'c@x.test'): User
    {
        $u = new User(['name' => $role, 'email' => $email, 'password' => 'secret-pass']);
        $u->forceFill(['role' => $role, 'email_verified_at' => now()])->save();
        return $u;
    }

    private function orderFor(User $u, Product $p, int $qty): Order
    {
        $o = Order::create(['number' => 'BGF-A-'.rand(1000, 9999), 'user_id' => $u->id, 'first_name' => 'A', 'last_name' => 'B', 'email' => $u->email,
            'phone' => '0800000000', 'shipping_address' => ['address' => 'x'], 'subtotal' => 100, 'total' => 100, 'payment_method' => 'cod']);
        $o->items()->create(['product_id' => $p->id, 'name' => $p->name, 'sku' => $p->sku, 'unit_price' => 100, 'quantity' => $qty, 'line_total' => 100 * $qty]);
        return $o;
    }

    public function test_customers_see_only_their_own_orders(): void
    {
        $p = Product::create(['name' => 'Chair', 'sku' => 'C1', 'price' => 100, 'stock_quantity' => 9, 'status' => 'published']);
        $mine = $this->orderFor($this->user('customer', 'a@x.test'), $p, 1);
        $other = $this->orderFor($this->user('customer', 'b@x.test'), $p, 1);

        $this->actingAs(User::where('email', 'a@x.test')->first());
        $this->get(route('account.order', $mine->number))->assertOk();
        $this->get(route('account.order', $other->number))->assertNotFound();
    }

    public function test_reorder_uses_current_price_and_skips_unavailable(): void
    {
        $u = $this->user();
        $ok = Product::create(['name' => 'Chair', 'sku' => 'C1', 'price' => 500, 'stock_quantity' => 9, 'status' => 'published']);
        $gone = Product::create(['name' => 'Old Sofa', 'sku' => 'S1', 'price' => 900, 'stock_quantity' => 0, 'status' => 'published']);
        $o = $this->orderFor($u, $ok, 2);
        $o->items()->create(['product_id' => $gone->id, 'name' => 'Old Sofa', 'sku' => 'S1', 'unit_price' => 900, 'quantity' => 1, 'line_total' => 900]);

        $this->actingAs($u)->post(route('account.reorder', $o->number))->assertRedirect(route('cart.show'));

        $totals = app(\App\Services\CartService::class)->calculate();
        $this->assertCount(1, $totals['lines']);
        $this->assertSame(1000, $totals['subtotal']); // 2 x current price 500, not the historical 100
    }

    public function test_nav_items_nest_only_one_level_and_hidden_items_are_not_public(): void
    {
        $manager = $this->user('manager', 'm@x.test');
        $top = NavItem::create(['label' => 'Living', 'url' => '/category/living-room']);
        $child = NavItem::create(['label' => 'Sofas', 'url' => '/category/sofas', 'parent_id' => $top->id]);
        NavItem::create(['label' => 'Secret', 'url' => '/x', 'is_visible' => false]);

        $this->assertSame(['Living'], NavItem::tree()->pluck('label')->all());

        $this->actingAs($manager)->post('/admin/nav', ['label' => 'Deep', 'url' => '/deep', 'parent_id' => $child->id])->assertSessionHas('error');
        $this->actingAs($manager)->post('/admin/nav', ['label' => 'Bad', 'url' => 'javascript:alert(1)'])->assertSessionHasErrors('url');
    }

    public function test_image_thumb_path_helper(): void
    {
        $this->assertSame('products/abc-thumb.webp', ImageStore::thumb('products/abc.webp'));
        $this->assertSame('products/old.jpg', ImageStore::thumb('products/old.jpg')); // legacy uploads keep their original
    }

    public function test_about_and_contact_exist_but_unknown_pages_404(): void
    {
        $this->get('/about')->assertOk();
        $this->get('/contact')->assertOk();
        $this->get('/page/does-not-exist')->assertNotFound();
    }
}
