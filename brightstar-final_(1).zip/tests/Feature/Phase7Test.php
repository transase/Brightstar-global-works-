<?php

namespace Tests\Feature;

use App\Models\Article;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class Phase7Test extends TestCase
{
    use RefreshDatabase;

    public function test_pinned_published_product_renders_hotspot_and_unpinned_does_not(): void
    {
        $pinned = Product::create(['name' => 'Pinned Lamp', 'sku' => 'P1', 'price' => 100, 'status' => 'published']);
        $plain = Product::create(['name' => 'Plain Rug', 'sku' => 'P2', 'price' => 100, 'status' => 'published']);
        $draft = Product::create(['name' => 'Draft Chair', 'sku' => 'P3', 'price' => 100, 'status' => 'draft']);
        $a = Article::create(['slug' => 'look', 'title' => 'Look', 'cover_image' => 'articles/x.webp', 'is_published' => true, 'published_at' => now()->subMinute()]);
        $a->products()->attach([$pinned->id => ['pos_x' => 25.5, 'pos_y' => 60], $plain->id => [], $draft->id => ['pos_x' => 10, 'pos_y' => 10]]);

        $res = $this->get('/ideas/look')->assertOk();
        $res->assertSee('left: 25.5%', false)->assertSee('Show Pinned Lamp', false);
        $res->assertDontSee('Show Plain Rug', false)->assertDontSee('Draft Chair');
    }

    public function test_admin_saves_pins_and_rejects_out_of_range(): void
    {
        $m = new User(['name' => 'm', 'email' => 'm@x.test', 'password' => 'secret-pass']);
        $m->forceFill(['role' => 'manager', 'email_verified_at' => now()])->save();
        $p = Product::create(['name' => 'Lamp', 'sku' => 'P1', 'price' => 100, 'status' => 'published']);
        $a = Article::create(['slug' => 'look', 'title' => 'Look']);

        $this->actingAs($m)->put(route('admin.articles.update', $a), ['title' => 'Look', 'products' => [$p->id], 'hotspots' => [$p->id => ['x' => 140, 'y' => 5]]])
            ->assertSessionHasErrors('hotspots.'.$p->id.'.x');

        $this->actingAs($m)->put(route('admin.articles.update', $a), ['title' => 'Look', 'products' => [$p->id], 'hotspots' => [$p->id => ['x' => '33.333', 'y' => '66']]]);
        $pivot = $a->fresh()->products->first()->pivot;
        $this->assertEquals(33.33, (float) $pivot->pos_x);
        $this->assertEquals(66.0, (float) $pivot->pos_y);
    }
}
