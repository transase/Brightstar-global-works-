<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class CheckoutPaymentTest extends TestCase
{
    use RefreshDatabase;

    private function order(int $total = 5000000): array
    {
        config(['services.paystack.enabled' => true, 'services.paystack.secret' => 'sk_test_x']);
        $order = Order::create([
            'number' => 'BGF-TEST-1', 'first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '0800000000',
            'shipping_address' => ['address' => 'x'], 'subtotal' => $total, 'total' => $total, 'payment_method' => 'paystack',
        ]);
        $payment = Payment::create(['order_id' => $order->id, 'gateway' => 'paystack', 'reference' => 'REF1', 'amount' => $total, 'currency' => 'NGN']);
        return [$order, $payment];
    }

    public function test_verified_payment_marks_order_paid_once(): void
    {
        [$order] = $this->order();
        Http::fake(['api.paystack.co/*' => Http::response(['data' => ['status' => 'success', 'amount' => 5000000, 'currency' => 'NGN', 'id' => 99]])]);

        $svc = app(PaymentService::class);
        $svc->verifyAndSettle('paystack', 'REF1');
        $svc->verifyAndSettle('paystack', 'REF1'); // duplicate callback/webhook

        $this->assertSame('paid', $order->fresh()->payment_status);
        $this->assertSame(1, $order->logs()->where('event', 'payment_verified')->count());
    }

    public function test_amount_mismatch_is_not_marked_paid(): void
    {
        [$order] = $this->order();
        Http::fake(['api.paystack.co/*' => Http::response(['data' => ['status' => 'success', 'amount' => 100, 'currency' => 'NGN', 'id' => 99]])]);

        app(PaymentService::class)->verifyAndSettle('paystack', 'REF1');

        $this->assertNotSame('paid', $order->fresh()->payment_status);
    }

    public function test_webhook_with_bad_signature_is_rejected(): void
    {
        $this->order();
        $this->postJson('/webhooks/paystack', ['event' => 'charge.success'], ['x-paystack-signature' => 'bad'])->assertStatus(401);
    }

    public function test_valid_webhook_signature_settles_payment(): void
    {
        [$order] = $this->order();
        Http::fake(['api.paystack.co/*' => Http::response(['data' => ['status' => 'success', 'amount' => 5000000, 'currency' => 'NGN', 'id' => 99]])]);
        $body = json_encode(['event' => 'charge.success', 'data' => ['id' => 99, 'reference' => 'REF1']]);
        $sig = hash_hmac('sha512', $body, 'sk_test_x');

        $this->call('POST', '/webhooks/paystack', [], [], [], ['HTTP_X_PAYSTACK_SIGNATURE' => $sig, 'CONTENT_TYPE' => 'application/json'], $body)->assertOk();
        $this->assertSame('paid', $order->fresh()->payment_status);
    }

    public function test_cart_total_ignores_browser_supplied_prices(): void
    {
        $p = Product::create(['name' => 'Chair', 'sku' => 'C1', 'price' => 1000000, 'stock_quantity' => 5, 'status' => 'published']);
        $this->post(route('cart.add', $p), ['quantity' => 2, 'price' => 1])->assertRedirect();
        $totals = app(\App\Services\CartService::class)->calculate();
        $this->assertSame(2000000, $totals['subtotal']);
    }
}
