<?php

namespace Tests\Feature;

use App\Models\Article;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class Phase5Test extends TestCase
{
    use RefreshDatabase;

    private function paid(): Payment
    {
        config(['services.paystack.secret' => 'sk_test_x']);
        $o = Order::create(['number' => 'BGF-R-1', 'first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '0800000000',
            'shipping_address' => ['address' => 'x'], 'subtotal' => 100000, 'total' => 100000, 'payment_method' => 'paystack', 'payment_status' => 'paid']);
        return Payment::create(['order_id' => $o->id, 'gateway' => 'paystack', 'reference' => 'R1', 'amount' => 100000, 'currency' => 'NGN', 'status' => 'successful']);
    }

    public function test_partial_then_full_refund_updates_statuses(): void
    {
        Http::fake(['api.paystack.co/refund' => Http::response(['status' => true, 'message' => 'Refund has been queued'])]);
        $p = $this->paid();
        $svc = app(PaymentService::class);

        $svc->refund($p, 40000, null);
        $this->assertSame('partially_refunded', $p->order->fresh()->payment_status);
        $this->assertSame('successful', $p->fresh()->status);

        $svc->refund($p->fresh(), 60000, null);
        $this->assertSame('refunded', $p->order->fresh()->payment_status);
        $this->assertSame('refunded', $p->fresh()->status);
    }

    public function test_cannot_refund_more_than_remaining(): void
    {
        Http::fake();
        $p = $this->paid();
        $this->expectException(\InvalidArgumentException::class);
        app(PaymentService::class)->refund($p, 100001, null);
    }

    public function test_provider_rejection_leaves_records_untouched(): void
    {
        Http::fake(['api.paystack.co/refund' => Http::response(['status' => false, 'message' => 'nope'], 400)]);
        $p = $this->paid();
        try { app(PaymentService::class)->refund($p, 1000, null); } catch (\InvalidArgumentException) {}
        $this->assertSame(0, $p->fresh()->refunded_amount);
        $this->assertSame('paid', $p->order->fresh()->payment_status);
    }

    public function test_manager_cannot_refund_but_admin_can_reach_endpoint(): void
    {
        Http::fake(['api.paystack.co/refund' => Http::response(['status' => true, 'message' => 'ok'])]);
        $p = $this->paid();
        $mk = function ($role) { $u = new User(['name' => $role, 'email' => $role.'@x.test', 'password' => 'secret-pass']); $u->forceFill(['role' => $role, 'email_verified_at' => now()])->save(); return $u; };
        $this->actingAs($mk('manager'))->post(route('admin.payments.refund', $p), ['amount' => 10])->assertForbidden();
        $this->actingAs($mk('admin'))->post(route('admin.payments.refund', $p), ['amount' => 10])->assertSessionHas('status');
    }

    public function test_article_shows_only_published_products_and_hides_drafts(): void
    {
        $live = Product::create(['name' => 'Live Sofa', 'sku' => 'L1', 'price' => 100, 'status' => 'published']);
        $draft = Product::create(['name' => 'Draft Sofa', 'sku' => 'D1', 'price' => 100, 'status' => 'draft']);
        $a = Article::create(['slug' => 'cosy', 'title' => 'Cosy lounge', 'is_published' => true, 'published_at' => now()->subMinute()]);
        $a->products()->attach([$live->id, $draft->id]);
        $hidden = Article::create(['slug' => 'later', 'title' => 'Scheduled', 'is_published' => true, 'published_at' => now()->addDay()]);

        $this->get('/ideas/cosy')->assertOk()->assertSee('Live Sofa')->assertDontSee('Draft Sofa');
        $this->get('/ideas/later')->assertNotFound();
    }
}
