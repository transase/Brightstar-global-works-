<?php

namespace Tests\Feature;

use App\Mail\OrderMail;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class PaymentEdgeCasesTest extends TestCase
{
    use RefreshDatabase;

    private function orderWithTwoAttempts(): array
    {
        config(['services.paystack.secret' => 'sk_test_x', 'services.flutterwave.secret' => 'flw_x']);
        $p = Product::create(['name' => 'Bed', 'sku' => 'B1', 'price' => 100000, 'stock_quantity' => 5, 'status' => 'published']);
        $o = Order::create(['number' => 'BGF-E-1', 'first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '0800000000',
            'shipping_address' => ['address' => 'x'], 'subtotal' => 100000, 'total' => 100000, 'payment_method' => 'paystack', 'payment_status' => 'pending', 'fulfilment_status' => 'awaiting_payment']);
        $o->items()->create(['product_id' => $p->id, 'name' => 'Bed', 'sku' => 'B1', 'unit_price' => 100000, 'quantity' => 1, 'line_total' => 100000]);
        $a = Payment::create(['order_id' => $o->id, 'gateway' => 'paystack', 'reference' => 'A1', 'amount' => 100000, 'currency' => 'NGN']);
        $b = Payment::create(['order_id' => $o->id, 'gateway' => 'flutterwave', 'reference' => 'B1', 'amount' => 100000, 'currency' => 'NGN']);
        return [$o, $a, $b, $p];
    }

    private function fakeProviders(string $paystack, string $flutterwave): void
    {
        Http::fake([
            'api.paystack.co/*' => Http::response(['data' => ['status' => $paystack, 'amount' => 100000, 'currency' => 'NGN', 'id' => 1]]),
            'api.flutterwave.com/*' => Http::response(['data' => ['status' => $flutterwave, 'amount' => 1000, 'currency' => 'NGN', 'id' => 2]]),
        ]);
    }

    public function test_failed_old_attempt_does_not_downgrade_an_order_paid_by_another_attempt(): void
    {
        [$o] = $this->orderWithTwoAttempts();
        $this->fakeProviders('abandoned', 'successful');
        $svc = app(PaymentService::class);

        $svc->verifyAndSettle('flutterwave', 'B1');   // customer paid via the second attempt
        $svc->verifyAndSettle('paystack', 'A1');      // stale first attempt re-checked later: failed

        $this->assertSame('paid', $o->fresh()->payment_status);
        $this->assertSame('processing', $o->fresh()->fulfilment_status);
    }

    public function test_second_successful_payment_is_flagged_not_fulfilled_twice(): void
    {
        Mail::fake();
        [$o, , , $p] = $this->orderWithTwoAttempts();
        $this->fakeProviders('success', 'successful');
        $svc = app(PaymentService::class);

        $svc->verifyAndSettle('paystack', 'A1');
        $svc->verifyAndSettle('flutterwave', 'B1'); // customer paid twice

        $this->assertSame(1, $p->fresh()->sales_count);
        $this->assertSame('duplicate_payment', Payment::where('reference', 'B1')->first()->meta['needs_review']);
        Mail::assertQueuedCount(1); // one "paid" email only (no store email configured)
    }

    public function test_payment_after_cancellation_does_not_reopen_the_order(): void
    {
        [$o, $a] = $this->orderWithTwoAttempts();
        $o->update(['fulfilment_status' => 'cancelled']);
        $this->fakeProviders('success', 'abandoned');

        app(PaymentService::class)->verifyAndSettle('paystack', 'A1');

        $this->assertSame('cancelled', $o->fresh()->fulfilment_status);
        $this->assertSame('paid', $o->fresh()->payment_status);
        $this->assertSame('paid_after_cancellation', $a->fresh()->meta['needs_review']);
    }

    private function checkoutPayload(array $over = []): array
    {
        return array_merge(['first_name' => 'A', 'last_name' => 'B', 'email' => 'a@b.test', 'phone' => '08000000000', 'address' => '1 Road',
            'city' => 'Lagos', 'state' => 'Lagos', 'country' => 'Nigeria', 'payment_method' => 'whatsapp'], $over);
    }

    public function test_delivery_area_is_required_when_areas_exist(): void
    {
        \App\Models\Setting::put('whatsapp_phone', '+2348012345678');
        $p = Product::create(['name' => 'Desk', 'sku' => 'D1', 'price' => 100000, 'stock_quantity' => 5, 'status' => 'published']);
        $zone = \App\Models\DeliveryZone::create(['name' => 'Lagos', 'fee' => 250000]);
        $this->post(route('cart.add', $p), ['quantity' => 1]);

        $this->post(route('checkout.store'), $this->checkoutPayload())->assertSessionHasErrors('delivery_zone_id'); // tampered: no area

        $this->post(route('checkout.store'), $this->checkoutPayload(['delivery_zone_id' => $zone->id]))->assertRedirect();
        $this->assertSame(350000, Order::latest('id')->first()->total); // item + delivery fee, computed server-side
    }

    public function test_coupon_at_its_usage_limit_blocks_the_order_and_keeps_stock(): void
    {
        \App\Models\Setting::put('whatsapp_phone', '+2348012345678');
        $p = Product::create(['name' => 'Desk', 'sku' => 'D1', 'price' => 100000, 'stock_quantity' => 5, 'status' => 'published']);
        $c = \App\Models\Coupon::create(['code' => 'ONCE', 'type' => 'percent', 'value' => 10, 'max_uses' => 1]);
        $this->post(route('cart.add', $p), ['quantity' => 1]);
        $this->post(route('cart.coupon'), ['code' => 'ONCE']);
        $c->update(['used_count' => 1]); // someone else used the last redemption meanwhile

        $this->post(route('checkout.store'), $this->checkoutPayload())->assertSessionHas('error');
        $this->assertSame(5, $p->fresh()->stock_quantity);
        $this->assertSame(0, Order::count());
    }
}
