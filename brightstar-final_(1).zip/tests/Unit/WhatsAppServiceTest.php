<?php

namespace Tests\Unit;

use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Setting;
use App\Services\WhatsAppService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WhatsAppServiceTest extends TestCase
{
    use RefreshDatabase;

    public function test_phone_is_normalised_to_digits_and_rejects_junk(): void
    {
        $this->assertSame('2348012345678', WhatsAppService::normalisePhone('+234 801 234 5678'));
        $this->assertNull(WhatsAppService::normalisePhone('abc'));
        $this->assertNull(WhatsAppService::normalisePhone('123'));
    }

    public function test_no_link_when_phone_not_configured(): void
    {
        $this->assertNull(app(WhatsAppService::class)->link('Hello'));
    }

    public function test_message_is_url_encoded_and_uses_variant_values(): void
    {
        Setting::put('whatsapp_phone', '+2348012345678');
        $product = Product::create(['name' => 'Oak Bed', 'sku' => 'BED-1', 'price' => 10000000, 'status' => 'published']);
        $variant = ProductVariant::create(['product_id' => $product->id, 'sku' => 'BED-1-K', 'size' => 'King', 'price_adjustment' => 500000]);

        $wa = app(WhatsAppService::class);
        $msg = $wa->productMessage($product, $variant, 2, 'https://example.test/product/oak-bed');

        $this->assertStringContainsString('Product: Oak Bed', $msg);
        $this->assertStringContainsString('SKU: BED-1-K', $msg);
        $this->assertStringContainsString('Selected Variant: King', $msg);
        $this->assertStringContainsString('Quantity: 2', $msg);
        $this->assertStringContainsString('₦1,050,000.00', $msg);

        $link = $wa->link($msg);
        $this->assertStringStartsWith('https://wa.me/2348012345678?text=', $link);
        $this->assertStringNotContainsString("\n", $link);
    }
}
