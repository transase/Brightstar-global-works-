<?php

namespace App\Providers;

use App\Models\Setting;
use App\Services\Credentials;
use Illuminate\Support\ServiceProvider;

/** Applies admin-saved settings (store name, SMTP) to Laravel's config at boot, including queue workers. */
class StoreSettingsServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // cPanel split layout: app lives outside public_html, so CLI/cron must be told where the public files are.
        if (($p = env('PUBLIC_PATH')) && is_dir($p)) $this->app->usePublicPath($p);
    }

    public function boot(): void
    {
        // Disk for hosts that block symlinks (storage:link): files are written straight into public/uploads.
        config(['filesystems.disks.uploads' => ['driver' => 'local', 'root' => public_path('uploads'), 'url' => rtrim((string) config('app.url'), '/').'/uploads', 'visibility' => 'public', 'throw' => false]]);

        try {
            if (! \Illuminate\Support\Facades\Schema::hasTable('settings')) return;

            if ($name = Setting::get('store_name')) config(['app.name' => $name]);

            if ($host = Setting::get('mail_host')) {
                $enc = Setting::get('mail_encryption');
                config([
                    'mail.default' => 'smtp',
                    'mail.mailers.smtp.host' => $host,
                    'mail.mailers.smtp.port' => (int) Setting::get('mail_port', 587),
                    'mail.mailers.smtp.username' => Setting::get('mail_username'),
                    'mail.mailers.smtp.password' => Credentials::get('mail_password'),
                    'mail.mailers.smtp.scheme' => $enc === 'ssl' ? 'smtps' : 'smtp',
                    'mail.mailers.smtp.encryption' => in_array($enc, ['tls', 'ssl'], true) ? $enc : null,
                ]);
            }
            if ($from = Setting::get('mail_from_address')) {
                config(['mail.from.address' => $from, 'mail.from.name' => Setting::get('mail_from_name', Setting::get('store_name', config('app.name')))]);
            }
        } catch (\Throwable) {
            // Database not ready (fresh install / migrating): fall back to .env values.
        }
    }
}
