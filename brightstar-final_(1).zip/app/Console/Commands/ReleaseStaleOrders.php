<?php

namespace App\Console\Commands;

use App\Models\Order;
use App\Services\OrderService;
use App\Services\PaymentService;
use Illuminate\Console\Command;

/** Cancels unpaid online-payment orders after a grace period and returns their reserved stock. */
class ReleaseStaleOrders extends Command
{
    protected $signature = 'orders:release-stale {--hours=3}';
    protected $description = 'Release stock held by abandoned online-payment orders';

    public function handle(PaymentService $payments, OrderService $orders): int
    {
        $count = 0;
        Order::whereIn('payment_method', OrderService::GATEWAYS)
            ->whereIn('payment_status', ['unpaid', 'pending', 'failed'])
            ->whereNotIn('fulfilment_status', ['cancelled'])
            ->where('created_at', '<', now()->subHours((int) $this->option('hours')))
            ->with('payments')->each(function (Order $order) use ($payments, $orders, &$count) {
                // Last chance: the customer may have paid and the webhook never arrived.
                foreach ($order->payments as $p) {
                    try { $payments->verifyAndSettle($p->gateway, $p->reference); } catch (\Throwable $e) { report($e); return; } // provider unreachable: leave it for the next run
                }
                $order->refresh();
                if ($order->payment_status === 'paid') return;
                $orders->update($order, ['fulfilment_status' => 'cancelled'], null);
                $order->log('auto_cancelled', 'Unpaid after grace period; stock released.');
                $count++;
            });
        $this->info("Released {$count} stale orders.");
        return self::SUCCESS;
    }
}
