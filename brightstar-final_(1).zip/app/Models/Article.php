<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Article extends Model
{
    protected $guarded = [];
    protected $casts = ['is_published' => 'boolean', 'published_at' => 'datetime'];

    public function products(): BelongsToMany
    {
        return $this->belongsToMany(Product::class)->withPivot('sort_order', 'pos_x', 'pos_y')->orderByPivot('sort_order');
    }

    public function scopeLive(Builder $q): Builder
    {
        return $q->where('is_published', true)->where(fn ($w) => $w->whereNull('published_at')->orWhere('published_at', '<=', now()));
    }

    public function coverUrl(): ?string { return $this->cover_image ? \App\Support\Media::url($this->cover_image) : null; }
}
