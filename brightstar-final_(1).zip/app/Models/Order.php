<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    protected $guarded = [];
    protected $casts = [
        'shipping_address' => 'array',
        'billing_address' => 'array',
        'whatsapp_handoff_at' => 'datetime',
    ];

    public function items(): HasMany { return $this->hasMany(OrderItem::class); }
    public function payments(): HasMany { return $this->hasMany(Payment::class); }
    public function logs(): HasMany { return $this->hasMany(OrderLog::class); }

    public static function generateNumber(): string
    {
        do {
            $prefix = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) Setting::get('order_prefix', 'BGF'))) ?: 'ORD';
            $number = $prefix.'-'.now()->format('ymd').'-'.strtoupper(\Illuminate\Support\Str::random(5));
        } while (static::where('number', $number)->exists());
        return $number;
    }

    public function log(string $event, ?string $note = null, ?int $userId = null): void
    {
        $this->logs()->create(['event' => $event, 'note' => $note, 'user_id' => $userId]);
    }
}
