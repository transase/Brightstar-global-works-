<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Crypt;

class Setting extends Model
{
    protected $guarded = [];

    public static function get(string $key, mixed $default = null): mixed
    {
        $all = Cache::rememberForever('settings.all', fn () => static::pluck('value', 'key')->all());
        $v = $all[$key] ?? null;
        return ($v === null || $v === '') ? $default : $v; // empty means "use the default"
    }

    public static function put(string $key, ?string $value): void
    {
        static::updateOrCreate(['key' => $key], ['value' => $value]);
        Cache::forget('settings.all');
    }

    /** Secrets (API keys, SMTP password) are stored encrypted with APP_KEY under a "secret." prefix. */
    public static function secret(string $key): ?string
    {
        $raw = static::get('secret.'.$key);
        if (! $raw) return null;
        try { return Crypt::decryptString($raw); } catch (DecryptException) { return null; } // e.g. APP_KEY changed: re-enter the value
    }

    public static function putSecret(string $key, ?string $value): void
    {
        static::put('secret.'.$key, filled($value) ? Crypt::encryptString($value) : null);
    }

    public static function hasSecret(string $key): bool { return static::secret($key) !== null; }
}
