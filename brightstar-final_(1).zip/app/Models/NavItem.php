<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Cache;

class NavItem extends Model
{
    protected $guarded = [];
    protected $casts = ['is_visible' => 'boolean', 'is_featured' => 'boolean'];

    public function children(): HasMany { return $this->hasMany(NavItem::class, 'parent_id')->where('is_visible', true)->orderBy('sort_order'); }

    protected static function booted(): void
    {
        $forget = fn () => Cache::forget('nav.tree');
        static::saved($forget);
        static::deleted($forget);
    }

    /** Visible top-level items with visible children, cached. Empty collection means "use the built-in default menu". */
    public static function tree()
    {
        return Cache::rememberForever('nav.tree', fn () => static::whereNull('parent_id')->where('is_visible', true)
            ->orderBy('sort_order')->with('children')->get());
    }

    public function imageUrl(): ?string { return $this->image ? \App\Support\Media::url($this->image) : null; }
}
