<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class NewsletterSubscriber extends Model
{
    protected $guarded = [];
    protected $casts = ['unsubscribed_at' => 'datetime'];

    protected static function booted(): void
    {
        static::creating(fn ($s) => $s->token ??= Str::random(40));
    }

    public function scopeActive(Builder $q): Builder { return $q->whereNull('unsubscribed_at'); }

    /** Rows created before tokens existed get one on demand. */
    public function ensureToken(): string
    {
        if (! $this->token) $this->forceFill(['token' => Str::random(40)])->save();
        return $this->token;
    }
}
