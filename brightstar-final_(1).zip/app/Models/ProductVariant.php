<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductVariant extends Model
{
    protected $guarded = [];
    protected $casts = ['is_active' => 'boolean'];

    public function product(): BelongsTo { return $this->belongsTo(Product::class); }

    public function label(): string
    {
        return collect([$this->colour, $this->size, $this->finish, $this->upholstery])->filter()->implode(' / ');
    }
}
