<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $guarded = [];
    protected $casts = ['starts_at' => 'datetime', 'expires_at' => 'datetime', 'is_active' => 'boolean'];

    public function isUsable(int $subtotal): bool
    {
        return $this->is_active
            && (! $this->starts_at || $this->starts_at->isPast())
            && (! $this->expires_at || $this->expires_at->isFuture())
            && ($this->max_uses === null || $this->used_count < $this->max_uses)
            && $subtotal >= $this->min_subtotal;
    }

    public function discountFor(int $subtotal): int
    {
        $amount = $this->type === 'percent' ? intdiv($subtotal * min(100, $this->value), 100) : $this->value;
        return min($amount, $subtotal);
    }
}
