<?php

namespace App\Models;

use App\Support\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Collection extends Model
{
    protected $guarded = [];
    protected $casts = ['is_active' => 'boolean', 'is_featured' => 'boolean'];

    public function products(): BelongsToMany { return $this->belongsToMany(Product::class); }

    public function imageUrl(): ?string { return $this->image ? Media::url($this->image) : null; }
}
