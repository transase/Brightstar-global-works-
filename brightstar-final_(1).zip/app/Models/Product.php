<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Product extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'track_stock' => 'boolean',
        'allow_backorder' => 'boolean',
        'enquiry_only' => 'boolean',
        'is_featured' => 'boolean',
        'is_best_seller' => 'boolean',
        'is_new_arrival' => 'boolean',
        'assembly_required' => 'boolean',
        'specs' => 'array',
    ];

    protected static function booted(): void
    {
        static::creating(function (Product $p) {
            $p->slug = $p->slug ?: static::uniqueSlug($p->name);
        });
    }

    public static function uniqueSlug(string $name): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $i = 2;
        while (static::where('slug', $slug)->exists()) {
            $slug = $base.'-'.$i++;
        }
        return $slug;
    }

    public function category(): BelongsTo { return $this->belongsTo(Category::class); }
    public function images(): HasMany { return $this->hasMany(ProductImage::class)->orderBy('sort_order'); }
    public function variants(): HasMany { return $this->hasMany(ProductVariant::class); }
    public function reviews(): HasMany { return $this->hasMany(Review::class); }
    public function collections(): BelongsToMany { return $this->belongsToMany(Collection::class); }
    public function related(): BelongsToMany
    {
        return $this->belongsToMany(Product::class, 'product_related', 'product_id', 'related_id');
    }

    public function scopePublished(Builder $q): Builder { return $q->where('status', 'published'); }

    /** Price in minor units currently charged for the base product. */
    public function currentPrice(): int
    {
        return (int) ($this->sale_price !== null && $this->sale_price < $this->price ? $this->sale_price : $this->price);
    }

    public function isOnSale(): bool
    {
        return $this->sale_price !== null && $this->sale_price < $this->price;
    }

    public function discountPercent(): ?int
    {
        return $this->isOnSale() ? (int) round((1 - $this->sale_price / $this->price) * 100) : null;
    }

    /** Unit price for a variant (or the base product when no variant). */
    public function priceFor(?ProductVariant $variant): int
    {
        return max(0, $this->currentPrice() + ($variant?->price_adjustment ?? 0));
    }

    public function availableStock(?ProductVariant $variant = null): int
    {
        return (int) ($variant ? $variant->stock_quantity : $this->stock_quantity);
    }

    public function canBePurchased(int $qty, ?ProductVariant $variant = null): bool
    {
        if ($this->status !== 'published' || $this->enquiry_only) return false;
        if ($variant && (! $variant->is_active || $variant->product_id !== $this->id)) return false;
        if (! $this->track_stock || $this->allow_backorder) return true;
        return $this->availableStock($variant) >= $qty;
    }

    public function stockLabel(): string
    {
        if ($this->enquiry_only) return 'Price on request';
        if (! $this->track_stock || $this->stock_quantity > 5) return 'In stock';
        if ($this->stock_quantity > 0) return 'Only '.$this->stock_quantity.' left';
        return $this->allow_backorder ? 'Available on backorder' : 'Out of stock';
    }

    public function imageUrl(): string
    {
        return $this->main_image ? \App\Support\Media::url($this->main_image) : asset('images/placeholder-furniture.svg');
    }

    /** Smaller image for grids. */
    public function cardImageUrl(): string
    {
        return $this->main_image ? \App\Support\Media::url(\App\Services\ImageStore::thumb($this->main_image)) : asset('images/placeholder-furniture.svg');
    }

    /** Average of approved review ratings (null when none). */
    public function averageRating(): ?float
    {
        $avg = $this->reviews()->where('status', 'approved')->avg('rating');
        return $avg ? round((float) $avg, 1) : null;
    }

    /** Parse "Label: value" lines (one per line) into the specs array. */
    public static function parseSpecs(?string $text): array
    {
        $out = [];
        foreach (preg_split('/\R/', (string) $text) as $line) {
            if (! str_contains($line, ':')) continue;
            [$k, $v] = array_map('trim', explode(':', $line, 2));
            if ($k !== '' && $v !== '' && count($out) < 30) $out[mb_substr($k, 0, 60)] = mb_substr($v, 0, 200);
        }
        return $out;
    }
}
