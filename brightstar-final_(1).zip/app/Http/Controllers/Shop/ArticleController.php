<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Article;

class ArticleController extends Controller
{
    public function index()
    {
        return view('shop.ideas', ['articles' => Article::live()->latest('published_at')->paginate(9)]);
    }

    public function show(string $slug)
    {
        $article = Article::live()->where('slug', $slug)->firstOrFail();
        // Only products that are currently published are shoppable.
        $products = $article->products()->where('status', 'published')->get();
        return view('shop.idea', ['article' => $article, 'products' => $products]);
    }
}
