<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Services\CartService;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    public function orders(Request $r)
    {
        return view('account.orders', ['orders' => Order::where('user_id', $r->user()->id)->latest()->paginate(10)]);
    }

    public function show(Request $r, string $number)
    {
        $order = Order::where('user_id', $r->user()->id)->where('number', $number)->with('items')->firstOrFail();
        return view('account.order', ['order' => $order]);
    }

    /** Re-adds whatever is still available at CURRENT prices and stock; reports the rest. */
    public function reorder(Request $r, string $number, CartService $cart)
    {
        $order = Order::where('user_id', $r->user()->id)->where('number', $number)->with('items')->firstOrFail();
        $added = 0;
        $skipped = [];
        foreach ($order->items as $i) {
            $product = $i->product_id ? Product::find($i->product_id) : null;
            $variant = $i->variant_id ? ProductVariant::find($i->variant_id) : null;
            if (! $product || ($i->variant_id && ! $variant) || ! $product->canBePurchased($i->quantity, $variant)) {
                $skipped[] = $i->name;
                continue;
            }
            try { $cart->add($product, $variant?->id, $i->quantity); $added++; }
            catch (\Symfony\Component\HttpKernel\Exception\HttpException) { $skipped[] = $i->name; }
        }
        $msg = "{$added} item(s) added to your cart at current prices.";
        if ($skipped) $msg .= ' Unavailable right now: '.implode(', ', $skipped).'.';
        return redirect()->route('cart.show')->with($added ? 'status' : 'error', $msg);
    }
}
