<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;

class SeoController extends Controller
{
    public function sitemap()
    {
        $urls = [[route('home'), null], [route('shop'), null]];
        foreach (Category::where('is_active', true)->get(['slug', 'updated_at']) as $c) $urls[] = [route('category.show', $c->slug), $c->updated_at];
        foreach (Product::published()->get(['slug', 'updated_at']) as $p) $urls[] = [route('product.show', $p->slug), $p->updated_at];

        foreach (\App\Models\Article::live()->get(['slug', 'updated_at']) as $a) $urls[] = [route('ideas.show', $a->slug), $a->updated_at];

        $xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        foreach ($urls as [$loc, $mod]) {
            $xml .= '<url><loc>'.e($loc).'</loc>'.($mod ? '<lastmod>'.$mod->toAtomString().'</lastmod>' : '').'</url>';
        }
        return response($xml.'</urlset>', 200, ['Content-Type' => 'application/xml']);
    }

    public function robots()
    {
        $txt = "User-agent: *\nDisallow: /admin\nDisallow: /cart\nDisallow: /checkout\nDisallow: /order/\nDisallow: /payment/\nDisallow: /webhooks/\n\nSitemap: ".route('sitemap')."\n";
        return response($txt, 200, ['Content-Type' => 'text/plain']);
    }
}
