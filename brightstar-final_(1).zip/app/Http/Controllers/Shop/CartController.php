<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\CartService;
use App\Services\WhatsAppService;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function __construct(private CartService $cart) {}

    public function show(WhatsAppService $wa)
    {
        $totals = $this->cart->calculate();
        return view('shop.cart', [
            'totals' => $totals,
            'waLink' => $totals['lines'] ? $wa->link($wa->cartMessage($totals, route('cart.show'))) : null,
        ]);
    }

    public function add(Request $request, Product $product)
    {
        $data = $request->validate(['variant_id' => 'nullable|integer', 'quantity' => 'required|integer|min:1|max:99']);
        $this->cart->add($product, $data['variant_id'] ?? null, $data['quantity']);

        return $request->input('buy_now')
            ? redirect()->route('checkout.show')
            : back()->with('status', "{$product->name} added to your cart.");
    }

    public function update(Request $request, int $item)
    {
        if ($request->filled('variant_id')) {
            $this->cart->changeVariant($item, (int) $request->input('variant_id'));
        } else {
            $this->cart->setQuantity($item, (int) $request->input('quantity'));
        }
        return back();
    }

    public function remove(int $item)
    {
        $this->cart->remove($item);
        return back();
    }

    public function coupon(Request $request)
    {
        $ok = $this->cart->applyCoupon($request->input('code'));
        return back()->with($ok ? 'status' : 'error', $ok ? 'Coupon updated.' : 'That coupon is not valid for this cart.');
    }
}
