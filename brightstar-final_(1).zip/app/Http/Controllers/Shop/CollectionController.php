<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Collection;

class CollectionController extends Controller
{
    public function index()
    {
        return view('shop.collections', ['collections' => Collection::where('is_active', true)->orderBy('sort_order')->withCount('products')->get()]);
    }

    public function show(string $slug)
    {
        $collection = Collection::where('is_active', true)->where('slug', $slug)->firstOrFail();
        $products = $collection->products()->where('status', 'published')->with(['category', 'variants'])->latest('products.created_at')->paginate(12);
        return view('shop.collection', ['collection' => $collection, 'products' => $products]);
    }
}
