<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\DeliveryZone;
use App\Models\Order;
use App\Models\Setting;
use App\Services\CartService;
use App\Services\CheckoutService;
use App\Services\PaymentService;
use App\Services\WhatsAppService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use RuntimeException;

class CheckoutController extends Controller
{
    public function __construct(private CartService $cart, private CheckoutService $checkout, private PaymentService $payments) {}

    private function methods(WhatsAppService $wa): array
    {
        $methods = [];
        foreach ($this->payments->enabledGateways() as $name => $g) $methods[$name] = ucfirst($name).' (card, bank, USSD)';
        if (Setting::get('cod_enabled')) $methods['cod'] = 'Cash on delivery';
        if (Setting::get('bank_transfer_enabled')) $methods['bank_transfer'] = 'Bank transfer (manual review)';
        if ($wa->phone()) $methods['whatsapp'] = 'Complete order on WhatsApp';
        return $methods;
    }

    public function show(WhatsAppService $wa)
    {
        $zones = DeliveryZone::where('is_active', true)->get();
        $totals = $this->cart->calculate();
        if (! $totals['lines']) return redirect()->route('cart.show')->with('error', 'Your cart is empty.');
        return view('shop.checkout', ['totals' => $totals, 'zones' => $zones, 'methods' => $this->methods($wa)]);
    }

    public function store(Request $request, WhatsAppService $wa)
    {
        $methods = $this->methods($wa);
        $data = $request->validate([
            'first_name' => 'required|string|max:80',
            'last_name' => 'required|string|max:80',
            'email' => 'required|email|max:160',
            'phone' => ['required', 'string', 'max:32', 'regex:/^[0-9+\s\-()]{7,}$/'],
            'address' => 'required|string|max:255',
            'city' => 'required|string|max:100',
            'state' => 'required|string|max:100',
            'postal_code' => 'nullable|string|max:20',
            'country' => 'required|string|max:100',
            // When delivery areas exist, one must be chosen: otherwise a tampered request could skip the delivery fee.
            'delivery_zone_id' => [Rule::requiredIf(fn () => DeliveryZone::where('is_active', true)->exists()), 'nullable', 'integer', Rule::exists('delivery_zones', 'id')->where('is_active', true)],
            'delivery_instructions' => 'nullable|string|max:1000',
            'payment_method' => ['required', Rule::in(array_keys($methods))],
        ]);

        // Billing details only when different from delivery.
        $data['billing_address'] = null;
        if (! $request->boolean('billing_same', true)) {
            $b = $request->validate([
                'billing.address' => 'required|string|max:255', 'billing.city' => 'required|string|max:100', 'billing.state' => 'required|string|max:100',
                'billing.postal_code' => 'nullable|string|max:20', 'billing.country' => 'required|string|max:100',
            ]);
            $data['billing_address'] = $b['billing'];
        }

        try {
            $order = $this->checkout->placeOrder($data, $data['payment_method'], $data['payment_method'] === 'whatsapp' ? 'whatsapp' : 'web');
        } catch (RuntimeException $e) {
            return back()->withInput()->with('error', $e->getMessage());
        }

        session(['order_access.'.$order->number => true]);
        app(\App\Services\OrderNotifier::class)->placed($order);
        $method = $data['payment_method'];
        if (isset($this->payments->gateways()[$method])) {
            try {
                return redirect()->away($this->payments->start($order, $method));
            } catch (\Throwable $e) {
                report($e);
                return redirect()->route('order.show', $order->number)->with('error', 'We could not reach the payment provider. Your order is saved; you can retry payment.');
            }
        }

        return redirect()->route('order.show', $order->number)->with('placed', true);
    }

    /** Shows the order status. WhatsApp orders get a button to open the chat (handoff is recorded on click). */
    public function order(string $number, WhatsAppService $wa)
    {
        $order = Order::where('number', $number)->with('items')->firstOrFail();
        // Order numbers contain a random suffix; additionally require the session or owner.
        // Access: same browser session, the owner, or a signed link sent by staff (e.g. a pay-later link on WhatsApp).
        if (request()->hasValidSignature()) session(['order_access.'.$number => true]);
        abort_unless(session('order_access.'.$number) || (auth()->check() && auth()->id() === $order->user_id), 404);

        $waLink = null;
        if ($order->payment_method === 'whatsapp') {
            $totals = ['lines' => $order->items->map(fn ($i) => [
                'name' => $i->name, 'variant_label' => $i->variant_label, 'quantity' => $i->quantity, 'line_total' => $i->line_total,
            ])->all(), 'subtotal' => $order->subtotal, 'discount' => $order->discount, 'tax' => $order->tax, 'delivery_fee' => $order->delivery_fee, 'total' => $order->total];
            $waLink = $wa->link($wa->cartMessage($totals, route('order.show', $order->number), $order));
        }
        $payable = ! in_array($order->payment_status, ['paid', 'partially_refunded', 'refunded'], true) && $order->fulfilment_status !== 'cancelled';
        return view('shop.order', [
            'order' => $order, 'waLink' => $waLink,
            'payGateways' => $payable ? array_keys($this->payments->enabledGateways()) : [],
            'bankDetails' => $order->payment_method === 'bank_transfer' ? \App\Models\Setting::get('bank_transfer_details') : null,
        ]);
    }

    public function whatsappHandoff(string $number)
    {
        $order = Order::where('number', $number)->firstOrFail();
        abort_unless(session('order_access.'.$number), 404);
        $order->update(['whatsapp_handoff_at' => now()]);
        $order->log('whatsapp_handoff_attempted', 'Customer opened WhatsApp. Not proof the message was sent.');
        return response()->noContent();
    }

    /** Start (or retry) an online payment for an existing unpaid order. */
    public function pay(string $number, string $gateway)
    {
        $order = Order::where('number', $number)->firstOrFail();
        abort_unless(session('order_access.'.$number) || (auth()->check() && auth()->id() === $order->user_id), 404);
        abort_if(in_array($order->payment_status, ['paid', 'partially_refunded', 'refunded'], true) || $order->fulfilment_status === 'cancelled', 409, 'This order cannot be paid online.');

        try {
            return redirect()->away($this->payments->start($order, $gateway));
        } catch (\InvalidArgumentException $e) {
            return back()->with('error', $e->getMessage());
        } catch (\Throwable $e) {
            report($e);
            return back()->with('error', 'We could not reach the payment provider. Please try again in a moment.');
        }
    }
}
