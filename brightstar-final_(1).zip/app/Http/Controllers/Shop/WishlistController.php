<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Wishlist;
use Illuminate\Http\Request;

class WishlistController extends Controller
{
    public function index(Request $r)
    {
        $products = Product::published()->whereIn('id', Wishlist::where('user_id', $r->user()->id)->pluck('product_id'))->get();
        return view('shop.wishlist', ['products' => $products]);
    }

    public function toggle(Request $r, Product $product)
    {
        $row = Wishlist::where(['user_id' => $r->user()->id, 'product_id' => $product->id]);
        if ($row->exists()) { $row->delete(); $msg = 'Removed from your wishlist.'; }
        else { Wishlist::create(['user_id' => $r->user()->id, 'product_id' => $product->id]); $msg = 'Saved to your wishlist.'; }
        return back()->with('status', $msg);
    }
}
