<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Page;

class PageController extends Controller
{
    public function show(string $slug)
    {
        $page = Page::where('slug', $slug)->where('is_published', true)->first();
        // About/Contact always exist (with store details) even before the owner writes content.
        abort_unless($page || in_array($slug, ['about', 'contact'], true), 404);
        $page ??= new Page(['slug' => $slug, 'title' => $slug === 'about' ? 'About Us' : 'Contact Us']);
        return view('shop.page', ['page' => $page]);
    }
}
