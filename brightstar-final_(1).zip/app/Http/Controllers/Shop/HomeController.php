<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;

class HomeController extends Controller
{
    public function __invoke()
    {
        $products = fn () => Product::published()->with(['category', 'variants']);
        return view('shop.home', [
            'heroSlides' => \App\Models\Slide::live('hero')->get(),
            'ideas' => \App\Models\Article::live()->latest('published_at')->take(3)->get(),
            'promos' => \App\Models\Slide::live('promo')->get(),
            // Admin-chosen "featured" categories (any level); falls back to top-level categories.
            'categories' => (function () {
                $featured = Category::where('is_active', true)->where('is_featured', true)->orderBy('sort_order')->take(12)->get();
                return $featured->isNotEmpty() ? $featured : Category::where('is_active', true)->whereNull('parent_id')->orderBy('sort_order')->get();
            })(),
            'rooms' => Category::where('is_active', true)->whereIn('slug', ['living-room', 'bedroom', 'dining-room', 'office-furniture', 'outdoor-furniture'])->get()->sortBy(fn ($c) => array_search($c->slug, ['living-room', 'bedroom', 'dining-room', 'office-furniture', 'outdoor-furniture']))->values(),
            'benefits' => \App\Models\Benefit::where('is_active', true)->orderBy('sort_order')->get(),
            'collections' => \App\Models\Collection::where('is_active', true)->where('is_featured', true)->orderBy('sort_order')->take(4)->get(),
            'testimonials' => \App\Models\Review::where('status', 'approved')->where('rating', '>=', 4)->whereNotNull('body')->latest()->take(3)->get(),
            'featured' => $products()->where('is_featured', true)->latest()->take(8)->get(),
            'newArrivals' => $products()->where('is_new_arrival', true)->latest()->take(4)->get(),
            // Best sellers: manual flag OR real sales data.
            'bestSellers' => $products()->where(fn ($q) => $q->where('is_best_seller', true)->orWhere('sales_count', '>', 0))
                ->orderByDesc('sales_count')->take(4)->get(),
        ]);
    }
}
