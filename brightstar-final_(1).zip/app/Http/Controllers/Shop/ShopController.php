<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Services\WhatsAppService;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function index(Request $request, ?Category $category = null)
    {
        $q = Product::published()->with(['category', 'variants']);

        if ($category) {
            abort_unless($category->is_active, 404);
            $q->whereIn('category_id', $category->descendantIds());
        }

        if ($term = trim((string) $request->query('q'))) app(\App\Services\Search\ProductSearch::class)->apply($q, $term);
        if ($request->filled('category')) {
            $c = Category::where('slug', $request->query('category'))->first();
            if ($c) $q->whereIn('category_id', $c->descendantIds());
        }
        if ($request->filled('min_price')) $q->whereRaw('COALESCE(sale_price, price) >= ?', [(int) ($request->query('min_price') * 100)]);
        if ($request->filled('max_price')) $q->whereRaw('COALESCE(sale_price, price) <= ?', [(int) ($request->query('max_price') * 100)]);
        if ($request->filled('collection')) $q->whereHas('collections', fn ($c) => $c->where('slug', $request->query('collection'))->where('is_active', true));
        if ($request->filled('material')) $q->where('material', $request->query('material'));
        if ($request->filled('colour')) $q->whereHas('variants', fn ($v) => $v->where('colour', $request->query('colour'))->where('is_active', true));
        if ($request->filled('size')) $q->whereHas('variants', fn ($v) => $v->where('size', $request->query('size'))->where('is_active', true));
        if ($request->boolean('in_stock')) $q->where(fn ($w) => $w->where('track_stock', false)->orWhere('stock_quantity', '>', 0));
        if ($request->boolean('on_sale')) $q->whereNotNull('sale_price')->whereColumn('sale_price', '<', 'price');

        match ($request->query('sort')) {
            'price_asc' => $q->orderByRaw('COALESCE(sale_price, price) asc'),
            'price_desc' => $q->orderByRaw('COALESCE(sale_price, price) desc'),
            'popular' => $q->orderByDesc('sales_count'),
            'name' => $q->orderBy('name'),
            default => $q->latest(),
        };

        return view('shop.index', [
            'category' => $category,
            'products' => $q->paginate(12)->withQueryString(),
            'categories' => Category::where('is_active', true)->whereNull('parent_id')->with('children')->orderBy('sort_order')->get(),
            'materials' => Product::published()->whereNotNull('material')->distinct()->pluck('material'),
            'view' => $request->query('view') === 'list' ? 'list' : 'grid',
            'colours' => \App\Models\ProductVariant::where('is_active', true)->whereNotNull('colour')->distinct()->orderBy('colour')->pluck('colour'),
            'sizes' => \App\Models\ProductVariant::where('is_active', true)->whereNotNull('size')->distinct()->orderBy('size')->pluck('size'),
            'collections' => \App\Models\Collection::where('is_active', true)->orderBy('sort_order')->get(['slug', 'name']),
        ]);
    }

    public function show(Product $product, WhatsAppService $wa)
    {
        abort_unless($product->status === 'published', 404);
        $product->load(['images', 'variants' => fn ($v) => $v->where('is_active', true), 'category', 'related']);

        $reviews = $product->reviews()->where('status', 'approved')->latest()->take(10)->get();
        $recent = collect(session('recently_viewed', []))->reject(fn ($id) => $id === $product->id)->take(4);
        session(['recently_viewed' => collect([$product->id])->merge($recent)->unique()->take(8)->values()->all()]);

        return view('shop.product', [
            'product' => $product,
            'reviews' => $reviews,
            'recentlyViewed' => Product::published()->whereIn('id', $recent)->get(),
            'waLink' => $wa->link($wa->productMessage($product, $product->variants->first(), 1, route('product.show', $product))),
        ]);
    }

    /** Builds the WhatsApp message from the selected variant/quantity on the server, then redirects to wa.me. */
    public function whatsapp(Request $request, Product $product, WhatsAppService $wa)
    {
        abort_unless($product->status === 'published', 404);
        $variant = $request->filled('variant') ? $product->variants()->where('is_active', true)->find($request->query('variant')) : null;
        $qty = max(1, min(99, (int) $request->query('qty', 1)));
        $link = $wa->link($wa->productMessage($product, $variant, $qty, route('product.show', $product)));
        abort_unless($link, 404);
        return redirect()->away($link);
    }

    /** HTML fragment for the quick-view modal. */
    public function quick(Product $product)
    {
        abort_unless($product->status === 'published', 404);
        return view('shop.quick', ['product' => $product->load('variants')]);
    }
}
