<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function __construct(private PaymentService $payments) {}

    /** Browser return URL. Success is decided ONLY by server-side verification. */
    public function callback(Request $request, string $gateway)
    {
        $reference = $request->query('reference') ?? $request->query('trxref') ?? $request->query('tx_ref');
        abort_unless($reference, 400);

        try {
            $payment = $this->payments->verifyAndSettle($gateway, (string) $reference);
        } catch (\Throwable $e) {
            report($e);
            $payment = Payment::where('reference', $reference)->first();
        }
        abort_unless($payment, 404);

        session(['order_access.'.$payment->order->number => true]);
        return redirect()->route('order.show', $payment->order->number)
            ->with($payment->status === 'successful' ? 'status' : 'error',
                $payment->status === 'successful' ? 'Payment confirmed. Thank you!' : 'We could not confirm your payment yet. If you were charged, it will update shortly.');
    }

    public function webhook(Request $request, string $gateway)
    {
        $g = $this->payments->gateway($gateway);
        if (! $g->validWebhookSignature($request)) abort(401);

        $parsed = $g->parseWebhook($request);
        if (! $parsed['reference'] || ! $this->payments->claimWebhookEvent($gateway, $parsed)) {
            return response()->json(['ok' => true]); // duplicate or irrelevant: acknowledge without reprocessing
        }

        try {
            $this->payments->verifyAndSettle($gateway, $parsed['reference']);
        } catch (\Throwable $e) {
            report($e);
            \App\Models\PaymentEvent::where('gateway', $gateway)->where('event_id', $parsed['event_id'].':'.$parsed['type'])->delete();
            return response()->json(['ok' => false], 500); // let the provider retry
        }
        return response()->json(['ok' => true]);
    }
}
