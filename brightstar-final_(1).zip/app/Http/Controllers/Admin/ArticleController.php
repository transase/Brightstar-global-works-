<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Product;
use App\Services\ImageStore;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ArticleController extends Controller
{
    public function index() { return view('admin.articles.index', ['articles' => Article::latest()->get()]); }

    public function create() { return view('admin.articles.form', ['article' => new Article, 'products' => Product::orderBy('name')->get(['id', 'name', 'sku'])]); }

    public function edit(Article $article)
    {
        return view('admin.articles.form', ['article' => $article->load('products'), 'products' => Product::orderBy('name')->get(['id', 'name', 'sku'])]);
    }

    public function store(Request $r) { return $this->save($r, new Article); }
    public function update(Request $r, Article $article) { return $this->save($r, $article); }

    private function save(Request $r, Article $article)
    {
        $d = $r->validate([
            'title' => 'required|string|max:200',
            'slug' => ['nullable', 'string', 'max:220', Rule::unique('articles', 'slug')->ignore($article->id)],
            'excerpt' => 'nullable|string|max:400', 'body' => 'nullable|string|max:100000',
            'seo_description' => 'nullable|string|max:300', 'published_at' => 'nullable|date',
            'cover_image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'products' => 'nullable|array|max:12', 'products.*' => 'integer|exists:products,id',
            'hotspots' => 'nullable|array', 'hotspots.*.x' => 'nullable|numeric|between:0,100', 'hotspots.*.y' => 'nullable|numeric|between:0,100',
        ]);
        $d['slug'] = Str::slug($d['slug'] ?: $d['title']);
        $d['is_published'] = $r->boolean('is_published');
        if ($d['is_published'] && empty($d['published_at'])) $d['published_at'] = now();
        if ($r->hasFile('cover_image')) {
            ImageStore::delete($article->cover_image);
            $d['cover_image'] = ImageStore::put($r->file('cover_image'), 'articles');
        } else unset($d['cover_image']);
        $ids = $d['products'] ?? [];
        $hot = $d['hotspots'] ?? [];
        unset($d['products'], $d['hotspots']);

        $article->fill($d)->save();
        $article->products()->sync(collect($ids)->values()->mapWithKeys(function ($id, $i) use ($hot) {
            $x = $hot[$id]['x'] ?? null;
            $y = $hot[$id]['y'] ?? null;
            $pinned = $x !== null && $x !== '' && $y !== null && $y !== '';
            return [$id => ['sort_order' => $i, 'pos_x' => $pinned ? round((float) $x, 2) : null, 'pos_y' => $pinned ? round((float) $y, 2) : null]];
        })->all());
        return redirect()->route('admin.articles.edit', $article)->with('status', 'Article saved.');
    }

    public function destroy(Article $article)
    {
        ImageStore::delete($article->cover_image);
        $article->delete();
        return redirect()->route('admin.articles.index')->with('status', 'Article deleted.');
    }
}
