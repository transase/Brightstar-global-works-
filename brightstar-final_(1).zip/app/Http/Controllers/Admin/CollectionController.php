<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Collection;
use App\Models\Product;
use App\Services\ImageStore;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class CollectionController extends Controller
{
    private function page(Collection $collection)
    {
        return view('admin.collections', [
            'collections' => Collection::orderBy('sort_order')->withCount('products')->get(),
            'collection' => $collection->exists ? $collection->load('products') : $collection,
            'products' => Product::orderBy('name')->get(['id', 'name', 'sku']),
        ]);
    }

    public function index() { return $this->page(new Collection(['is_active' => true])); }
    public function edit(Collection $collection) { return $this->page($collection); }
    public function store(Request $r) { return $this->save($r, new Collection); }
    public function update(Request $r, Collection $collection) { return $this->save($r, $collection); }

    private function save(Request $r, Collection $c)
    {
        $d = $r->validate([
            'name' => 'required|string|max:120',
            'slug' => ['nullable', 'string', 'max:140', Rule::unique('collections', 'slug')->ignore($c->id)],
            'description' => 'nullable|string|max:2000', 'seo_title' => 'nullable|string|max:160', 'seo_description' => 'nullable|string|max:300',
            'sort_order' => 'nullable|integer|min:0',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'products' => 'nullable|array', 'products.*' => 'integer|exists:products,id',
        ]);
        $ids = $d['products'] ?? [];
        unset($d['products']);
        $d['slug'] = Str::slug($d['slug'] ?: $d['name']);
        $d['sort_order'] = $d['sort_order'] ?? 0;
        $d['is_active'] = $r->boolean('is_active');
        $d['is_featured'] = $r->boolean('is_featured');
        if ($r->hasFile('image')) { ImageStore::delete($c->image); $d['image'] = ImageStore::put($r->file('image'), 'collections'); }
        else unset($d['image']);
        $c->fill($d)->save();
        $c->products()->sync($ids);
        return redirect()->route('admin.collections.index')->with('status', 'Collection saved.');
    }

    public function destroy(Collection $collection)
    {
        ImageStore::delete($collection->image);
        $collection->delete();
        return back()->with('status', 'Collection deleted.');
    }
}
