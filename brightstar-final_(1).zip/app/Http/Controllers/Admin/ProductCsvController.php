<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ProductCsvController extends Controller
{
    private const COLUMNS = ['sku', 'name', 'category_slug', 'price', 'sale_price', 'cost_price', 'stock_quantity', 'status', 'short_description', 'material', 'finish'];

    public function export()
    {
        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');
            fputcsv($out, self::COLUMNS);
            Product::with('category')->orderBy('id')->chunk(200, function ($chunk) use ($out) {
                foreach ($chunk as $p) {
                    fputcsv($out, [
                        $this->safe($p->sku), $this->safe($p->name), $p->category?->slug, $p->price / 100, $p->sale_price !== null ? $p->sale_price / 100 : '',
                        $p->cost_price !== null ? $p->cost_price / 100 : '', $p->stock_quantity, $p->status,
                        $this->safe($p->short_description), $this->safe($p->material), $this->safe($p->finish),
                    ]);
                }
            });
            fclose($out);
        }, 'products-'.now()->format('Ymd').'.csv', ['Content-Type' => 'text/csv']);
    }

    /** Neutralise spreadsheet formula injection in exported text cells. */
    private function safe(?string $v): ?string
    {
        return ($v !== null && $v !== '' && str_contains('=+-@', $v[0])) ? "'".$v : $v;
    }

    public function import(Request $r)
    {
        $r->validate(['file' => 'required|file|mimes:csv,txt|max:5120']);
        $h = fopen($r->file('file')->getRealPath(), 'r');
        $header = array_map(fn ($c) => Str::lower(trim((string) $c)), fgetcsv($h) ?: []);
        if (array_diff(['sku', 'name', 'price'], $header)) {
            return back()->with('error', 'The CSV must include at least the columns: sku, name, price.');
        }

        $created = $updated = 0;
        $errors = [];
        $line = 1;
        while (($row = fgetcsv($h)) !== false) {
            $line++;
            if (count($row) !== count($header)) { $errors[] = "Line {$line}: wrong number of columns."; continue; }
            $d = array_combine($header, array_map('trim', $row));

            $v = Validator::make($d, [
                'sku' => 'required|string|max:64', 'name' => 'required|string|max:200', 'price' => 'required|numeric|min:0',
                'sale_price' => 'nullable|numeric|min:0|lt:price', 'cost_price' => 'nullable|numeric|min:0',
                'stock_quantity' => 'nullable|integer|min:0', 'status' => ['nullable', Rule::in(['draft', 'published', 'archived'])],
            ]);
            if ($v->fails()) { $errors[] = "Line {$line} (".($d['sku'] ?? '?')."): ".$v->errors()->first(); continue; }

            $cat = ! empty($d['category_slug']) ? Category::where('slug', $d['category_slug'])->first() : null;
            if (! empty($d['category_slug']) && ! $cat) { $errors[] = "Line {$line} ({$d['sku']}): unknown category '{$d['category_slug']}'."; continue; }

            $attrs = [
                'name' => $d['name'], 'category_id' => $cat?->id, 'price' => (int) round($d['price'] * 100),
                'sale_price' => ($d['sale_price'] ?? '') !== '' ? (int) round($d['sale_price'] * 100) : null,
                'cost_price' => ($d['cost_price'] ?? '') !== '' ? (int) round($d['cost_price'] * 100) : null,
                'stock_quantity' => (int) ($d['stock_quantity'] ?? 0), 'status' => ($d['status'] ?? '') ?: 'draft',
                'short_description' => $d['short_description'] ?? null, 'material' => $d['material'] ?? null, 'finish' => $d['finish'] ?? null,
            ];
            $p = Product::where('sku', $d['sku'])->first();
            if ($p) { $p->update($attrs); $updated++; } else { Product::create($attrs + ['sku' => $d['sku'], 'slug' => Product::uniqueSlug($d['name'])]); $created++; }
        }
        fclose($h);

        return back()->with('status', "Import finished: {$created} created, {$updated} updated, ".count($errors).' rows skipped.')
            ->with('import_errors', $errors);
    }
}
