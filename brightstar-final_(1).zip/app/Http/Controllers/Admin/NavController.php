<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\NavItem;
use App\Services\ImageStore;
use Illuminate\Http\Request;

class NavController extends Controller
{
    public function index()
    {
        return view('admin.nav.index', [
            'tops' => NavItem::whereNull('parent_id')->orderBy('sort_order')->get(),
            'item' => new NavItem(['is_visible' => true]),
        ]);
    }

    public function edit(NavItem $nav)
    {
        return view('admin.nav.index', ['tops' => NavItem::whereNull('parent_id')->orderBy('sort_order')->get(), 'item' => $nav]);
    }

    public function store(Request $r) { return $this->save($r, new NavItem); }
    public function update(Request $r, NavItem $nav) { return $this->save($r, $nav); }

    private function save(Request $r, NavItem $item)
    {
        $d = $r->validate([
            'label' => 'required|string|max:60',
            'url' => ['required', 'string', 'max:500', 'regex:#^(/|https?://)#i'],
            'parent_id' => ['nullable', 'integer', 'exists:nav_items,id'],
            'sort_order' => 'nullable|integer|min:0',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:4096',
        ]);
        // Two levels only (menu + mega-menu column); an item cannot be its own parent or a child of a child.
        if (! empty($d['parent_id'])) {
            $parent = NavItem::find($d['parent_id']);
            if ($parent->parent_id !== null || $parent->id === $item->id) {
                return back()->withInput()->with('error', 'Menu items can be nested one level deep.');
            }
            if ($item->exists && NavItem::where('parent_id', $item->id)->exists()) {
                return back()->withInput()->with('error', 'Move or delete this item\'s sub-items first.');
            }
        }
        $d['is_visible'] = $r->boolean('is_visible');
        $d['is_featured'] = $r->boolean('is_featured');
        $d['sort_order'] = $d['sort_order'] ?? 0;
        if ($r->hasFile('image')) {
            ImageStore::delete($item->image);
            $d['image'] = ImageStore::put($r->file('image'), 'nav');
        } else unset($d['image']);
        $item->fill($d)->save();
        return redirect()->route('admin.nav.index')->with('status', 'Menu saved.');
    }

    public function destroy(NavItem $nav)
    {
        ImageStore::delete($nav->image);
        $nav->delete(); // children cascade
        return back()->with('status', 'Deleted.');
    }

    /** One-click starting point mirroring the original navigation spec. */
    public function defaults()
    {
        if (NavItem::exists()) return back()->with('error', 'Menu items already exist.');
        foreach ([
            ['Shop Furniture', '/shop'], ['Living Room', '/category/living-room'], ['Bedroom', '/category/bedroom'],
            ['Dining Room', '/category/dining-room'], ['Office Furniture', '/category/office-furniture'],
            ['Outdoor Furniture', '/category/outdoor-furniture'], ['Collections', '/shop'], ['New Arrivals', '/shop?sort=newest'],
            ['Best Sellers', '/shop?sort=popular'], ['Offers', '/shop?on_sale=1'], ['About Us', '/about'], ['Contact Us', '/contact'],
        ] as $i => [$label, $url]) NavItem::create(['label' => $label, 'url' => $url, 'sort_order' => $i]);
        return back()->with('status', 'Default menu created. Add sub-items to turn a link into a mega-menu.');
    }
}
