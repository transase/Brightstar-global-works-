<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Review;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function index(Request $r)
    {
        return view('admin.reviews', ['reviews' => Review::where('status', $r->query('status', 'pending'))->latest()->paginate(20)->withQueryString()]);
    }

    public function update(Request $r, Review $review)
    {
        $review->update($r->validate(['status' => 'required|in:approved,rejected,pending']));
        return back()->with('status', 'Review '.$review->status.'.');
    }

    public function destroy(Review $review) { $review->delete(); return back(); }
}
