<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index(Request $r)
    {
        $q = Product::with('category')->latest();
        if ($t = trim((string) $r->query('q'))) $q->where(fn ($w) => $w->where('name', 'like', "%$t%")->orWhere('sku', 'like', "%$t%"));
        if ($r->filled('status')) $q->where('status', $r->query('status'));
        if ($r->filled('category')) $q->where('category_id', $r->query('category'));
        return view('admin.products.index', ['products' => $q->paginate(20)->withQueryString(), 'categories' => Category::orderBy('name')->get()]);
    }

    public function create() { return view('admin.products.form', ['product' => new Product(['status' => 'draft', 'dimension_unit' => 'cm']), 'categories' => Category::orderBy('name')->get()]); }

    public function edit(Product $product)
    {
        $product->load(['images', 'variants', 'related']);
        return view('admin.products.form', ['product' => $product, 'categories' => Category::orderBy('name')->get(), 'all' => Product::where('id', '!=', $product->id)->orderBy('name')->get(['id', 'name', 'sku'])]);
    }

    public function store(Request $r) { return $this->save($r, new Product); }
    public function update(Request $r, Product $product) { return $this->save($r, $product); }

    private function toMinor(mixed $v): ?int { return ($v === null || $v === '') ? null : (int) round(((float) $v) * 100); }

    private function save(Request $r, Product $product)
    {
        $data = $r->validate([
            'name' => 'required|string|max:200',
            'sku' => ['required', 'string', 'max:64', Rule::unique('products', 'sku')->ignore($product->id)],
            'slug' => ['nullable', 'string', 'max:220', Rule::unique('products', 'slug')->ignore($product->id)],
            'category_id' => 'nullable|exists:categories,id',
            'brand' => 'nullable|string|max:120',
            'short_description' => 'nullable|string|max:500', 'description' => 'nullable|string',
            'price' => 'required|numeric|min:0', 'sale_price' => 'nullable|numeric|min:0|lt:price', 'cost_price' => 'nullable|numeric|min:0',
            'stock_quantity' => 'required|integer|min:0',
            'status' => ['required', Rule::in(['draft', 'published', 'archived'])],
            'height' => 'nullable|numeric|min:0', 'width' => 'nullable|numeric|min:0', 'depth' => 'nullable|numeric|min:0',
            'dimension_unit' => ['nullable', Rule::in(['cm', 'mm', 'in', 'm'])], 'weight' => 'nullable|numeric|min:0',
            'material' => 'nullable|string|max:120', 'finish' => 'nullable|string|max:120', 'warranty' => 'nullable|string|max:255',
            'delivery_info' => 'nullable|string|max:1000', 'delivery_timeframe' => 'nullable|string|max:120',
            'seo_title' => 'nullable|string|max:160', 'seo_description' => 'nullable|string|max:300',
            'main_image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'seo_image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'specs_text' => 'nullable|string|max:4000',
            'variants.*.image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'gallery.*' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'variants' => 'nullable|array', 'variants.*.id' => 'nullable|integer',
            'variants.*.sku' => 'nullable|string|max:64|distinct',
            'variants.*.colour' => 'nullable|string|max:80', 'variants.*.size' => 'nullable|string|max:80',
            'variants.*.finish' => 'nullable|string|max:80', 'variants.*.upholstery' => 'nullable|string|max:80',
            'variants.*.price_adjustment' => 'nullable|numeric', 'variants.*.stock_quantity' => 'nullable|integer|min:0',
            'related' => 'nullable|array', 'related.*' => 'integer|exists:products,id',
        ]);

        foreach (['price', 'sale_price', 'cost_price'] as $k) $data[$k] = $this->toMinor($data[$k] ?? null);
        foreach (['track_stock', 'allow_backorder', 'enquiry_only', 'is_featured', 'is_best_seller', 'is_new_arrival', 'assembly_required'] as $k) $data[$k] = $r->boolean($k);
        $data['slug'] = ! empty($data['slug']) ? Str::slug($data['slug']) : ($product->exists ? $product->slug : Product::uniqueSlug($data['name']));
        if ($r->hasFile('main_image')) {
            if ($product->main_image) \App\Services\ImageStore::delete($product->main_image);
            $data['main_image'] = \App\Services\ImageStore::put($r->file('main_image'), 'products');
        } else unset($data['main_image']);
        if ($r->hasFile('seo_image')) {
            \App\Services\ImageStore::delete($product->seo_image);
            $data['seo_image'] = \App\Services\ImageStore::put($r->file('seo_image'), 'products');
        } else unset($data['seo_image']);
        $data['specs'] = Product::parseSpecs($data['specs_text'] ?? null) ?: null;
        unset($data['specs_text']);

        $variants = $data['variants'] ?? [];
        // Variant SKUs must be unique across the store (and not clash with product SKUs).
        foreach ($variants as $v) {
            if (! empty($v['sku'])) {
                $clash = DB::table('product_variants')->where('sku', $v['sku'])->when(! empty($v['id']), fn ($q) => $q->where('id', '!=', $v['id']))->exists()
                    || DB::table('products')->where('sku', $v['sku'])->exists();
                if ($clash) return back()->withInput()->with('error', "Variant SKU {$v['sku']} is already used.");
            }
        }
        unset($data['variants'], $data['gallery'], $data['related']);

        DB::transaction(function () use ($r, $product, $data, $variants) {
            $product->fill($data)->save();

            $keep = [];
            foreach ($variants as $idx => $v) {
                if (! array_filter([$v['colour'] ?? null, $v['size'] ?? null, $v['finish'] ?? null, $v['upholstery'] ?? null])) continue;
                $row = [
                    'sku' => $v['sku'] ?: null, 'colour' => $v['colour'] ?? null, 'size' => $v['size'] ?? null,
                    'finish' => $v['finish'] ?? null, 'upholstery' => $v['upholstery'] ?? null,
                    'price_adjustment' => $this->toMinor($v['price_adjustment'] ?? 0) ?? 0,
                    'stock_quantity' => (int) ($v['stock_quantity'] ?? 0), 'is_active' => true,
                ];
                $model = ! empty($v['id']) ? $product->variants()->find($v['id']) : null;
                if ($file = $r->file("variants.$idx.image")) {
                    \App\Services\ImageStore::delete($model?->image);
                    $row['image'] = \App\Services\ImageStore::put($file, 'products');
                }
                $model ? $model->update($row) : ($model = $product->variants()->create($row));
                $keep[] = $model->id;
            }
            $product->variants()->whereNotIn('id', $keep)->delete();

            foreach ($r->file('gallery', []) as $i => $file) {
                $product->images()->create(['path' => \App\Services\ImageStore::put($file, 'products'), 'sort_order' => $product->images()->count() + $i]);
            }
            $product->related()->sync($r->input('related', []));
        });

        return redirect()->route('admin.products.edit', $product)->with('status', 'Product saved.');
    }

    public function destroy(Product $product)
    {
        $product->images->each(fn ($i) => \App\Services\ImageStore::delete($i->path));
        $product->delete(); // order history keeps its own snapshots
        return redirect()->route('admin.products.index')->with('status', 'Product deleted.');
    }

    public function duplicate(Product $product)
    {
        $copy = DB::transaction(function () use ($product) {
            $copy = $product->replicate(['slug', 'sku', 'sales_count']);
            $copy->name = $product->name.' (copy)';
            $copy->slug = Product::uniqueSlug($copy->name);
            $copy->sku = $product->sku.'-COPY'.Str::upper(Str::random(3));
            $copy->status = 'draft';
            $copy->sales_count = 0;
            $copy->save();
            foreach ($product->variants as $v) {
                $copy->variants()->create($v->replicate(['sku', 'product_id'])->toArray());
            }
            return $copy;
        });
        return redirect()->route('admin.products.edit', $copy)->with('status', 'Product duplicated as a draft. Update its SKU and name.');
    }

    public function deleteImage(Product $product, ProductImage $image)
    {
        abort_unless($image->product_id === $product->id, 404);
        \App\Services\ImageStore::delete($image->path);
        $image->delete();
        return back()->with('status', 'Image removed.');
    }

    /** Move a gallery image one place earlier/later (dir = up|down). */
    public function moveImage(Request $r, Product $product, ProductImage $image)
    {
        abort_unless($image->product_id === $product->id, 404);
        $ids = $product->images()->orderBy('sort_order')->orderBy('id')->pluck('id')->all();
        $i = array_search($image->id, $ids, true);
        $j = $r->input('dir') === 'up' ? $i - 1 : $i + 1;
        if ($i !== false && $j >= 0 && $j < count($ids)) {
            [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]];
            foreach ($ids as $pos => $id) $product->images()->whereKey($id)->update(['sort_order' => $pos]);
        }
        return back();
    }

    public function reorderImages(Request $r, Product $product)
    {
        foreach ((array) $r->input('ids', []) as $pos => $id) $product->images()->whereKey((int) $id)->update(['sort_order' => $pos]);
        return response()->noContent();
    }

    public function bulk(Request $r)
    {
        $r->validate(['ids' => 'required|array', 'ids.*' => 'integer', 'action' => ['required', Rule::in(['publish', 'unpublish', 'archive', 'price_percent', 'stock_set', 'category'])], 'value' => 'nullable|numeric']);
        $q = Product::whereIn('id', $r->input('ids'));
        $n = (clone $q)->count();

        match ($r->input('action')) {
            'publish' => $q->update(['status' => 'published']),
            'unpublish' => $q->update(['status' => 'draft']),
            'archive' => $q->update(['status' => 'archived']),
            'category' => $q->update(['category_id' => Category::findOrFail((int) $r->input('value'))->id]),
            'stock_set' => $q->update(['stock_quantity' => max(0, (int) $r->input('value'))]),
            'price_percent' => $this->bulkPrice($q, (float) $r->input('value')),
        };
        return back()->with('status', "Updated {$n} products.");
    }

    private function bulkPrice($q, float $percent): void
    {
        abort_if($percent <= -100 || $percent > 500, 422, 'Percent change is out of range.');
        $factor = 1 + $percent / 100;
        $q->get()->each(function (Product $p) use ($factor) {
            $p->price = (int) round($p->price * $factor);
            $p->sale_price = $p->sale_price !== null ? min((int) round($p->sale_price * $factor), $p->price) : null;
            $p->save();
        });
    }
}
