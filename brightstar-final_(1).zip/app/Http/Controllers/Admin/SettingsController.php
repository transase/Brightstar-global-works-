<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Services\Credentials;
use App\Services\ImageStore;
use App\Services\WhatsAppService;
use App\Support\Branding;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class SettingsController extends Controller
{
    private const TEXT = [
        'store_name', 'store_email', 'store_phone', 'store_address', 'default_country', 'order_prefix', 'footer_about',
        'announcement_text', 'hero_title', 'hero_text',
        'wa_greeting', 'wa_product_template', 'wa_cart_template', 'wa_general_template', 'wa_hours_notice',
        'facebook_url', 'instagram_url', 'tiktok_url', 'bank_transfer_details', 'tax_label',
        'mail_host', 'mail_username', 'mail_encryption', 'mail_from_address', 'mail_from_name',
    ];
    private const FLAGS = ['announcement_enabled', 'wa_floating', 'cod_enabled', 'bank_transfer_enabled', 'gateway_paystack', 'gateway_flutterwave', 'gateway_stripe'];
    /** form field => credential key */
    private const SECRETS = [
        'paystack_secret', 'flutterwave_secret', 'flutterwave_webhook_hash', 'stripe_secret', 'stripe_webhook_secret', 'mail_password',
    ];

    public function edit()
    {
        return view('admin.settings', [
            's' => fn ($k, $d = null) => Setting::get($k, $d),
            'secretSource' => fn ($k) => Credentials::source($k),
        ]);
    }

    public function update(Request $r)
    {
        $r->validate([
            'whatsapp_phone' => ['nullable', 'string', 'max:32', function ($attr, $v, $fail) {
                if ($v && ! WhatsAppService::normalisePhone($v)) $fail('Enter the WhatsApp number in international format, e.g. +2348012345678.');
            }],
            'currency' => ['required', Rule::in(['NGN', 'USD', 'GBP', 'EUR', 'GHS'])],
            'store_email' => 'nullable|email', 'mail_from_address' => 'nullable|email',
            'facebook_url' => 'nullable|url', 'instagram_url' => 'nullable|url', 'tiktok_url' => 'nullable|url',
            'tax_rate' => 'nullable|numeric|min:0|max:100',
            'free_delivery_min' => 'nullable|numeric|min:0',
            'low_stock_threshold' => 'nullable|integer|min:0|max:1000',
            'order_prefix' => 'nullable|alpha_num|max:6',
            'mail_port' => 'nullable|integer|min:1|max:65535',
            'mail_encryption' => ['nullable', Rule::in(['tls', 'ssl', 'none'])],
            'brand_red' => ['nullable', 'regex:/^#[0-9A-Fa-f]{6}$/'], 'brand_green' => ['nullable', 'regex:/^#[0-9A-Fa-f]{6}$/'], 'brand_yellow' => ['nullable', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'logo' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'favicon' => 'nullable|image|mimes:png,jpg,jpeg,webp,ico|max:512',
            'hero_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:5120',
        ]);

        foreach (self::TEXT as $k) Setting::put($k, $r->input($k));
        foreach (self::FLAGS as $k) Setting::put($k, $r->boolean($k) ? '1' : '0');
        Setting::put('currency', $r->input('currency'));
        Setting::put('whatsapp_phone', $r->filled('whatsapp_phone') ? '+'.WhatsAppService::normalisePhone($r->input('whatsapp_phone')) : '');
        Setting::put('mail_port', $r->input('mail_port'));
        Setting::put('tax_rate', $r->filled('tax_rate') ? (string) $r->input('tax_rate') : '0');
        Setting::put('free_delivery_min', $r->filled('free_delivery_min') ? (string) (int) round($r->input('free_delivery_min') * 100) : '0');
        Setting::put('low_stock_threshold', $r->filled('low_stock_threshold') ? (string) $r->input('low_stock_threshold') : '3');

        // Brand colours (blank or "reset" restores the defaults).
        foreach (Branding::DEFAULTS as $k => $default) {
            Setting::put($k, ($r->boolean('reset_colors') || ! $r->filled($k)) ? null : strtoupper($r->input($k)));
        }

        // Secrets: a typed value replaces the saved one; blank keeps it; "clear" removes it. Never echoed back.
        foreach (self::SECRETS as $k) {
            if ($r->boolean('clear_'.$k)) Setting::putSecret($k, null);
            elseif ($r->filled('secret_'.$k)) Setting::putSecret($k, trim($r->input('secret_'.$k)));
        }

        // Brand images.
        foreach (['logo' => 'branding', 'favicon' => 'branding'] as $k => $dir) {
            if ($r->boolean('reset_'.$k)) { $this->dropFile($k); Setting::put($k, null); }
            elseif ($r->hasFile($k)) {
                $this->dropFile($k);
                Setting::put($k, $r->file($k)->store($dir, \App\Support\Media::diskName())); // stored as-is: keeps PNG transparency and .ico
            }
        }
        if ($r->boolean('reset_hero_image')) { ImageStore::delete(Setting::get('hero_image')); Setting::put('hero_image', null); }
        elseif ($r->hasFile('hero_image')) { ImageStore::delete(Setting::get('hero_image')); Setting::put('hero_image', ImageStore::put($r->file('hero_image'), 'branding')); }

        return back()->with('status', 'Settings saved.');
    }

    private function dropFile(string $key): void
    {
        if ($old = Setting::get($key)) \App\Support\Media::disk()->delete($old);
    }

    /** Sends a real (synchronous) email using the saved SMTP settings so mistakes show immediately. */
    public function testMail(Request $r)
    {
        try {
            Mail::raw('This is a test email from your store admin. If you can read it, email sending works.', fn ($m) => $m->to($r->user()->email)->subject('Store email test'));
        } catch (\Throwable $e) {
            return back()->with('error', 'Email failed: '.\Illuminate\Support\Str::limit($e->getMessage(), 300));
        }
        return back()->with('status', 'Test email sent to '.$r->user()->email.'.');
    }
}
