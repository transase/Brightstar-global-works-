<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class CategoryController extends Controller
{
    public function index()
    {
        return view('admin.categories.index', [
            'categories' => Category::whereNull('parent_id')->with('children')->orderBy('sort_order')->get(),
        ]);
    }

    public function create() { return view('admin.categories.form', ['category' => new Category, 'parents' => Category::whereNull('parent_id')->get()]); }

    public function edit(Category $category)
    {
        return view('admin.categories.form', ['category' => $category, 'parents' => Category::whereNull('parent_id')->where('id', '!=', $category->id)->get()]);
    }

    public function store(Request $r) { return $this->save($r, new Category); }
    public function update(Request $r, Category $category) { return $this->save($r, $category); }

    private function save(Request $r, Category $category)
    {
        $data = $r->validate([
            'name' => 'required|string|max:120',
            'slug' => ['nullable', 'string', 'max:140', Rule::unique('categories', 'slug')->ignore($category->id)],
            'parent_id' => ['nullable', 'integer', 'exists:categories,id', Rule::notIn([$category->id])],
            'description' => 'nullable|string|max:2000',
            'seo_title' => 'nullable|string|max:160', 'seo_description' => 'nullable|string|max:300',
            'sort_order' => 'nullable|integer|min:0', 'spec_fields' => 'nullable|string|max:500',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:4096',
        ]);
        $data['slug'] = Str::slug($data['slug'] ?: $data['name']);
        $data['sort_order'] = $data['sort_order'] ?? 0;
        $data['is_active'] = $r->boolean('is_active');
        $data['is_featured'] = $r->boolean('is_featured');
        if ($r->hasFile('image')) $data['image'] = \App\Services\ImageStore::put($r->file('image'), 'categories');
        else unset($data['image']);

        // Prevent cycles: a category cannot be moved under its own descendant.
        if ($category->exists && ! empty($data['parent_id']) && in_array((int) $data['parent_id'], $category->descendantIds(), true)) {
            return back()->withInput()->with('error', 'A category cannot be nested under itself or one of its subcategories.');
        }

        $category->fill($data)->save();
        return redirect()->route('admin.categories.index')->with('status', 'Category saved.');
    }

    public function destroy(Category $category)
    {
        if ($category->products()->exists()) {
            return back()->with('error', 'Move or archive this category\'s products before deleting it.');
        }
        $category->children()->update(['parent_id' => $category->parent_id]);
        $category->delete();
        return back()->with('status', 'Category deleted.');
    }

    /** Drag-and-drop reorder: POST ids[] in the desired order. */
    public function reorder(Request $r)
    {
        foreach ((array) $r->input('ids', []) as $pos => $id) Category::whereKey((int) $id)->update(['sort_order' => $pos]);
        return response()->noContent();
    }

    /** Swap position with the neighbouring sibling (dir = up|down). */
    public function move(Request $r, Category $category)
    {
        $siblings = Category::where('parent_id', $category->parent_id)->orderBy('sort_order')->orderBy('id')->get()->values();
        $i = $siblings->search(fn ($c) => $c->id === $category->id);
        $j = $r->input('dir') === 'up' ? $i - 1 : $i + 1;
        if ($i === false || $j < 0 || $j >= $siblings->count()) return back();
        $order = $siblings->pluck('id')->all();
        [$order[$i], $order[$j]] = [$order[$j], $order[$i]];
        foreach ($order as $pos => $id) Category::whereKey($id)->update(['sort_order' => $pos]);
        return back();
    }
}
