<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    /** Reconciliation view: highlights payments that need attention. */
    public function index(Request $r)
    {
        $q = Payment::with('order')->latest();
        if ($r->filled('status')) $q->where('status', $r->query('status'));
        if ($r->boolean('attention')) {
            $q->where(fn ($w) => $w->where('status', 'failed')->orWhere(fn ($x) => $x->where('status', 'pending')->where('created_at', '<', now()->subHour())));
        }
        return view('admin.payments.index', ['payments' => $q->paginate(25)->withQueryString()]);
    }

    /** Ask the provider again (e.g. webhook never arrived). Settlement still requires matching amount/currency. */
    public function reverify(Payment $payment, PaymentService $svc)
    {
        try {
            $svc->verifyAndSettle($payment->gateway, $payment->reference);
        } catch (\Throwable $e) {
            report($e);
            return back()->with('error', 'Could not reach the provider. Try again shortly.');
        }
        return back()->with('status', 'Payment re-checked with '.$payment->gateway.'.');
    }

    /** Admin-only (see routes). Amount is entered in major units. */
    public function refund(Request $r, Payment $payment, PaymentService $svc)
    {
        $d = $r->validate(['amount' => 'required|numeric|min:0.01']);
        try {
            $svc->refund($payment, (int) round($d['amount'] * 100), $r->user()->id);
        } catch (\InvalidArgumentException $e) {
            return back()->with('error', $e->getMessage());
        } catch (\Throwable $e) {
            report($e);
            return back()->with('error', 'Could not reach the payment provider. Nothing was refunded; try again.');
        }
        return back()->with('status', 'Refund requested. The provider may take a few days to return the money.');
    }
}
