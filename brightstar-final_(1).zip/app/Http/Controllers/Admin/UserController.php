<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;

/** Admin only. Staff accounts and customer list. */
class UserController extends Controller
{
    private const ROLES = ['admin', 'manager', 'staff', 'customer'];

    public function index(Request $r)
    {
        $q = User::orderBy('role')->orderBy('name');
        if ($t = trim((string) $r->query('q'))) $q->where(fn ($w) => $w->where('name', 'like', "%$t%")->orWhere('email', 'like', "%$t%"));
        if ($r->filled('role')) $q->where('role', $r->query('role'));
        return view('admin.users', ['users' => $q->paginate(25)->withQueryString(), 'roles' => self::ROLES]);
    }

    public function store(Request $r)
    {
        $d = $r->validate([
            'name' => 'required|string|max:120', 'email' => 'required|email|max:160|unique:users,email',
            'role' => ['required', Rule::in(self::ROLES)],
            'password' => ['required', Password::min(10)],
        ]);
        $u = new User(['name' => $d['name'], 'email' => $d['email'], 'password' => Hash::make($d['password'])]);
        $u->forceFill(['role' => $d['role'], 'email_verified_at' => now()])->save();
        return back()->with('status', 'Account created. Share the password securely and ask them to change it.');
    }

    public function update(Request $r, User $user)
    {
        $d = $r->validate(['role' => ['required', Rule::in(self::ROLES)], 'password' => ['nullable', Password::min(10)]]);

        if ($user->role === 'admin' && $d['role'] !== 'admin' && User::where('role', 'admin')->count() <= 1) {
            return back()->with('error', 'You cannot remove the last admin.');
        }
        if ($user->id === $r->user()->id && $d['role'] !== 'admin') {
            return back()->with('error', 'You cannot remove your own admin access.');
        }
        $user->forceFill(['role' => $d['role']]);
        if (! empty($d['password'])) $user->password = Hash::make($d['password']);
        $user->save();
        return back()->with('status', 'Account updated.');
    }

    public function destroy(Request $r, User $user)
    {
        if ($user->id === $r->user()->id) return back()->with('error', 'You cannot delete your own account.');
        if ($user->role === 'admin' && User::where('role', 'admin')->count() <= 1) return back()->with('error', 'You cannot delete the last admin.');
        $user->delete(); // orders keep their own customer snapshots
        return back()->with('status', 'Account deleted.');
    }
}
