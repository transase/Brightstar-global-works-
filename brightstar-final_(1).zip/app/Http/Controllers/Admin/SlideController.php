<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Slide;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class SlideController extends Controller
{
    public function index() { return view('admin.slides.index', ['slides' => Slide::orderBy('type')->orderBy('sort_order')->get(), 'slide' => new Slide(['type' => 'hero', 'is_active' => true])]); }

    public function edit(Slide $slide) { return view('admin.slides.index', ['slides' => Slide::orderBy('type')->orderBy('sort_order')->get(), 'slide' => $slide]); }

    public function store(Request $r) { return $this->save($r, new Slide); }
    public function update(Request $r, Slide $slide) { return $this->save($r, $slide); }

    private function save(Request $r, Slide $slide)
    {
        $d = $r->validate([
            'type' => ['required', Rule::in(['hero', 'promo'])],
            'heading' => 'required|string|max:160', 'description' => 'nullable|string|max:500',
            'cta_text' => 'nullable|string|max:40',
            // Internal paths or http(s) only: blocks javascript: URLs.
            'url' => ['nullable', 'string', 'max:500', 'regex:#^(/|https?://)#i'],
            'starts_at' => 'nullable|date', 'ends_at' => 'nullable|date|after:starts_at',
            'sort_order' => 'nullable|integer|min:0',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
        ]);
        $d['is_active'] = $r->boolean('is_active');
        $d['sort_order'] = $d['sort_order'] ?? 0;
        if ($r->hasFile('image')) {
            if ($slide->image) \App\Services\ImageStore::delete($slide->image);
            $d['image'] = \App\Services\ImageStore::put($r->file('image'), 'slides');
        } else unset($d['image']);
        $slide->fill($d)->save();
        return redirect()->route('admin.slides.index')->with('status', 'Saved.');
    }

    public function destroy(Slide $slide)
    {
        if ($slide->image) \App\Services\ImageStore::delete($slide->image);
        $slide->delete();
        return back()->with('status', 'Deleted.');
    }
}
