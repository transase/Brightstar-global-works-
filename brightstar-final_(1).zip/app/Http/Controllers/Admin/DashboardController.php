<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;

class DashboardController extends Controller
{
    public function __invoke()
    {
        return view('admin.dashboard', [
            'pending' => Order::where('fulfilment_status', 'pending_confirmation')->count(),
            'today' => Order::whereDate('created_at', today())->count(),
            'revenue30' => Order::where('payment_status', 'paid')->where('created_at', '>=', now()->subDays(30))->sum('total'),
            'lowStock' => Product::where('track_stock', true)->where('stock_quantity', '<=', (int) \App\Models\Setting::get('low_stock_threshold', 3))->where('status', 'published')->orderBy('stock_quantity')->take(8)->get(),
            'recent' => Order::latest()->take(8)->get(),
        ]);
    }
}
