<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DeliveryZone;
use Illuminate\Http\Request;

class DeliveryZoneController extends Controller
{
    public function index() { return view('admin.zones', ['zones' => DeliveryZone::orderBy('name')->get()]); }

    private function data(Request $r): array
    {
        $d = $r->validate(['name' => 'required|string|max:120', 'state' => 'nullable|string|max:100', 'fee' => 'required|numeric|min:0']);
        return ['name' => $d['name'], 'state' => $d['state'] ?? null, 'fee' => (int) round($d['fee'] * 100), 'is_active' => $r->boolean('is_active')];
    }

    public function store(Request $r) { DeliveryZone::create($this->data($r)); return back()->with('status', 'Delivery area added.'); }
    public function update(Request $r, DeliveryZone $zone) { $zone->update($this->data($r)); return back()->with('status', 'Delivery area updated.'); }
    public function destroy(DeliveryZone $zone) { $zone->delete(); return back()->with('status', 'Delivery area deleted.'); }
}
