<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Benefit;
use Illuminate\Http\Request;

class BenefitController extends Controller
{
    public function index() { return view('admin.benefits', ['benefits' => Benefit::orderBy('sort_order')->get()]); }

    private function data(Request $r): array
    {
        $d = $r->validate(['title' => 'required|string|max:100', 'text' => 'nullable|string|max:300', 'sort_order' => 'nullable|integer|min:0']);
        return $d + ['sort_order' => $d['sort_order'] ?? 0, 'is_active' => $r->boolean('is_active')];
    }

    public function store(Request $r) { Benefit::create($this->data($r)); return back()->with('status', 'Added.'); }
    public function update(Request $r, Benefit $benefit) { $benefit->update($this->data($r)); return back()->with('status', 'Saved.'); }
    public function destroy(Benefit $benefit) { $benefit->delete(); return back()->with('status', 'Deleted.'); }
}
