<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CouponController extends Controller
{
    public function index() { return view('admin.coupons', ['coupons' => Coupon::latest()->get()]); }

    public function store(Request $r)
    {
        $d = $r->validate([
            'code' => 'required|alpha_dash|max:40|unique:coupons,code',
            'type' => ['required', Rule::in(['percent', 'fixed'])],
            'value' => 'required|numeric|min:0.01',
            'min_subtotal' => 'nullable|numeric|min:0', 'max_uses' => 'nullable|integer|min:1',
            'starts_at' => 'nullable|date', 'expires_at' => 'nullable|date|after:starts_at',
        ]);
        if ($d['type'] === 'percent' && $d['value'] > 100) return back()->withInput()->with('error', 'A percentage cannot exceed 100.');
        Coupon::create([
            'code' => strtoupper($d['code']), 'type' => $d['type'],
            'value' => $d['type'] === 'percent' ? (int) $d['value'] : (int) round($d['value'] * 100),
            'min_subtotal' => (int) round(($d['min_subtotal'] ?? 0) * 100), 'max_uses' => $d['max_uses'] ?? null,
            'starts_at' => $d['starts_at'] ?? null, 'expires_at' => $d['expires_at'] ?? null,
        ]);
        return back()->with('status', 'Coupon created.');
    }

    public function toggle(Coupon $coupon) { $coupon->update(['is_active' => ! $coupon->is_active]); return back(); }
    public function destroy(Coupon $coupon) { $coupon->delete(); return back()->with('status', 'Coupon deleted.'); }
}
