<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class PageController extends Controller
{
    public function index() { return view('admin.pages', ['pages' => Page::orderBy('title')->get(), 'page' => new Page(['is_published' => true])]); }
    public function edit(Page $page) { return view('admin.pages', ['pages' => Page::orderBy('title')->get(), 'page' => $page]); }
    public function store(Request $r) { return $this->save($r, new Page); }
    public function update(Request $r, Page $page) { return $this->save($r, $page); }

    private function save(Request $r, Page $page)
    {
        $d = $r->validate([
            'title' => 'required|string|max:160',
            'slug' => ['nullable', 'string', 'max:120', Rule::unique('pages', 'slug')->ignore($page->id)],
            'body' => 'nullable|string|max:50000', 'seo_description' => 'nullable|string|max:300',
        ]);
        $d['slug'] = Str::slug($d['slug'] ?: $d['title']);
        $d['is_published'] = $r->boolean('is_published');
        $page->fill($d)->save();
        return redirect()->route('admin.pages.index')->with('status', 'Page saved.');
    }

    public function destroy(Page $page) { $page->delete(); return back()->with('status', 'Page deleted.'); }
}
