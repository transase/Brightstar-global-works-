<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\NewsletterMail;
use App\Models\NewsletterSubscriber;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class NewsletterController extends Controller
{
    public function index()
    {
        return view('admin.newsletter', ['active' => NewsletterSubscriber::active()->count(), 'total' => NewsletterSubscriber::count()]);
    }

    public function send(Request $r)
    {
        $d = $r->validate(['subject' => 'required|string|max:150', 'body' => 'required|string|max:20000']);

        if ($r->boolean('test')) {
            Mail::to($r->user()->email)->queue(new NewsletterMail('[TEST] '.$d['subject'], $d['body'], Str::random(40)));
            return back()->withInput()->with('status', 'Test sent to '.$r->user()->email.'.');
        }

        $n = 0;
        NewsletterSubscriber::active()->chunkById(200, function ($chunk) use ($d, &$n) {
            foreach ($chunk as $sub) {
                Mail::to($sub->email)->queue(new NewsletterMail($d['subject'], $d['body'], $sub->ensureToken()));
                $n++;
            }
        });
        return back()->with('status', "Queued for {$n} subscribers.");
    }
}
