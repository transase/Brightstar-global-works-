<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    public function index(Request $r)
    {
        $q = Order::latest();
        if ($t = trim((string) $r->query('q'))) $q->where(fn ($w) => $w->where('number', 'like', "%$t%")->orWhere('email', 'like', "%$t%")->orWhere('phone', 'like', "%$t%")->orWhere('last_name', 'like', "%$t%"));
        if ($r->filled('fulfilment')) $q->where('fulfilment_status', $r->query('fulfilment'));
        if ($r->filled('payment')) $q->where('payment_status', $r->query('payment'));
        if ($r->filled('source')) $q->where('source', $r->query('source'));
        return view('admin.orders.index', ['orders' => $q->paginate(20)->withQueryString()]);
    }

    public function show(Order $order)
    {
        return view('admin.orders.show', ['order' => $order->load(['items', 'payments', 'logs'])]);
    }

    public function invoice(Order $order)
    {
        return view('admin.orders.invoice', ['order' => $order->load('items')]);
    }

    public function update(Request $r, Order $order, OrderService $service)
    {
        $data = $r->validate([
            'fulfilment_status' => ['nullable', Rule::in(OrderService::FULFILMENT)],
            'payment_status' => ['nullable', Rule::in(['unpaid', 'pending', 'paid', 'failed', 'refunded', 'partially_refunded'])],
            'admin_notes' => 'nullable|string|max:3000',
        ]);
        try {
            $service->update($order, array_filter($data, fn ($v) => $v !== null) + ['admin_notes' => $data['admin_notes'] ?? $order->admin_notes], $r->user()->id);
        } catch (\InvalidArgumentException $e) {
            return back()->with('error', $e->getMessage());
        }
        return back()->with('status', 'Order updated.');
    }
}
