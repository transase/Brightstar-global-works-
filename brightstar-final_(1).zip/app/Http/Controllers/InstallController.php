<?php

namespace App\Http\Controllers;

use App\Http\Middleware\RedirectIfNotInstalled;
use App\Models\Setting;
use Database\Seeders\BrightstarSeeder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use PDO;

/**
 * Browser installer for shared hosting (cPanel). Available only until storage/app/installed.lock exists.
 * Guarded by an install code stored on the server (storage/app/INSTALL-CODE.txt) so a stranger who finds
 * the site before you cannot install it first.
 */
class InstallController extends Controller
{
    private function codeFile(): string { return storage_path('app/INSTALL-CODE.txt'); }

    private function guard(): void { abort_if(RedirectIfNotInstalled::installed(), 404); }

    /** @return array<int, array{label: string, ok: bool, required: bool, hint: string}> */
    public function checks(): array
    {
        $c = [];
        $add = function (string $label, bool $ok, string $hint = '', bool $required = true) use (&$c) { $c[] = compact('label', 'ok', 'required', 'hint'); };

        $add('PHP 8.2 or newer (you have '.PHP_VERSION.')', version_compare(PHP_VERSION, '8.2.0', '>='), 'In cPanel open "MultiPHP Manager" and choose PHP 8.2 or 8.3 for this domain.');
        foreach (['pdo_mysql', 'mbstring', 'openssl', 'tokenizer', 'xml', 'ctype', 'json', 'fileinfo', 'curl', 'dom'] as $ext) {
            $add("PHP extension: {$ext}", extension_loaded($ext), 'In cPanel open "Select PHP Version" → Extensions and tick it.');
        }
        $add('PHP extension: gd with WebP (image optimisation)', extension_loaded('gd') && function_exists('imagewebp'), 'Optional. Without it, images are stored without resizing.', false);
        $add('Folder writable: storage', is_writable(storage_path()), 'Set permissions to 755 (or 775) on storage and everything inside it.');
        $add('Folder writable: bootstrap/cache', is_writable(base_path('bootstrap/cache')), 'Set permissions to 755 (or 775).');
        $env = base_path('.env');
        $add('Settings file (.env) writable', file_exists($env) ? is_writable($env) : is_writable(base_path()), 'Set .env permissions to 644 and make sure you own the file.');
        return $c;
    }

    public function show(Request $request)
    {
        $this->guard();
        $checks = $this->checks();
        return view('install.wizard', [
            'checks' => $checks,
            'blocked' => collect($checks)->contains(fn ($c) => $c['required'] && ! $c['ok']),
            'needsCode' => file_exists($this->codeFile()),
            'appUrl' => rtrim($request->getSchemeAndHttpHost().$request->getBasePath(), '/'),
        ]);
    }

    public function store(Request $request)
    {
        $this->guard();
        @set_time_limit(240);

        if (collect($this->checks())->contains(fn ($c) => $c['required'] && ! $c['ok'])) {
            return back()->withInput()->with('error', 'Fix the red items in the requirements list first.');
        }

        $needsCode = file_exists($this->codeFile());
        $d = $request->validate([
            'install_code' => $needsCode ? 'required|string' : 'nullable|string',
            'app_url' => 'required|url|max:200',
            'db_host' => 'required|string|max:120', 'db_port' => 'required|integer|min:1|max:65535',
            'db_name' => 'required|string|max:100', 'db_user' => 'required|string|max:100', 'db_pass' => 'nullable|string|max:200',
            'store_name' => 'required|string|max:120',
            'admin_name' => 'required|string|max:120', 'admin_email' => 'required|email|max:160',
            'admin_password' => 'required|string|min:10|confirmed',
        ]);

        if ($needsCode && ! hash_equals(trim((string) file_get_contents($this->codeFile())), trim($d['install_code']))) {
            return back()->withInput()->with('error', 'The install code is wrong. Open storage/app/INSTALL-CODE.txt on the server (cPanel File Manager) and copy it exactly.');
        }

        try {
            new PDO("mysql:host={$d['db_host']};port={$d['db_port']};dbname={$d['db_name']};charset=utf8mb4", $d['db_user'], $d['db_pass'] ?? '', [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 8,
            ]);
        } catch (\PDOException $e) {
            return back()->withInput()->with('error', 'Could not connect to the database: '.mb_substr($e->getMessage(), 0, 200).'. Check the database name, user and password in cPanel → MySQL Databases, and that the user is added to the database with ALL PRIVILEGES.');
        }

        // Use the new credentials for this request.
        config(['database.default' => 'mysql', 'database.connections.mysql.host' => $d['db_host'], 'database.connections.mysql.port' => $d['db_port'],
            'database.connections.mysql.database' => $d['db_name'], 'database.connections.mysql.username' => $d['db_user'], 'database.connections.mysql.password' => $d['db_pass'] ?? '']);
        DB::purge('mysql');

        try {
            Artisan::call('migrate', ['--force' => true]);
            Artisan::call('db:seed', ['--class' => BrightstarSeeder::class, '--force' => true]);
            BrightstarSeeder::createAdmin($d['admin_name'], $d['admin_email'], $d['admin_password']);
            Setting::put('store_name', $d['store_name']);
            Setting::put('store_email', $d['admin_email']);
        } catch (\Throwable $e) {
            report($e);
            return back()->withInput()->with('error', 'Setting up the database failed: '.mb_substr($e->getMessage(), 0, 300).' You can fix the problem and press Install again; it is safe to repeat.');
        }

        // Image storage: prefer the normal storage link; if the host blocks symlinks use public/uploads directly.
        $mediaDisk = 'public';
        try { if (! file_exists(public_path('storage'))) Artisan::call('storage:link'); } catch (\Throwable) {}
        if (! file_exists(public_path('storage'))) $mediaDisk = 'uploads';

        self::writeEnv([
            'APP_NAME' => $d['store_name'], 'APP_ENV' => 'production', 'APP_DEBUG' => 'false', 'APP_URL' => rtrim($d['app_url'], '/'),
            'DB_CONNECTION' => 'mysql', 'DB_HOST' => $d['db_host'], 'DB_PORT' => (string) $d['db_port'], 'DB_DATABASE' => $d['db_name'],
            'DB_USERNAME' => $d['db_user'], 'DB_PASSWORD' => $d['db_pass'] ?? '',
            'SESSION_DRIVER' => 'file', 'CACHE_STORE' => 'file', 'QUEUE_CONNECTION' => 'sync',
            'SESSION_SECURE_COOKIE' => str_starts_with($d['app_url'], 'https://') ? 'true' : 'false',
            'MEDIA_DISK' => $mediaDisk, 'PUBLIC_PATH' => public_path(),
        ]);

        @unlink($this->codeFile());
        file_put_contents(storage_path('app/installed.lock'), 'Installed '.now()->toDateTimeString()."\n");

        return view('install.done', ['adminEmail' => $d['admin_email'], 'url' => rtrim($d['app_url'], '/'), 'mediaDisk' => $mediaDisk]);
    }

    /** Update/add KEY=value lines in .env (values quoted when needed). */
    public static function writeEnv(array $values): void
    {
        $path = base_path('.env');
        $lines = file_exists($path) ? preg_split('/\R/', (string) file_get_contents($path)) : [];
        $quote = fn (string $v) => preg_match('/[\s#"\'\\\\$=]/', $v) ? '"'.str_replace(['\\', '"', '$'], ['\\\\', '\\"', '\\$'], $v).'"' : $v;

        foreach ($values as $k => $v) {
            $found = false;
            foreach ($lines as $i => $line) {
                if (preg_match('/^\s*'.preg_quote($k, '/').'\s*=/', $line)) { $lines[$i] = $k.'='.$quote((string) $v); $found = true; break; }
            }
            if (! $found) $lines[] = $k.'='.$quote((string) $v);
        }
        if (! array_filter($lines, fn ($l) => str_starts_with(trim($l), 'APP_KEY=') && trim(substr(trim($l), 8)) !== '')) {
            $lines[] = 'APP_KEY=base64:'.base64_encode(random_bytes(32));
        }
        file_put_contents($path, rtrim(implode("\n", $lines))."\n");
    }
}
