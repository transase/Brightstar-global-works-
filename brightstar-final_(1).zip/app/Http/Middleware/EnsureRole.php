<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Usage: ->middleware('role:admin,manager'). Admins always pass. */
class EnsureRole
{
    public function handle(Request $request, Closure $next, string ...$roles)
    {
        $user = $request->user();
        abort_unless($user && ($user->role === 'admin' || in_array($user->role, $roles, true)), 403);
        return $next($request);
    }
}
