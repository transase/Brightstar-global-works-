<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Until the web installer has finished (storage/app/installed.lock exists), every page redirects to /install. */
class RedirectIfNotInstalled
{
    public static function installed(): bool { return file_exists(storage_path('app/installed.lock')); }

    public function handle(Request $request, Closure $next)
    {
        if (static::installed() || app()->runningInConsole() || app()->environment('testing') || $request->is('install', 'install/*')) {
            return $next($request);
        }
        return redirect('/install');
    }
}
