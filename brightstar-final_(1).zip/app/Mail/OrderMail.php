<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/** One mailable for all order emails. $kind: received | paid | status | admin */
class OrderMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(public Order $order, public string $kind, public ?string $status = null) {}

    public function envelope(): Envelope
    {
        $n = $this->order->number;
        return new Envelope(subject: match ($this->kind) {
            'received' => "We received your order {$n}",
            'paid' => "Payment confirmed for order {$n}",
            'admin' => "New order {$n}",
            default => "Update on your order {$n}",
        });
    }

    public function content(): Content
    {
        return new Content(view: 'emails.order', with: ['order' => $this->order->loadMissing('items'), 'kind' => $this->kind, 'status' => $this->status]);
    }
}
