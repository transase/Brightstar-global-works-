<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Mail\Mailables\Headers;

class NewsletterMail extends Mailable implements ShouldQueue
{
    use Queueable;

    public function __construct(public string $subjectLine, public string $body, public string $token) {}

    public function envelope(): Envelope { return new Envelope(subject: $this->subjectLine); }

    public function headers(): Headers
    {
        return new Headers(text: ['List-Unsubscribe' => '<'.route('newsletter.unsubscribe', $this->token).'>']);
    }

    public function content(): Content
    {
        return new Content(view: 'emails.newsletter', with: ['unsubscribeUrl' => route('newsletter.unsubscribe', $this->token)]);
    }
}
