<?php

namespace App\Support;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Storage;

/**
 * Single place that knows where uploaded media lives. Default: local "public" disk.
 * For S3-compatible storage set MEDIA_DISK=s3 (and the AWS_* variables); URLs then come from the bucket.
 */
class Media
{
    public static function diskName(): string { return (string) config('store.media_disk', 'public'); }

    public static function disk(): Filesystem { return Storage::disk(static::diskName()); }

    public static function url(string $path): string
    {
        return match (static::diskName()) {
            'public' => asset('storage/'.$path),
            'uploads' => asset('uploads/'.$path),
            default => static::disk()->url($path),
        };
    }
}
