<?php

namespace App\Support;

use App\Models\Setting;

class Branding
{
    public const DEFAULTS = ['brand_red' => '#E51B23', 'brand_green' => '#078B2B', 'brand_yellow' => '#F2DF00'];

    private static function file(string $key, string $fallback): string
    {
        $p = Setting::get($key);
        return $p ? \App\Support\Media::url($p) : asset($fallback);
    }

    public static function logo(): string { return static::file('logo', 'images/logo.png'); }
    public static function favicon(): string { return static::file('favicon', 'images/logo.png'); }
    public static function hero(): string { return static::file('hero_image', 'images/hero.jpg'); }

    public static function color(string $key): string
    {
        $c = (string) Setting::get($key, self::DEFAULTS[$key]);
        return preg_match('/^#[0-9A-Fa-f]{6}$/', $c) ? $c : self::DEFAULTS[$key];
    }

    /** Darken a #RRGGBB colour for hover states. */
    public static function darken(string $hex, float $amount = 0.14): string
    {
        $n = array_map(fn ($h) => (int) round(hexdec($h) * (1 - $amount)), str_split(ltrim($hex, '#'), 2));
        return sprintf('#%02X%02X%02X', ...$n);
    }

    /** CSS custom-property overrides for the Tailwind theme. Colours are validated hex, so output is safe. */
    public static function css(): string
    {
        $red = static::color('brand_red');
        return ':root{--color-brand-red:'.$red.';--color-brand-red-dark:'.static::darken($red)
            .';--color-brand-green:'.static::color('brand_green').';--color-brand-yellow:'.static::color('brand_yellow').'}';
    }
}
