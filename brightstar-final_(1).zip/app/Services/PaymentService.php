<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Payment;
use App\Models\PaymentEvent;
use App\Services\Payments\FlutterwaveGateway;
use App\Services\Payments\Gateway;
use App\Services\Payments\PaystackGateway;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;

class PaymentService
{
    /** @return array<string, Gateway> */
    public function gateways(): array
    {
        return ['paystack' => new PaystackGateway, 'flutterwave' => new FlutterwaveGateway, 'stripe' => new Payments\StripeGateway];
    }

    public function enabledGateways(): array
    {
        return array_filter($this->gateways(), fn (Gateway $g) => $g->isEnabled());
    }

    public function gateway(string $name): Gateway
    {
        $g = $this->gateways()[$name] ?? throw new InvalidArgumentException('Unknown gateway.');
        if (! $g->isEnabled()) throw new InvalidArgumentException('That payment method is not available.');
        return $g;
    }

    /** Creates a payment record and returns the provider's hosted checkout URL. */
    public function start(Order $order, string $gatewayName): string
    {
        $gateway = $this->gateway($gatewayName);
        abort_if($order->payment_status === 'paid', 409, 'This order is already paid.');

        $payment = Payment::create([
            'order_id' => $order->id,
            'gateway' => $gatewayName,
            'reference' => $order->number.'-'.strtoupper(Str::random(6)),
            'amount' => $order->total,
            'currency' => $order->currency,
            'status' => 'pending',
        ]);
        $order->update(['payment_status' => 'pending', 'payment_method' => $gatewayName]);
        $order->log('payment_started', "{$gatewayName} reference {$payment->reference}");

        return $gateway->initialize($order, $payment, route('payment.callback', $gatewayName));
    }

    /**
     * Independently verifies with the provider, then settles. Safe to call repeatedly
     * (browser callback + webhook may both arrive).
     */
    public function verifyAndSettle(string $gatewayName, string $reference): ?Payment
    {
        $payment = Payment::where('gateway', $gatewayName)->where('reference', $reference)->first();
        if (! $payment) return null;

        $result = $this->gateway($gatewayName)->verify($reference);

        $justPaid = false;
        $settled = DB::transaction(function () use ($payment, $result, &$justPaid) {
            $payment = Payment::whereKey($payment->id)->lockForUpdate()->first();
            if ($payment->status === 'successful') return $payment; // idempotent

            $order = Order::whereKey($payment->order_id)->lockForUpdate()->first();

            if (! $result['successful']) {
                $payment->update(['status' => 'failed', 'verified_at' => now()]);
                // A different attempt may already have paid this order: never downgrade it.
                if (! in_array($order->payment_status, ['paid', 'partially_refunded', 'refunded'], true)) {
                    $order->update(['payment_status' => 'failed']);
                }
                $order->log('payment_failed', $payment->reference);
                return $payment;
            }

            // Reference, amount, currency and order association must all match what we asked for.
            if ($result['amount'] !== (int) $payment->amount || strtoupper($result['currency']) !== strtoupper($payment->currency)
                || $payment->amount !== $order->total) {
                $payment->update(['status' => 'failed', 'meta' => array_merge($payment->meta ?? [], ['reason' => 'amount_or_currency_mismatch']), 'verified_at' => now()]);
                $order->log('payment_mismatch', "Expected {$payment->amount} {$payment->currency}; got {$result['amount']} {$result['currency']}.");
                return $payment;
            }

            $alreadySettled = in_array($order->payment_status, ['paid', 'partially_refunded', 'refunded'], true);
            if ($alreadySettled || $order->fulfilment_status === 'cancelled') {
                // Real money arrived but the order must not be fulfilled again / reopened (stock was already released).
                $reason = $alreadySettled ? 'duplicate_payment' : 'paid_after_cancellation';
                $payment->update([
                    'status' => 'successful', 'gateway_transaction_id' => $result['transaction_id'], 'verified_at' => now(),
                    'meta' => array_merge($payment->meta ?? [], ['needs_review' => $reason]),
                ]);
                if (! $alreadySettled) $order->update(['payment_status' => 'paid']);
                $order->log('payment_needs_review', "{$reason}: {$payment->gateway} {$payment->reference}. Refund or reinstate manually.");
                return $payment;
            }

            $payment->update([
                'status' => 'successful',
                'gateway_transaction_id' => $result['transaction_id'],
                'verified_at' => now(),
            ]);
            $order->update(['payment_status' => 'paid', 'fulfilment_status' => 'processing']);
            $order->items()->get()->each(fn ($i) => $i->product_id && \App\Models\Product::whereKey($i->product_id)->increment('sales_count', $i->quantity));
            $order->log('payment_verified', "{$payment->gateway} {$payment->reference}");
            $justPaid = true;

            return $payment;
        });

        if ($justPaid) app(OrderNotifier::class)->paid(Order::find($settled->order_id));
        return $settled;
    }

    /** Records a webhook exactly once. Returns false if it was already processed. */
    public function claimWebhookEvent(string $gateway, array $parsed): bool
    {
        if ($parsed['event_id'] === '') return false;
        try {
            PaymentEvent::create([
                'gateway' => $gateway,
                'event_id' => $parsed['event_id'].':'.$parsed['type'],
                'reference' => $parsed['reference'],
                'type' => $parsed['type'],
                'processed_at' => now(),
            ]);
            return true;
        } catch (QueryException) {
            return false;
        }
    }

    /**
     * Refund part or all of a successful payment. Amount in minor units.
     * Only recorded locally AFTER the provider accepts the request.
     */
    public function refund(Payment $payment, int $amount, ?int $userId): Payment
    {
        return DB::transaction(function () use ($payment, $amount, $userId) {
            $payment = Payment::whereKey($payment->id)->lockForUpdate()->first();
            $remaining = $payment->amount - $payment->refunded_amount;

            if ($payment->status !== 'successful') throw new InvalidArgumentException('Only successful payments can be refunded.');
            if ($amount < 1 || $amount > $remaining) throw new InvalidArgumentException('Refund must be between 0.01 and the remaining refundable amount.');

            $result = $this->gateway($payment->gateway)->refund($payment, $amount);
            if (! $result['ok']) throw new InvalidArgumentException('The provider rejected the refund: '.$result['message']);

            $payment->refunded_amount += $amount;
            $full = $payment->refunded_amount >= $payment->amount;
            if ($full) $payment->status = 'refunded';
            $payment->save();

            $order = Order::whereKey($payment->order_id)->lockForUpdate()->first();
            $order->update(['payment_status' => $full ? 'refunded' : 'partially_refunded']);
            $order->log('refund_requested', Money::format($amount, $payment->currency).' via '.$payment->gateway.' ('.$result['message'].')', $userId);

            return $payment;
        });
    }
}
