<?php

namespace App\Services\Payments;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class PaystackGateway implements Gateway
{
    public function name(): string { return 'paystack'; }

    public function isEnabled(): bool
    {
        // Keys live in .env; admins switch the gateway on/off in Settings.
        return filled(\App\Services\Credentials::get('paystack_secret')) && \App\Models\Setting::get('gateway_paystack', '1') !== '0';
    }

    private function http()
    {
        return Http::withToken(\App\Services\Credentials::get('paystack_secret'))->acceptJson()->timeout(20)->baseUrl('https://api.paystack.co');
    }

    public function initialize(Order $order, Payment $payment, string $callbackUrl): string
    {
        $res = $this->http()->post('/transaction/initialize', [
            'email' => $order->email,
            'amount' => $payment->amount, // Paystack expects minor units (kobo)
            'currency' => $payment->currency,
            'reference' => $payment->reference,
            'callback_url' => $callbackUrl,
            'metadata' => ['order_number' => $order->number],
        ]);

        if (! $res->successful() || ! $res->json('status')) {
            throw new RuntimeException('Could not start Paystack payment.');
        }
        return $res->json('data.authorization_url');
    }

    public function verify(string $reference): array
    {
        $res = $this->http()->get('/transaction/verify/'.rawurlencode($reference));
        if (! $res->successful()) {
            throw new RuntimeException('Paystack verification request failed.');
        }
        $d = $res->json('data');
        return [
            'successful' => ($d['status'] ?? null) === 'success',
            'amount' => (int) ($d['amount'] ?? 0),
            'currency' => (string) ($d['currency'] ?? ''),
            'transaction_id' => isset($d['id']) ? (string) $d['id'] : null,
        ];
    }

    public function refund(Payment $payment, int $amount): array
    {
        $res = $this->http()->post('/refund', ['transaction' => $payment->reference, 'amount' => $amount, 'currency' => $payment->currency]);
        return ['ok' => $res->successful() && (bool) $res->json('status'), 'message' => (string) ($res->json('message') ?? 'No response from Paystack.')];
    }

    public function validWebhookSignature(Request $request): bool
    {
        $sig = (string) $request->header('x-paystack-signature');
        $expected = hash_hmac('sha512', $request->getContent(), (string) \App\Services\Credentials::get('paystack_secret'));
        return $sig !== '' && hash_equals($expected, $sig);
    }

    public function parseWebhook(Request $request): array
    {
        $b = $request->json()->all();
        return [
            'event_id' => (string) ($b['data']['id'] ?? ''),
            'type' => (string) ($b['event'] ?? ''),
            'reference' => $b['data']['reference'] ?? null,
        ];
    }
}
