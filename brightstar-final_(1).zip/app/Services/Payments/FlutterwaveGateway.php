<?php

namespace App\Services\Payments;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class FlutterwaveGateway implements Gateway
{
    public function name(): string { return 'flutterwave'; }

    public function isEnabled(): bool
    {
        // Keys live in .env; admins switch the gateway on/off in Settings.
        return filled(\App\Services\Credentials::get('flutterwave_secret')) && \App\Models\Setting::get('gateway_flutterwave', '1') !== '0';
    }

    private function http()
    {
        return Http::withToken(\App\Services\Credentials::get('flutterwave_secret'))->acceptJson()->timeout(20)->baseUrl('https://api.flutterwave.com/v3');
    }

    public function initialize(Order $order, Payment $payment, string $callbackUrl): string
    {
        $res = $this->http()->post('/payments', [
            'tx_ref' => $payment->reference,
            'amount' => $payment->amount / 100, // Flutterwave expects major units
            'currency' => $payment->currency,
            'redirect_url' => $callbackUrl,
            'customer' => [
                'email' => $order->email,
                'name' => $order->first_name.' '.$order->last_name,
                'phonenumber' => $order->phone,
            ],
            'meta' => ['order_number' => $order->number],
        ]);

        if (! $res->successful() || $res->json('status') !== 'success') {
            throw new RuntimeException('Could not start Flutterwave payment.');
        }
        return $res->json('data.link');
    }

    public function verify(string $reference): array
    {
        $res = $this->http()->get('/transactions/verify_by_reference', ['tx_ref' => $reference]);
        if (! $res->successful()) {
            throw new RuntimeException('Flutterwave verification request failed.');
        }
        $d = $res->json('data') ?? [];
        return [
            'successful' => ($d['status'] ?? null) === 'successful',
            'amount' => (int) round(((float) ($d['amount'] ?? 0)) * 100),
            'currency' => (string) ($d['currency'] ?? ''),
            'transaction_id' => isset($d['id']) ? (string) $d['id'] : null,
        ];
    }

    public function refund(Payment $payment, int $amount): array
    {
        if (! $payment->gateway_transaction_id) return ['ok' => false, 'message' => 'Missing Flutterwave transaction id.'];
        $res = $this->http()->post('/transactions/'.rawurlencode($payment->gateway_transaction_id).'/refund', ['amount' => $amount / 100]);
        return ['ok' => $res->successful() && $res->json('status') === 'success', 'message' => (string) ($res->json('message') ?? 'No response from Flutterwave.')];
    }

    /** Flutterwave sends the secret hash you configured in its dashboard in the `verif-hash` header. */
    public function validWebhookSignature(Request $request): bool
    {
        $hash = (string) \App\Services\Credentials::get('flutterwave_webhook_hash');
        $sent = (string) $request->header('verif-hash');
        return $hash !== '' && $sent !== '' && hash_equals($hash, $sent);
    }

    public function parseWebhook(Request $request): array
    {
        $b = $request->json()->all();
        return [
            'event_id' => (string) ($b['data']['id'] ?? ''),
            'type' => (string) ($b['event'] ?? $b['event.type'] ?? ''),
            'reference' => $b['data']['tx_ref'] ?? null,
        ];
    }
}
