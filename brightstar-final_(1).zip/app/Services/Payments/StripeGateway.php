<?php

namespace App\Services\Payments;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use RuntimeException;

/**
 * Stripe Checkout (hosted page). Only enable if your Stripe account supports the store currency
 * (e.g. NGN requires a Nigerian Stripe account).
 */
class StripeGateway implements Gateway
{
    private const TOLERANCE_SECONDS = 300;

    public function name(): string { return 'stripe'; }

    public function isEnabled(): bool
    {
        return filled(\App\Services\Credentials::get('stripe_secret')) && \App\Models\Setting::get('gateway_stripe', '1') !== '0';
    }

    private function http()
    {
        return Http::withToken(\App\Services\Credentials::get('stripe_secret'))->asForm()->acceptJson()->timeout(20)->baseUrl('https://api.stripe.com/v1');
    }

    public function initialize(Order $order, Payment $payment, string $callbackUrl): string
    {
        $res = $this->http()->post('/checkout/sessions', [
            'mode' => 'payment',
            'client_reference_id' => $payment->reference,
            'customer_email' => $order->email,
            // Stripe substitutes {CHECKOUT_SESSION_ID}; we identify the payment by our own reference.
            'success_url' => $callbackUrl.'?reference='.rawurlencode($payment->reference),
            'cancel_url' => route('order.show', $order->number),
            'line_items' => [[
                'quantity' => 1,
                'price_data' => [
                    'currency' => strtolower($payment->currency),
                    'unit_amount' => $payment->amount, // minor units
                    'product_data' => ['name' => 'Order '.$order->number],
                ],
            ]],
            'metadata' => ['order_number' => $order->number, 'payment_reference' => $payment->reference],
        ]);

        if (! $res->successful() || ! $res->json('url')) {
            throw new RuntimeException('Could not start Stripe payment.');
        }
        $payment->update(['meta' => ['session_id' => $res->json('id')]]);
        return $res->json('url');
    }

    public function verify(string $reference): array
    {
        $payment = Payment::where('gateway', 'stripe')->where('reference', $reference)->first();
        $sessionId = $payment?->meta['session_id'] ?? null;
        if (! $sessionId) throw new RuntimeException('No Stripe session recorded for this payment.');

        $res = $this->http()->get('/checkout/sessions/'.rawurlencode($sessionId));
        if (! $res->successful()) throw new RuntimeException('Stripe verification request failed.');

        $d = $res->json();
        return [
            'successful' => ($d['payment_status'] ?? null) === 'paid' && ($d['client_reference_id'] ?? null) === $reference,
            'amount' => (int) ($d['amount_total'] ?? 0),
            'currency' => strtoupper((string) ($d['currency'] ?? '')),
            'transaction_id' => $d['payment_intent'] ?? null, // used for refunds
        ];
    }

    public function refund(Payment $payment, int $amount): array
    {
        if (! $payment->gateway_transaction_id) return ['ok' => false, 'message' => 'Missing Stripe payment intent.'];
        $res = $this->http()->post('/refunds', ['payment_intent' => $payment->gateway_transaction_id, 'amount' => $amount]);
        return ['ok' => $res->successful(), 'message' => $res->successful() ? 'Refund '.$res->json('status') : (string) ($res->json('error.message') ?? 'Stripe rejected the refund.')];
    }

    /** Stripe-Signature: t=timestamp,v1=hmac_sha256("t.payload", webhook secret). Rejects stale timestamps. */
    public function validWebhookSignature(Request $request): bool
    {
        $secret = (string) \App\Services\Credentials::get('stripe_webhook_secret');
        $header = (string) $request->header('Stripe-Signature');
        if ($secret === '' || $header === '') return false;

        $t = null; $sigs = [];
        foreach (explode(',', $header) as $part) {
            [$k, $v] = array_pad(explode('=', trim($part), 2), 2, '');
            if ($k === 't') $t = $v;
            if ($k === 'v1') $sigs[] = $v;
        }
        if (! $t || ! ctype_digit($t) || abs(time() - (int) $t) > self::TOLERANCE_SECONDS) return false;

        $expected = hash_hmac('sha256', $t.'.'.$request->getContent(), $secret);
        foreach ($sigs as $sig) if (hash_equals($expected, $sig)) return true;
        return false;
    }

    public function parseWebhook(Request $request): array
    {
        $b = $request->json()->all();
        $type = (string) ($b['type'] ?? '');
        // Only a completed Checkout is a payment signal; everything else is acknowledged and ignored.
        $ref = in_array($type, ['checkout.session.completed', 'checkout.session.async_payment_succeeded'], true)
            ? ($b['data']['object']['client_reference_id'] ?? null) : null;
        return ['event_id' => (string) ($b['id'] ?? ''), 'type' => $type, 'reference' => $ref];
    }
}
