<?php

namespace App\Services\Payments;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\Request;

interface Gateway
{
    public function name(): string;

    public function isEnabled(): bool;

    /** Server-side initialisation. Returns the hosted checkout URL. */
    public function initialize(Order $order, Payment $payment, string $callbackUrl): string;

    /**
     * Ask the provider directly about a transaction. Never trust the browser redirect.
     *
     * @return array{successful: bool, amount: int, currency: string, transaction_id: ?string}
     */
    public function verify(string $reference): array;

    /**
     * Request a (partial) refund. Amount in minor units. Providers may complete it asynchronously.
     *
     * @return array{ok: bool, message: string}
     */
    public function refund(Payment $payment, int $amount): array;

    public function validWebhookSignature(Request $request): bool;

    /** @return array{event_id: string, type: string, reference: ?string} */
    public function parseWebhook(Request $request): array;
}
