<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Resizes uploads (max 1600px wide) and converts to WebP using GD, plus a 600px "-thumb" copy.
 * Falls back to storing the original file when GD/WebP is unavailable, so uploads never fail because of it.
 */
class ImageStore
{
    public static function put(UploadedFile $file, string $dir): string
    {
        $src = static::canOptimise() ? @imagecreatefromstring((string) file_get_contents($file->getRealPath())) : false;
        if (! $src) return $file->store($dir, \App\Support\Media::diskName());

        $name = $dir.'/'.Str::uuid();
        \App\Support\Media::disk()->put($name.'.webp', static::encode($src, 1600));
        \App\Support\Media::disk()->put($name.'-thumb.webp', static::encode($src, 600));
        imagedestroy($src);
        return $name.'.webp';
    }

    public static function delete(?string $path): void
    {
        if (! $path) return;
        $disk = \App\Support\Media::disk();
        $disk->delete($path);
        if (str_ends_with($path, '.webp')) $disk->delete(substr($path, 0, -5).'-thumb.webp');
    }

    /** Thumbnail path if this image was optimised by put(); otherwise the original. */
    public static function thumb(string $path): string
    {
        return str_ends_with($path, '.webp') && ! str_ends_with($path, '-thumb.webp') ? substr($path, 0, -5).'-thumb.webp' : $path;
    }

    private static function canOptimise(): bool
    {
        return extension_loaded('gd') && function_exists('imagewebp');
    }

    private static function encode($src, int $maxWidth): string
    {
        $w = imagesx($src); $h = imagesy($src);
        $nw = min($w, $maxWidth); $nh = (int) round($h * ($nw / $w));
        $dst = imagecreatetruecolor($nw, $nh);
        imagealphablending($dst, false); imagesavealpha($dst, true);
        imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 255, 255, 255, 127));
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
        ob_start(); imagewebp($dst, null, 82); $bin = ob_get_clean();
        imagedestroy($dst);
        return $bin;
    }
}
