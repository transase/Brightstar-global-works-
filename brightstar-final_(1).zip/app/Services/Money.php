<?php

namespace App\Services;

use App\Models\Setting;

class Money
{
    public static function currency(): string
    {
        return Setting::get('currency', config('store.currency', 'NGN'));
    }

    public static function symbol(?string $currency = null): string
    {
        return match ($currency ?? static::currency()) {
            'NGN' => '₦', 'USD' => '$', 'GBP' => '£', 'EUR' => '€', 'GHS' => 'GH₵', default => ($currency ?? static::currency()).' ',
        };
    }

    /** Format minor units (kobo) for display. */
    public static function format(int $minor, ?string $currency = null): string
    {
        return static::symbol($currency).number_format($minor / 100, 2);
    }
}
