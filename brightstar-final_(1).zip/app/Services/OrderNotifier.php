<?php

namespace App\Services;

use App\Mail\OrderMail;
use App\Models\Order;
use App\Models\Setting;
use Illuminate\Support\Facades\Mail;

/** Emails never block or break an order: failures are reported, not thrown. */
class OrderNotifier
{
    private function send(string $to, OrderMail $mail): void
    {
        try { Mail::to($to)->queue($mail); } catch (\Throwable $e) { report($e); }
    }

    private function admin(Order $order): void
    {
        if ($to = Setting::get('store_email')) $this->send($to, new OrderMail($order, 'admin'));
    }

    /** Offline methods (COD, bank transfer, WhatsApp) are confirmed on placement; gateway orders wait for payment. */
    public function placed(Order $order): void
    {
        if (in_array($order->payment_method, OrderService::GATEWAYS, true)) return;
        $this->send($order->email, new OrderMail($order, 'received'));
        $this->admin($order);
    }

    public function paid(Order $order): void
    {
        $this->send($order->email, new OrderMail($order, 'paid'));
        $this->admin($order);
    }

    public function statusChanged(Order $order, string $status): void
    {
        if (in_array($status, ['processing', 'ready_for_dispatch', 'shipped', 'delivered', 'cancelled'], true)) {
            $this->send($order->email, new OrderMail($order, 'status', $status));
        }
    }
}
