<?php

namespace App\Services;

use App\Models\Setting;

/** Gateway/SMTP credentials: value saved in Admin → Settings wins; falls back to the server's .env/config. */
class Credentials
{
    public const MAP = [
        'paystack_secret' => 'services.paystack.secret',
        'flutterwave_secret' => 'services.flutterwave.secret',
        'flutterwave_webhook_hash' => 'services.flutterwave.webhook_hash',
        'stripe_secret' => 'services.stripe.secret',
        'stripe_webhook_secret' => 'services.stripe.webhook_secret',
        'mail_password' => 'mail.mailers.smtp.password',
    ];

    public static function get(string $name): ?string
    {
        $v = Setting::secret($name);
        return filled($v) ? $v : (config(self::MAP[$name] ?? '') ?: null);
    }

    /** 'admin' | 'env' | null — where the value currently comes from (for the settings screen). */
    public static function source(string $name): ?string
    {
        if (Setting::hasSecret($name)) return 'admin';
        return filled(config(self::MAP[$name] ?? '')) ? 'env' : null;
    }
}
