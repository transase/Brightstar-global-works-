<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class OrderService
{
    public const FULFILMENT = ['pending_confirmation', 'awaiting_payment', 'processing', 'ready_for_dispatch', 'shipped', 'delivered', 'cancelled'];
    public const GATEWAYS = ['paystack', 'flutterwave', 'stripe'];

    public function update(Order $order, array $data, ?int $userId): Order
    {
        $changedTo = null;
        $result = DB::transaction(function () use ($order, $data, $userId, &$changedTo) {
            $order = Order::whereKey($order->id)->lockForUpdate()->first();

            if (isset($data['payment_status']) && $data['payment_status'] !== $order->payment_status) {
                // Gateway payments are only ever settled by server-side verification, never by hand.
                if (in_array($order->payment_method, self::GATEWAYS, true) && $data['payment_status'] === 'paid') {
                    throw new InvalidArgumentException('Online payments are marked paid only after provider verification.');
                }
                $becamePaid = $data['payment_status'] === 'paid' && $order->payment_status !== 'paid';
                $order->log('payment_status_changed', "{$order->payment_status} → {$data['payment_status']}", $userId);
                $order->payment_status = $data['payment_status'];
                if ($becamePaid) {
                    $order->items->each(fn ($i) => $i->product_id && Product::whereKey($i->product_id)->increment('sales_count', $i->quantity));
                }
            }

            if (isset($data['fulfilment_status']) && $data['fulfilment_status'] !== $order->fulfilment_status) {
                if ($data['fulfilment_status'] === 'cancelled') $this->restoreStock($order);
                $order->log('status_changed', "{$order->fulfilment_status} → {$data['fulfilment_status']}", $userId);
                $order->fulfilment_status = $data['fulfilment_status'];
                $changedTo = $data['fulfilment_status'];
            }

            if (array_key_exists('admin_notes', $data)) $order->admin_notes = $data['admin_notes'];
            $order->save();
            return $order;
        });

        if ($changedTo) app(OrderNotifier::class)->statusChanged($result, $changedTo);
        return $result;
    }

    /** Returns reserved stock exactly once. */
    private function restoreStock(Order $order): void
    {
        if ($order->fulfilment_status === 'cancelled') return;
        foreach ($order->items as $i) {
            $product = $i->product_id ? Product::find($i->product_id) : null;
            if (! $product || ! $product->track_stock) continue;
            $i->variant_id && ($v = ProductVariant::find($i->variant_id))
                ? $v->increment('stock_quantity', $i->quantity)
                : $product->increment('stock_quantity', $i->quantity);
        }
        $order->log('stock_restored', 'Reserved stock returned on cancellation.');
    }
}
