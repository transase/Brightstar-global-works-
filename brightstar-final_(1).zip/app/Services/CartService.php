<?php

namespace App\Services;

use App\Models\Cart;
use App\Models\Coupon;
use App\Models\DeliveryZone;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class CartService
{
    private ?Cart $cart = null;

    public function cart(bool $create = true): ?Cart
    {
        if ($this->cart) return $this->cart;

        $token = session('cart_token');
        if (Auth::check()) {
            $cart = Cart::firstOrCreate(['user_id' => Auth::id()]);
            // Merge a guest cart into the customer's cart on login.
            if ($token && ($guest = Cart::where('session_token', $token)->whereNull('user_id')->first())) {
                foreach ($guest->items as $item) {
                    $existing = $cart->items()->where('product_id', $item->product_id)->where('variant_id', $item->variant_id)->first();
                    $existing ? $existing->increment('quantity', $item->quantity) : $item->update(['cart_id' => $cart->id]);
                }
                $guest->delete();
                session()->forget('cart_token');
            }
            return $this->cart = $cart;
        }

        if (! $token) {
            if (! $create) return null;
            $token = Str::random(40);
            session(['cart_token' => $token]);
        }
        return $this->cart = $create
            ? Cart::firstOrCreate(['session_token' => $token, 'user_id' => null])
            : Cart::where('session_token', $token)->first();
    }

    public function add(Product $product, ?int $variantId, int $qty): void
    {
        $qty = max(1, min($qty, 99));
        $variant = $variantId ? ProductVariant::where('product_id', $product->id)->findOrFail($variantId) : null;
        if ($product->variants()->where('is_active', true)->exists() && ! $variant) {
            abort(422, 'Please choose an option before adding to cart.');
        }

        $item = $this->cart()->items()->firstOrNew(['product_id' => $product->id, 'variant_id' => $variant?->id]);
        $newQty = ($item->quantity ?? 0) + $qty;
        abort_unless($product->canBePurchased($newQty, $variant), 422, 'That quantity is not available.');
        $item->quantity = $newQty;
        $item->save();
    }

    public function setQuantity(int $itemId, int $qty): void
    {
        $item = $this->cart()->items()->findOrFail($itemId);
        $qty <= 0 ? $item->delete() : $item->update(['quantity' => min($qty, 99)]);
    }

    /** Switch a cart line to another option of the same product, merging with an existing line if needed. */
    public function changeVariant(int $itemId, int $variantId): void
    {
        $item = $this->cart()->items()->with('product')->findOrFail($itemId);
        $variant = ProductVariant::where('product_id', $item->product_id)->where('is_active', true)->findOrFail($variantId);
        abort_unless($item->product->canBePurchased($item->quantity, $variant), 422, 'That option is not available in this quantity.');

        $existing = $this->cart()->items()->where('product_id', $item->product_id)->where('variant_id', $variant->id)->where('id', '!=', $item->id)->first();
        if ($existing) {
            $merged = $existing->quantity + $item->quantity;
            abort_unless($item->product->canBePurchased($merged, $variant), 422, 'That option is not available in this quantity.');
            $existing->update(['quantity' => min(99, $merged)]);
            $item->delete();
        } else {
            $item->update(['variant_id' => $variant->id]);
        }
    }

    public function remove(int $itemId): void
    {
        $this->cart()->items()->whereKey($itemId)->delete();
    }

    public function applyCoupon(?string $code): bool
    {
        $cart = $this->cart();
        if (! $code) { $cart->update(['coupon_code' => null]); return true; }
        $coupon = Coupon::where('code', strtoupper(trim($code)))->first();
        if (! $coupon || ! $coupon->isUsable($this->calculate()['subtotal'])) return false;
        $cart->update(['coupon_code' => $coupon->code]);
        return true;
    }

    public function count(): int
    {
        $cart = $this->cart(false);
        return $cart ? (int) $cart->items()->sum('quantity') : 0;
    }

    /**
     * Server-side recalculation. Prices ALWAYS come from the database, never from the browser.
     * Returns lines plus totals in minor units, and any stock problems.
     */
    public function calculate(?DeliveryZone $zone = null): array
    {
        $cart = $this->cart(false);
        $lines = [];
        $issues = [];
        $subtotal = 0;

        foreach ($cart?->items()->with(['product.variants', 'variant'])->get() ?? [] as $item) {
            $p = $item->product;
            if (! $p || ! $p->canBePurchased($item->quantity, $item->variant)) {
                $issues[] = ($p?->name ?? 'An item').' is no longer available in the quantity requested.';
                continue;
            }
            $unit = $p->priceFor($item->variant);
            $lineTotal = $unit * $item->quantity;
            $subtotal += $lineTotal;
            $lines[] = [
                'item_id' => $item->id,
                'product' => $p,
                'variant' => $item->variant,
                'name' => $p->name,
                'sku' => $item->variant?->sku ?: $p->sku,
                'variant_label' => $item->variant?->label(),
                'unit_price' => $unit,
                'quantity' => $item->quantity,
                'line_total' => $lineTotal,
            ];
        }

        $discount = 0;
        $coupon = $cart?->coupon_code ? Coupon::where('code', $cart->coupon_code)->first() : null;
        if ($coupon && $coupon->isUsable($subtotal)) {
            $discount = $coupon->discountFor($subtotal);
        } else {
            $coupon = null;
        }

        $net = max(0, $subtotal - $discount);
        $freeFrom = (int) \App\Models\Setting::get('free_delivery_min', 0);
        $delivery = ($freeFrom > 0 && $net >= $freeFrom) ? 0 : ($zone?->fee ?? 0);
        $tax = (int) round($net * ((float) \App\Models\Setting::get('tax_rate', 0)) / 100);

        return [
            'lines' => $lines,
            'issues' => $issues,
            'coupon' => $coupon,
            'subtotal' => $subtotal,
            'discount' => $discount,
            'delivery_fee' => $delivery,
            'tax' => $tax,
            'total' => max(0, $net + $delivery + $tax),
        ];
    }

    public function clear(): void
    {
        $this->cart(false)?->items()->delete();
        $this->cart(false)?->update(['coupon_code' => null]);
    }
}
