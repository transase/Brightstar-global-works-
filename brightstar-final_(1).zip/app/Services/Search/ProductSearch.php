<?php

namespace App\Services\Search;

use Illuminate\Database\Eloquent\Builder;

/**
 * The ONLY place that knows how product text search works. Today: indexed-column LIKE queries on
 * name/SKU/short description (SKU has a unique index). To move to Meilisearch/Algolia/Scout later,
 * replace apply() (e.g. whereIn('id', $engine->ids($term))) without touching controllers or views.
 */
class ProductSearch
{
    public function apply(Builder $query, string $term): Builder
    {
        $term = trim($term);
        if ($term === '') return $query;
        // "!" is the escape character: supported by MySQL/MariaDB and SQLite alike.
        $like = '%'.str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $term).'%';

        return $query->where(fn ($w) => $w->whereRaw("name LIKE ? ESCAPE '!'", [$like])
            ->orWhereRaw("sku LIKE ? ESCAPE '!'", [$like])
            ->orWhereRaw("short_description LIKE ? ESCAPE '!'", [$like])
            ->orWhereRaw("brand LIKE ? ESCAPE '!'", [$like]));
    }
}
