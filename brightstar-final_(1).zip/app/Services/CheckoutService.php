<?php

namespace App\Services;

use App\Models\DeliveryZone;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class CheckoutService
{
    public function __construct(private CartService $cart) {}

    /**
     * Re-validates the cart and creates the order in one transaction.
     * Stock is reserved here (row-locked) so two buyers cannot take the last unit.
     *
     * @param array $data validated customer/address data
     */
    public function placeOrder(array $data, string $paymentMethod, string $source = 'web'): Order
    {
        $zone = ! empty($data['delivery_zone_id']) ? DeliveryZone::where('is_active', true)->find($data['delivery_zone_id']) : null;
        $totals = $this->cart->calculate($zone);

        if ($totals['issues'] || empty($totals['lines'])) {
            throw new RuntimeException($totals['issues'][0] ?? 'Your cart is empty.');
        }

        return DB::transaction(function () use ($data, $paymentMethod, $source, $totals) {
            foreach ($totals['lines'] as $line) {
                /** @var Product $product */
                $product = Product::whereKey($line['product']->id)->lockForUpdate()->first();
                $variant = $line['variant'] ? ProductVariant::whereKey($line['variant']->id)->lockForUpdate()->first() : null;

                if (! $product->canBePurchased($line['quantity'], $variant)) {
                    throw new RuntimeException("{$product->name} just went out of stock.");
                }
                if ($product->track_stock) {
                    $variant ? $variant->decrement('stock_quantity', $line['quantity']) : $product->decrement('stock_quantity', $line['quantity']);
                }
            }

            $isWhatsApp = $paymentMethod === 'whatsapp';
            $order = Order::create([
                'number' => Order::generateNumber(),
                'user_id' => Auth::id(),
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'email' => $data['email'],
                'phone' => $data['phone'],
                'shipping_address' => [
                    'address' => $data['address'], 'city' => $data['city'], 'state' => $data['state'],
                    'postal_code' => $data['postal_code'] ?? null, 'country' => $data['country'],
                ],
                'billing_address' => $data['billing_address'] ?? null,
                'delivery_instructions' => $data['delivery_instructions'] ?? null,
                'currency' => Money::currency(),
                'subtotal' => $totals['subtotal'],
                'discount' => $totals['discount'],
                'tax' => $totals['tax'],
                'delivery_fee' => $totals['delivery_fee'],
                'total' => $totals['total'],
                'coupon_code' => $totals['coupon']?->code,
                'payment_method' => $paymentMethod,
                'payment_status' => 'unpaid',
                // WhatsApp orders stay pending until staff confirm them.
                'fulfilment_status' => $isWhatsApp || in_array($paymentMethod, ['cod', 'bank_transfer'], true)
                    ? 'pending_confirmation' : 'awaiting_payment',
                'source' => $source,
            ]);

            foreach ($totals['lines'] as $line) {
                $order->items()->create([
                    'product_id' => $line['product']->id,
                    'variant_id' => $line['variant']?->id,
                    'name' => $line['name'],
                    'sku' => $line['sku'],
                    'variant_label' => $line['variant_label'],
                    'unit_price' => $line['unit_price'],
                    'quantity' => $line['quantity'],
                    'line_total' => $line['line_total'],
                ]);
            }

            if ($totals['coupon']) {
                // Re-check under a row lock so concurrent orders cannot exceed max_uses.
                $coupon = \App\Models\Coupon::whereKey($totals['coupon']->id)->lockForUpdate()->first();
                if (! $coupon || ! $coupon->isUsable($totals['subtotal'])) throw new RuntimeException('That coupon is no longer valid. Please remove it and try again.');
                $coupon->increment('used_count');
            }
            $order->log('order_created', "Created via {$source} using {$paymentMethod}.");
            $this->cart->clear();

            return $order;
        });
    }
}
