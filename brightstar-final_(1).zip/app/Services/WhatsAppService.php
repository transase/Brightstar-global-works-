<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Setting;

/**
 * Builds Click-to-Chat links. The phone number always comes from admin settings.
 * Templates and the greeting are editable in Admin → Settings → WhatsApp.
 */
class WhatsAppService
{
    public function phone(): ?string
    {
        return static::normalisePhone((string) Setting::get('whatsapp_phone', ''));
    }

    /** Digits only, international format without "+" (what wa.me expects). Null if implausible. */
    public static function normalisePhone(string $raw): ?string
    {
        $digits = preg_replace('/\D+/', '', $raw);
        return ($digits !== '' && strlen($digits) >= 8 && strlen($digits) <= 15) ? $digits : null;
    }

    public function link(string $message): ?string
    {
        $phone = $this->phone();
        if (! $phone) return null; // not configured: callers hide the button
        return 'https://wa.me/'.$phone.'?text='.rawurlencode($message);
    }

    public function store(): string { return (string) Setting::get('store_name', 'Brightstar Global Furniture'); }

    /** The opening line. Admin can override with their own greeting. */
    public function greeting(): string
    {
        return (string) Setting::get('wa_greeting', 'Hello '.$this->store().',');
    }

    public function productMessage(Product $product, ?ProductVariant $variant, int $qty, string $url): string
    {
        $tpl = (string) Setting::get('wa_product_template', <<<'TPL'
{greeting}

I am interested in this furniture product.

Product: {product}
SKU: {sku}
Selected Variant: {variant}
Quantity: {quantity}
Listed Price: {price}
Product Link: {url}

Please confirm availability and delivery details.

Thank you.
TPL);

        return strtr($tpl, [
            '{greeting}' => $this->greeting(),
            '{store}' => $this->store(),
            '{product}' => $product->name,
            '{sku}' => $variant?->sku ?: $product->sku,
            '{variant}' => $variant?->label() ?: 'Standard',
            '{quantity}' => (string) max(1, $qty),
            '{price}' => $product->enquiry_only ? 'Price on request' : Money::format($product->priceFor($variant)),
            '{url}' => $url,
        ]);
    }

    /** @param array{lines: array, subtotal: int, discount: int, delivery_fee: int, total: int, tax?: int} $totals */
    public function cartMessage(array $totals, string $cartUrl, ?Order $order = null): string
    {
        $items = [];
        foreach ($totals['lines'] as $i => $l) {
            $items[] = ($i + 1).'. '.$l['name'].($l['variant_label'] ? ' ('.$l['variant_label'].')' : '')
                .' x'.$l['quantity'].' - '.Money::format($l['line_total']);
        }
        $tax = (int) ($totals['tax'] ?? 0);
        $address = '';
        if ($order) {
            $a = $order->shipping_address;
            $address = collect([$a['address'] ?? null, $a['city'] ?? null, $a['state'] ?? null])->filter()->implode(', ');
        }

        $parts = [
            '{greeting}' => $this->greeting(), '{store}' => $this->store(),
            '{items}' => implode("\n", $items),
            '{subtotal}' => Money::format($totals['subtotal']),
            '{discount}' => $totals['discount'] > 0 ? '-'.Money::format($totals['discount']) : '',
            '{tax}' => $tax > 0 ? Money::format($tax) : '',
            '{delivery}' => $totals['delivery_fee'] > 0 ? Money::format($totals['delivery_fee']) : '',
            '{total}' => Money::format($totals['total']),
            '{url}' => $cartUrl, '{order}' => $order?->number ?? '',
            '{customer}' => $order ? "{$order->first_name} {$order->last_name}" : '', '{phone}' => $order?->phone ?? '', '{address}' => $address,
        ];

        // Admin-defined cart template wins when set.
        if ($custom = trim((string) Setting::get('wa_cart_template', ''))) {
            return strtr($custom, $parts);
        }

        $msg = $this->greeting()."\n\n";
        $msg .= $order ? "I would like to complete order {$order->number}.\n\n" : "I would like to order the following:\n\n";
        $msg .= $parts['{items}']."\n\n";
        $msg .= 'Subtotal: '.$parts['{subtotal}']."\n";
        if ($parts['{discount}'] !== '') $msg .= 'Discount: '.$parts['{discount}']."\n";
        if ($tax > 0) $msg .= Setting::get('tax_label', 'Tax').': '.$parts['{tax}']."\n";
        if ($parts['{delivery}'] !== '') $msg .= 'Delivery: '.$parts['{delivery}']."\n";
        $msg .= 'Total: '.$parts['{total}']."\n\n";
        if ($order) {
            $msg .= "Name: {$parts['{customer}']}\nPhone: {$order->phone}\nDelivery address: {$address}\n\n";
        }
        return $msg."Link: {$cartUrl}\n\nPlease confirm availability and delivery details. Thank you.";
    }

    public function generalMessage(): string
    {
        return (string) Setting::get('wa_general_template', $this->greeting().' I have a question about your furniture.');
    }
}
