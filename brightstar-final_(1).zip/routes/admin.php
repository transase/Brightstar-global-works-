<?php

use App\Http\Controllers\Admin;
use Illuminate\Support\Facades\Route;

Route::prefix('admin')->name('admin.')->middleware(['auth', 'verified'])->group(function () {

    // Admin, manager and staff
    Route::middleware('role:manager,staff')->group(function () {
        Route::get('/', Admin\DashboardController::class)->name('dashboard');
        Route::get('orders', [Admin\OrderController::class, 'index'])->name('orders.index');
        Route::get('orders/{order}', [Admin\OrderController::class, 'show'])->name('orders.show');
        Route::get('orders/{order}/invoice', [Admin\OrderController::class, 'invoice'])->name('orders.invoice');
        Route::patch('orders/{order}', [Admin\OrderController::class, 'update'])->name('orders.update');
    });

    // Admin and manager: catalogue, marketing, payments
    Route::middleware('role:manager')->group(function () {
        Route::get('products/export', [Admin\ProductCsvController::class, 'export'])->name('products.export');
        Route::post('products/import', [Admin\ProductCsvController::class, 'import'])->name('products.import');
        Route::post('products/bulk', [Admin\ProductController::class, 'bulk'])->name('products.bulk');
        Route::post('products/{product}/duplicate', [Admin\ProductController::class, 'duplicate'])->name('products.duplicate');
        Route::delete('products/{product}/images/{image}', [Admin\ProductController::class, 'deleteImage'])->name('products.images.delete');
        Route::post('products/{product}/images/reorder', [Admin\ProductController::class, 'reorderImages'])->name('products.images.reorder');
        Route::resource('products', Admin\ProductController::class)->except('show');

        Route::post('categories/reorder', [Admin\CategoryController::class, 'reorder'])->name('categories.reorder');
        Route::resource('categories', Admin\CategoryController::class)->except('show');

        Route::get('coupons', [Admin\CouponController::class, 'index'])->name('coupons.index');
        Route::post('coupons', [Admin\CouponController::class, 'store'])->name('coupons.store');
        Route::patch('coupons/{coupon}', [Admin\CouponController::class, 'toggle'])->name('coupons.toggle');
        Route::delete('coupons/{coupon}', [Admin\CouponController::class, 'destroy'])->name('coupons.destroy');

        Route::get('reviews', [Admin\ReviewController::class, 'index'])->name('reviews.index');
        Route::patch('reviews/{review}', [Admin\ReviewController::class, 'update'])->name('reviews.update');
        Route::delete('reviews/{review}', [Admin\ReviewController::class, 'destroy'])->name('reviews.destroy');

        Route::post('nav/defaults', [Admin\NavController::class, 'defaults'])->name('nav.defaults');
        Route::resource('nav', Admin\NavController::class)->except(['show', 'create'])->parameters(['nav' => 'nav']);
        Route::resource('pages', Admin\PageController::class)->except(['show', 'create']);
        Route::resource('articles', Admin\ArticleController::class)->except('show');
        Route::get('newsletter', [Admin\NewsletterController::class, 'index'])->name('newsletter.index');
        Route::post('newsletter/send', [Admin\NewsletterController::class, 'send'])->name('newsletter.send');
        Route::resource('zones', Admin\DeliveryZoneController::class)->only(['index', 'store', 'update', 'destroy'])->parameters(['zones' => 'zone']);
        Route::resource('collections', Admin\CollectionController::class)->except(['show', 'create']);
        Route::resource('benefits', Admin\BenefitController::class)->only(['index', 'store', 'update', 'destroy']);
        Route::post('categories/{category}/move', [Admin\CategoryController::class, 'move'])->name('categories.move');
        Route::post('products/{product}/images/{image}/move', [Admin\ProductController::class, 'moveImage'])->name('products.images.move');
        Route::resource('slides', Admin\SlideController::class)->except(['show', 'create']);

        Route::get('payments', [Admin\PaymentController::class, 'index'])->name('payments.index');
        Route::post('payments/{payment}/reverify', [Admin\PaymentController::class, 'reverify'])->name('payments.reverify');
    });

    // Admin only: money movement and settings
    Route::middleware('role:admin')->group(function () {
        Route::post('payments/{payment}/refund', [Admin\PaymentController::class, 'refund'])->name('payments.refund');
        Route::get('settings', [Admin\SettingsController::class, 'edit'])->name('settings.edit');
        Route::post('settings/test-mail', [Admin\SettingsController::class, 'testMail'])->name('settings.test-mail');
        Route::resource('users', Admin\UserController::class)->only(['index', 'store', 'update', 'destroy']);
        Route::put('settings', [Admin\SettingsController::class, 'update'])->name('settings.update');
    });
});
