<?php

use Illuminate\Support\Facades\Schedule;

// Requires a cron entry: * * * * * php /path/to/artisan schedule:run
Schedule::command('orders:release-stale')->hourly();
