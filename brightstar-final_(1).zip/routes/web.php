<?php

use App\Http\Controllers\Shop\CartController;
use App\Http\Controllers\Shop\CheckoutController;
use App\Http\Controllers\Shop\HomeController;
use App\Http\Controllers\Shop\PaymentController;
use App\Http\Controllers\Shop\ShopController;
use Illuminate\Support\Facades\Route;

Route::get('/install', [\App\Http\Controllers\InstallController::class, 'show'])->name('install.show');
Route::post('/install', [\App\Http\Controllers\InstallController::class, 'store'])->middleware('throttle:10,1')->name('install.store');

Route::get('/', HomeController::class)->name('home');

Route::get('/shop', [ShopController::class, 'index'])->name('shop');
Route::get('/category/{category:slug}', [ShopController::class, 'index'])->name('category.show');
Route::get('/product/{product:slug}', [ShopController::class, 'show'])->name('product.show');

Route::get('/product/{product:slug}/quick', [ShopController::class, 'quick'])->name('product.quick');
Route::get('/collections', [\App\Http\Controllers\Shop\CollectionController::class, 'index'])->name('collections.index');
Route::get('/collections/{slug}', [\App\Http\Controllers\Shop\CollectionController::class, 'show'])->name('collections.show');
Route::get('/product/{product:slug}/whatsapp', [ShopController::class, 'whatsapp'])->name('product.whatsapp');
Route::post('/newsletter', function (\Illuminate\Http\Request $r) {
    $r->validate(['email' => 'required|email|max:160']);
    $sub = \App\Models\NewsletterSubscriber::firstOrCreate(['email' => strtolower($r->email)]);
    if ($sub->unsubscribed_at) $sub->update(['unsubscribed_at' => null]); // explicit re-subscribe
    return back()->with('status', 'Thanks for subscribing.');
})->middleware('throttle:5,1')->name('newsletter');
Route::get('/newsletter/unsubscribe/{token}', function (string $token) {
    $sub = \App\Models\NewsletterSubscriber::where('token', $token)->first();
    $sub?->update(['unsubscribed_at' => now()]);
    return redirect()->route('home')->with('status', $sub ? 'You have been unsubscribed.' : 'That link is no longer valid.');
})->name('newsletter.unsubscribe');

Route::post('/product/{product:slug}/reviews', function (\Illuminate\Http\Request $r, \App\Models\Product $product) {
    abort_unless($product->status === 'published', 404);
    $d = $r->validate(['author_name' => 'required|string|max:80', 'rating' => 'required|integer|between:1,5', 'body' => 'nullable|string|max:2000']);
    $verified = $r->user() && \App\Models\Order::where('user_id', $r->user()->id)->where('payment_status', 'paid')
        ->whereHas('items', fn ($q) => $q->where('product_id', $product->id))->exists();
    $product->reviews()->create($d + ['user_id' => $r->user()?->id, 'is_verified_purchase' => $verified, 'status' => 'pending']);
    return back()->with('status', 'Thanks! Your review will appear once approved.');
})->middleware('throttle:5,10')->name('reviews.store');

Route::get('/sitemap.xml', [\App\Http\Controllers\Shop\SeoController::class, 'sitemap'])->name('sitemap');
Route::get('/robots.txt', [\App\Http\Controllers\Shop\SeoController::class, 'robots']);
Route::middleware(['auth', 'verified'])->prefix('account')->name('account.')->group(function () {
    Route::get('orders', [\App\Http\Controllers\Shop\AccountController::class, 'orders'])->name('orders');
    Route::get('orders/{number}', [\App\Http\Controllers\Shop\AccountController::class, 'show'])->name('order');
    Route::post('orders/{number}/reorder', [\App\Http\Controllers\Shop\AccountController::class, 'reorder'])->name('reorder');
});
Route::middleware('auth')->group(function () {
    Route::get('/wishlist', [\App\Http\Controllers\Shop\WishlistController::class, 'index'])->name('wishlist');
    Route::post('/wishlist/{product}', [\App\Http\Controllers\Shop\WishlistController::class, 'toggle'])->name('wishlist.toggle');
});

Route::get('/about', fn () => app(\App\Http\Controllers\Shop\PageController::class)->show('about'))->name('page.about');
Route::get('/contact', fn () => app(\App\Http\Controllers\Shop\PageController::class)->show('contact'))->name('page.contact');
Route::get('/page/{slug}', [\App\Http\Controllers\Shop\PageController::class, 'show'])->name('page.show');

Route::get('/ideas', [\App\Http\Controllers\Shop\ArticleController::class, 'index'])->name('ideas.index');
Route::get('/ideas/{slug}', [\App\Http\Controllers\Shop\ArticleController::class, 'show'])->name('ideas.show');

Route::get('/cart', [CartController::class, 'show'])->name('cart.show');
Route::post('/cart/add/{product}', [CartController::class, 'add'])->name('cart.add');
Route::patch('/cart/items/{item}', [CartController::class, 'update'])->name('cart.update');
Route::delete('/cart/items/{item}', [CartController::class, 'remove'])->name('cart.remove');
Route::post('/cart/coupon', [CartController::class, 'coupon'])->name('cart.coupon');

Route::get('/checkout', [CheckoutController::class, 'show'])->name('checkout.show');
Route::post('/checkout', [CheckoutController::class, 'store'])->middleware('throttle:10,1')->name('checkout.store');
Route::get('/order/{number}', [CheckoutController::class, 'order'])->name('order.show');
Route::post('/order/{number}/pay/{gateway}', [CheckoutController::class, 'pay'])->middleware('throttle:10,1')->name('order.pay');
Route::post('/order/{number}/whatsapp-opened', [CheckoutController::class, 'whatsappHandoff'])->name('order.whatsapp');

Route::get('/payment/callback/{gateway}', [PaymentController::class, 'callback'])->name('payment.callback');
// Excluded from CSRF in bootstrap/app.php; authenticity is proven by signature verification.
Route::post('/webhooks/{gateway}', [PaymentController::class, 'webhook'])->name('payment.webhook');

// Customer account landing (Breeze provides login, registration, verification, password reset).
Route::get('/dashboard', function () {
    return in_array(auth()->user()->role, ['admin', 'manager', 'staff'], true)
        ? redirect()->route('admin.dashboard')
        : redirect()->route('account.orders');
})->middleware(['auth', 'verified'])->name('dashboard');

// Breeze's profile pages (its own views link to these route names).
if (class_exists(\App\Http\Controllers\ProfileController::class)) {
    Route::middleware('auth')->group(function () {
        Route::get('/profile', [\App\Http\Controllers\ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [\App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [\App\Http\Controllers\ProfileController::class, 'destroy'])->name('profile.destroy');
    });
}

if (file_exists(__DIR__.'/auth.php')) require __DIR__.'/auth.php';
if (file_exists(__DIR__.'/admin.php')) require __DIR__.'/admin.php';
