<?php
/**
 * Applies the small edits the overlay needs to a fresh Laravel project. Idempotent.
 * Usage: php scripts/patch-laravel.php /path/to/laravel-project
 */
$root = rtrim($argv[1] ?? getcwd(), '/\\');
$failed = [];

function edit(string $file, callable $fn, string $label): void
{
    global $root, $failed;
    $path = $root.'/'.$file;
    if (! file_exists($path)) { $failed[] = "$label: $file not found"; return; }
    $old = file_get_contents($path);
    $new = $fn($old);
    if ($new === null) { $failed[] = "$label: pattern not found in $file"; return; }
    if ($new !== $old) file_put_contents($path, $new);
    echo "  ok  $label\n";
}

/** Insert text before the final "];" of a PHP array file. */
$beforeLastBracket = function (string $insert) {
    return function (string $s) use ($insert) {
        $pos = strrpos($s, '];');
        return $pos === false ? null : substr($s, 0, $pos).$insert.substr($s, $pos);
    };
};

edit('config/services.php', function ($s) use ($beforeLastBracket) {
    if (str_contains($s, "'paystack'")) return $s;
    return $beforeLastBracket("\n    'paystack' => [\n        'secret' => env('PAYSTACK_SECRET_KEY'),\n        'public' => env('PAYSTACK_PUBLIC_KEY'),\n    ],\n\n    'flutterwave' => [\n        'secret' => env('FLUTTERWAVE_SECRET_KEY'),\n        'webhook_hash' => env('FLUTTERWAVE_WEBHOOK_HASH'),\n    ],\n\n    'stripe' => [\n        'secret' => env('STRIPE_SECRET_KEY'),\n        'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),\n    ],\n\n")($s);
}, 'payment gateway config');

edit('bootstrap/app.php', function ($s) {
    if (str_contains($s, 'EnsureRole')) return $s;
    $lines = "        \$middleware->alias(['role' => \\App\\Http\\Middleware\\EnsureRole::class]);\n"
        ."        \$middleware->validateCsrfTokens(except: ['webhooks/*']);\n"
        ."        \$middleware->append(\\App\\Http\\Middleware\\SecurityHeaders::class);\n"
        ."        \$middleware->web(append: [\\App\\Http\\Middleware\\RedirectIfNotInstalled::class]);\n";
    $r = preg_replace_callback('~->withMiddleware\(function \(Middleware \$middleware\)(\s*:\s*void)?\s*\{(.*?)\}\)~s', function ($m) use ($lines) {
        $body = trim(preg_replace('~^\s*//.*$~m', '', $m[2]));
        return '->withMiddleware(function (Middleware $middleware)'.($m[1] ?? '')." {\n".($body !== '' ? '        '.$body."\n" : '').$lines.'    })';
    }, $s, 1, $count);
    return $count ? $r : null;
}, 'middleware (role alias, webhook CSRF exemption, security headers, installer redirect)');

edit('bootstrap/providers.php', function ($s) use ($beforeLastBracket) {
    return str_contains($s, 'StoreSettingsServiceProvider') ? $s : $beforeLastBracket("    App\\Providers\\StoreSettingsServiceProvider::class,\n")($s);
}, 'settings service provider');

edit('app/Models/User.php', function ($s) {
    $s = preg_replace('~^//\s*(use Illuminate\\\\Contracts\\\\Auth\\\\MustVerifyEmail;)~m', '$1', $s);
    if (! str_contains($s, 'use Illuminate\Contracts\Auth\MustVerifyEmail;')) {
        $s = preg_replace('~(namespace App\\\\Models;\s*)~', "$1\nuse Illuminate\\Contracts\\Auth\\MustVerifyEmail;\n", $s, 1);
    }
    if (! preg_match('~class User extends Authenticatable\s+implements~', $s)) {
        $s = preg_replace('~class User extends Authenticatable~', 'class User extends Authenticatable implements MustVerifyEmail', $s, 1);
    }
    return $s;
}, 'require verified email on User');

if (file_exists($root.'/vite.config.js')) {
    edit('vite.config.js', function ($s) {
        if (str_contains($s, '@tailwindcss/vite')) return $s;
        $s = preg_replace("~(import laravel from [^\n]+\n)~", "$1import tailwindcss from '@tailwindcss/vite';\n", $s, 1);
        return preg_replace('~plugins:\s*\[~', "plugins: [\n        tailwindcss(),", $s, 1);
    }, 'Tailwind v4 vite plugin');
}

@unlink($root.'/public/robots.txt');
@unlink($root.'/tailwind.config.js');
@unlink($root.'/postcss.config.js');

if ($failed) {
    echo "\n!! Some automatic edits failed. Do these by hand (see README):\n";
    foreach ($failed as $f) echo "   - $f\n";
    exit(2);
}
echo "All edits applied.\n";
