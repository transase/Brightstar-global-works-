#!/usr/bin/env bash
# Builds brightstar-cpanel.zip: a ready-to-upload package for cPanel shared hosting
# (vendor/ included, assets compiled, public files split into public_html/).
# Needs PHP 8.2+, Composer, Node 18+, npm, zip on THIS machine (or run it for free in GitHub Actions).
#   bash scripts/build-cpanel-package.sh [output-dir]
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$SRC/dist}"
WORK="$(mktemp -d)"
APPDIR="${APP_FOLDER:-brightstar}"          # folder name created in the cPanel home directory
say() { printf '\n==> %s\n' "$*"; }
command -v zip >/dev/null || { echo "Missing required tool: zip"; exit 1; }

bash "$SRC/scripts/prepare.sh" "$WORK/app"
cd "$WORK/app"

say "Production dependencies and compiled assets"
composer install --no-dev --optimize-autoloader --no-interaction
npm run build

say "Production .env (the web installer fills in the database details)"
cp .env.example .env
php artisan key:generate --force
set_env() { if grep -q "^$1=" .env; then sed -i.bak "s#^$1=.*#$1=$2#" .env; else echo "$1=$2" >> .env; fi; }
set_env APP_ENV production;  set_env APP_DEBUG false; set_env LOG_LEVEL error
set_env SESSION_DRIVER file; set_env CACHE_STORE file; set_env QUEUE_CONNECTION sync
set_env DB_CONNECTION mysql; set_env DB_DATABASE ""; set_env DB_USERNAME ""; set_env DB_PASSWORD ""
set_env MAIL_MAILER log
rm -f .env.bak

say "Cleaning up"
rm -rf node_modules tests phpunit.xml .git .github scripts install.sh package-lock.json
mkdir -p storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs storage/app bootstrap/cache
rm -f storage/logs/*.log

say "Install code (stops strangers installing your site first)"
CODE="$(php -r 'echo substr(bin2hex(random_bytes(8)),0,12);')"
echo "$CODE" > storage/app/INSTALL-CODE.txt

say "Splitting into $APPDIR/ (private) and public_html/ (web root)"
PKG="$WORK/pkg"; mkdir -p "$PKG/public_html"
shopt -s dotglob
mv public/* "$PKG/public_html/"
shopt -u dotglob
rmdir public
# index.php now lives in public_html: point it at ../$APPDIR and tell Laravel where the public folder is.
php -r '
  $f = $argv[1]; $app = $argv[2]; $s = file_get_contents($f);
  $s = str_replace("__DIR__.\x27/../", "__DIR__.\x27/../".$app."/", $s);
  $s = str_replace("\$app->handleRequest(", "\$app->usePublicPath(__DIR__);\n\$app->handleRequest(", $s);
  file_put_contents($f, $s);' "$PKG/public_html/index.php" "$APPDIR"
grep -q usePublicPath "$PKG/public_html/index.php" || { echo "!! could not patch index.php"; exit 1; }
printf '<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n' > .htaccess
cd "$WORK"; mv app "$PKG/$APPDIR"

cat > "$PKG/START-HERE.txt" <<TXT
Brightstar Global Furniture - cPanel package

1. Upload this zip to your cPanel HOME folder (not inside public_html) and Extract it there.
   You should now see two folders: "$APPDIR" and "public_html".
2. In cPanel > MultiPHP Manager choose PHP 8.2 or 8.3 for your domain.
3. In cPanel > MySQL Databases create a database, a user, and add the user to the database with ALL PRIVILEGES.
4. Open File Manager > $APPDIR/storage/app/INSTALL-CODE.txt and copy the code inside.
5. Visit https://YOUR-DOMAIN/install and follow the screen.
Full guide with screenshots-free steps: CPANEL.md in the project, or ask your developer.

Install code (also saved in the file above): $CODE
TXT

mkdir -p "$OUT"
rm -f "$OUT/brightstar-cpanel.zip"
(cd "$PKG" && zip -qr "$OUT/brightstar-cpanel.zip" .)
say "Done: $OUT/brightstar-cpanel.zip"
echo "Install code for this build: $CODE"
