#!/usr/bin/env bash
# Creates a fresh Laravel project at TARGET and applies the Brightstar overlay to it.
# Usage: bash scripts/prepare.sh /path/to/new-project
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${1:?usage: prepare.sh TARGET_DIR}"
say() { printf '\n==> %s\n' "$*"; }

for tool in php composer node npm tar; do command -v "$tool" >/dev/null || { echo "Missing required tool: $tool"; exit 1; }; done
[ -e "$TARGET" ] && { echo "$TARGET already exists; choose another path"; exit 1; }

say "Creating a fresh Laravel project"
composer create-project laravel/laravel "$TARGET" --no-interaction
cd "$TARGET"

say "Installing Breeze (login, registration, email verification, password reset)"
composer require laravel/breeze --dev --no-interaction
php artisan breeze:install blade --no-interaction

say "Front-end packages (Alpine.js, Tailwind v4)"
npm install
npm install alpinejs
npm install -D tailwindcss@4 @tailwindcss/vite

say "Copying the Brightstar overlay (overwrites routes/web.php, css/js and a few views)"
tar -C "$SRC" --exclude=.git --exclude=node_modules --exclude=vendor --exclude=dist --exclude=.env.additions --exclude=config/services.additions.php -cf - . | tar -xf -
grep -q STRIPE_SECRET_KEY .env 2>/dev/null || cat "$SRC/.env.additions" >> .env

say "Applying automatic edits to Laravel's own files"
php "$SRC/scripts/patch-laravel.php" "$PWD" || echo "!! see the list above"
