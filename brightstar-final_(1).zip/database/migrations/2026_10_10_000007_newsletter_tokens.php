<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('newsletter_subscribers', function (Blueprint $t) {
            $t->string('token', 64)->nullable()->unique();
            $t->timestamp('unsubscribed_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('newsletter_subscribers', fn (Blueprint $t) => $t->dropColumn(['token', 'unsubscribed_at']));
    }
};
