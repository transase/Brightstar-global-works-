<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $t) {
            $t->id();
            $t->string('key')->unique();
            $t->text('value')->nullable();
            $t->timestamps();
        });

        Schema::create('coupons', function (Blueprint $t) {
            $t->id();
            $t->string('code')->unique();
            $t->enum('type', ['percent', 'fixed']);
            $t->unsignedBigInteger('value'); // percent (1-100) or minor units
            $t->unsignedBigInteger('min_subtotal')->default(0);
            $t->unsignedInteger('max_uses')->nullable();
            $t->unsignedInteger('used_count')->default(0);
            $t->timestamp('starts_at')->nullable();
            $t->timestamp('expires_at')->nullable();
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('delivery_zones', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('state')->nullable();
            $t->unsignedBigInteger('fee')->default(0);
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('carts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained()->cascadeOnDelete();
            $t->string('session_token', 64)->nullable()->index();
            $t->string('coupon_code')->nullable();
            $t->timestamps();
        });

        Schema::create('cart_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('cart_id')->constrained()->cascadeOnDelete();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->foreignId('variant_id')->nullable()->constrained('product_variants')->cascadeOnDelete();
            $t->unsignedInteger('quantity');
            $t->timestamps();
            $t->unique(['cart_id', 'product_id', 'variant_id']);
        });

        Schema::create('orders', function (Blueprint $t) {
            $t->id();
            $t->string('number')->unique();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('first_name');
            $t->string('last_name');
            $t->string('email');
            $t->string('phone', 32);
            $t->json('shipping_address');
            $t->json('billing_address')->nullable();
            $t->text('delivery_instructions')->nullable();
            $t->string('currency', 3)->default('NGN');
            $t->unsignedBigInteger('subtotal');
            $t->unsignedBigInteger('discount')->default(0);
            $t->unsignedBigInteger('tax')->default(0);
            $t->unsignedBigInteger('delivery_fee')->default(0);
            $t->unsignedBigInteger('total');
            $t->string('coupon_code')->nullable();
            $t->string('payment_method'); // paystack, flutterwave, cod, bank_transfer, whatsapp
            $t->enum('payment_status', ['unpaid', 'pending', 'paid', 'failed', 'refunded', 'partially_refunded'])->default('unpaid');
            $t->enum('fulfilment_status', [
                'pending_confirmation', 'awaiting_payment', 'processing', 'ready_for_dispatch',
                'shipped', 'delivered', 'cancelled',
            ])->default('pending_confirmation');
            $t->string('source')->default('web'); // web | whatsapp
            $t->timestamp('whatsapp_handoff_at')->nullable();
            $t->text('admin_notes')->nullable();
            $t->timestamps();
            $t->index(['payment_status', 'fulfilment_status']);
        });

        Schema::create('order_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('order_id')->constrained()->cascadeOnDelete();
            $t->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('variant_id')->nullable()->constrained('product_variants')->nullOnDelete();
            // Snapshots so later catalogue edits never rewrite history.
            $t->string('name');
            $t->string('sku');
            $t->string('variant_label')->nullable();
            $t->unsignedBigInteger('unit_price');
            $t->unsignedInteger('quantity');
            $t->unsignedBigInteger('line_total');
            $t->timestamps();
        });

        Schema::create('payments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('order_id')->constrained()->cascadeOnDelete();
            $t->string('gateway');
            $t->string('reference')->unique();
            $t->string('gateway_transaction_id')->nullable();
            $t->unsignedBigInteger('amount');
            $t->string('currency', 3);
            $t->enum('status', ['pending', 'successful', 'failed', 'refunded'])->default('pending');
            $t->json('meta')->nullable(); // safe metadata only; never secrets or card data
            $t->timestamp('verified_at')->nullable();
            $t->timestamps();
        });

        Schema::create('payment_events', function (Blueprint $t) {
            $t->id();
            $t->string('gateway');
            $t->string('event_id');
            $t->string('reference')->nullable()->index();
            $t->string('type')->nullable();
            $t->timestamp('processed_at')->nullable();
            $t->timestamps();
            $t->unique(['gateway', 'event_id']); // idempotency guard
        });

        Schema::create('order_logs', function (Blueprint $t) {
            $t->id();
            $t->foreignId('order_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('event');
            $t->text('note')->nullable();
            $t->timestamps();
        });

        Schema::create('newsletter_subscribers', function (Blueprint $t) {
            $t->id();
            $t->string('email')->unique();
            $t->timestamps();
        });

        Schema::table('users', function (Blueprint $t) {
            $t->string('role')->default('customer'); // customer|admin|manager|staff
            $t->string('phone', 32)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['role', 'phone']));
        foreach (['newsletter_subscribers', 'order_logs', 'payment_events', 'payments', 'order_items', 'orders',
                  'cart_items', 'carts', 'delivery_zones', 'coupons', 'settings'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
