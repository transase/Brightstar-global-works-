<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('nav_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('parent_id')->nullable()->constrained('nav_items')->cascadeOnDelete();
            $t->string('label');
            $t->string('url');
            $t->string('image')->nullable();   // shown in the mega-menu for children
            $t->boolean('is_featured')->default(false);
            $t->boolean('is_visible')->default(true);
            $t->unsignedInteger('sort_order')->default(0);
            $t->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('nav_items'); }
};
