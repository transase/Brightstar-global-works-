<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('slides', function (Blueprint $t) {
            $t->id();
            $t->enum('type', ['hero', 'promo'])->default('hero');
            $t->string('heading');
            $t->text('description')->nullable();
            $t->string('image')->nullable();
            $t->string('cta_text')->nullable();
            $t->string('url')->nullable();
            $t->timestamp('starts_at')->nullable();
            $t->timestamp('ends_at')->nullable();
            $t->unsignedInteger('sort_order')->default(0);
            $t->boolean('is_active')->default(true);
            $t->timestamps();
            $t->index(['type', 'is_active']);
        });
    }

    public function down(): void { Schema::dropIfExists('slides'); }
};
