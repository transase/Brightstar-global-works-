<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $t) {
            $t->id();
            $t->foreignId('parent_id')->nullable()->constrained('categories')->nullOnDelete();
            $t->string('name');
            $t->string('slug')->unique();
            $t->text('description')->nullable();
            $t->string('image')->nullable();
            $t->string('seo_title')->nullable();
            $t->string('seo_description')->nullable();
            $t->unsignedInteger('sort_order')->default(0);
            $t->boolean('is_active')->default(true);
            $t->boolean('is_featured')->default(false);
            $t->timestamps();
        });

        Schema::create('products', function (Blueprint $t) {
            $t->id();
            $t->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $t->string('name');
            $t->string('slug')->unique();
            $t->string('sku')->unique();
            $t->string('brand')->nullable();
            $t->string('short_description', 500)->nullable();
            $t->longText('description')->nullable();
            $t->string('main_image')->nullable();
            // Money is stored in minor units (kobo) as integers to avoid float errors.
            $t->unsignedBigInteger('price');
            $t->unsignedBigInteger('sale_price')->nullable();
            $t->unsignedBigInteger('cost_price')->nullable();
            $t->integer('stock_quantity')->default(0);
            $t->boolean('track_stock')->default(true);
            $t->boolean('allow_backorder')->default(false);
            $t->boolean('enquiry_only')->default(false);
            $t->enum('status', ['draft', 'published', 'archived'])->default('draft');
            $t->boolean('is_featured')->default(false);
            $t->boolean('is_best_seller')->default(false);
            $t->boolean('is_new_arrival')->default(false);
            $t->decimal('height', 8, 2)->nullable();
            $t->decimal('width', 8, 2)->nullable();
            $t->decimal('depth', 8, 2)->nullable();
            $t->string('dimension_unit', 8)->default('cm');
            $t->decimal('weight', 8, 2)->nullable();
            $t->string('material')->nullable();
            $t->string('finish')->nullable();
            $t->boolean('assembly_required')->default(false);
            $t->string('warranty')->nullable();
            $t->text('delivery_info')->nullable();
            $t->string('delivery_timeframe')->nullable();
            $t->unsignedInteger('sales_count')->default(0);
            $t->string('seo_title')->nullable();
            $t->string('seo_description')->nullable();
            $t->string('seo_image')->nullable();
            $t->timestamps();
            $t->index(['status', 'category_id']);
        });

        // SQLite (used by the default test setup) has no FULLTEXT support.
        if (in_array(Schema::getConnection()->getDriverName(), ['mysql', 'mariadb', 'pgsql'], true)) {
            Schema::table('products', fn (Blueprint $t) => $t->fullText(['name', 'short_description']));
        }

        Schema::create('product_images', function (Blueprint $t) {
            $t->id();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->string('path');
            $t->string('alt')->nullable();
            $t->unsignedInteger('sort_order')->default(0);
            $t->timestamps();
        });

        Schema::create('product_variants', function (Blueprint $t) {
            $t->id();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->string('sku')->nullable()->unique();
            $t->string('colour')->nullable();
            $t->string('size')->nullable();
            $t->string('finish')->nullable();
            $t->string('upholstery')->nullable();
            $t->bigInteger('price_adjustment')->default(0); // minor units, may be negative
            $t->integer('stock_quantity')->default(0);
            $t->string('image')->nullable();
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('product_related', function (Blueprint $t) {
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->foreignId('related_id')->constrained('products')->cascadeOnDelete();
            $t->primary(['product_id', 'related_id']);
        });

        Schema::create('reviews', function (Blueprint $t) {
            $t->id();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('author_name');
            $t->unsignedTinyInteger('rating');
            $t->text('body')->nullable();
            $t->boolean('is_verified_purchase')->default(false);
            $t->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $t->timestamps();
        });

        Schema::create('wishlists', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->unique(['user_id', 'product_id']);
        });
    }

    public function down(): void
    {
        foreach (['wishlists', 'reviews', 'product_related', 'product_variants', 'product_images', 'products', 'categories'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
