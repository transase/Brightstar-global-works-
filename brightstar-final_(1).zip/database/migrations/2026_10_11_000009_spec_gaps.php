<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('collections', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('slug')->unique();
            $t->text('description')->nullable();
            $t->string('image')->nullable();
            $t->string('seo_title')->nullable();
            $t->string('seo_description')->nullable();
            $t->unsignedInteger('sort_order')->default(0);
            $t->boolean('is_active')->default(true);
            $t->boolean('is_featured')->default(false);
            $t->timestamps();
        });

        Schema::create('collection_product', function (Blueprint $t) {
            $t->foreignId('collection_id')->constrained()->cascadeOnDelete();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->primary(['collection_id', 'product_id']);
        });

        Schema::create('benefits', function (Blueprint $t) {
            $t->id();
            $t->string('title');
            $t->string('text', 300)->nullable();
            $t->unsignedInteger('sort_order')->default(0);
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::table('categories', function (Blueprint $t) {
            $t->string('spec_fields', 500)->nullable(); // suggested attribute names, comma separated (e.g. "Seats, Frame material")
        });

        Schema::table('products', function (Blueprint $t) {
            $t->json('specs')->nullable(); // category-specific attributes: {"Seats": "3", ...}
            $t->index('price');
            $t->index('created_at');
        });
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $t) { $t->dropIndex(['price']); $t->dropIndex(['created_at']); $t->dropColumn('specs'); });
        Schema::table('categories', fn (Blueprint $t) => $t->dropColumn('spec_fields'));
        foreach (['benefits', 'collection_product', 'collections'] as $tbl) Schema::dropIfExists($tbl);
    }
};
