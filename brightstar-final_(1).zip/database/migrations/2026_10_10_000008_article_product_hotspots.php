<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('article_product', function (Blueprint $t) {
            // Pin position on the cover image, as a percentage of its width/height. Null = no pin (grid only).
            $t->decimal('pos_x', 5, 2)->nullable();
            $t->decimal('pos_y', 5, 2)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('article_product', fn (Blueprint $t) => $t->dropColumn(['pos_x', 'pos_y']));
    }
};
