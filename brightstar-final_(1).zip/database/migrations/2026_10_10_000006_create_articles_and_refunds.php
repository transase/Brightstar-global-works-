<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('articles', function (Blueprint $t) {
            $t->id();
            $t->string('slug')->unique();
            $t->string('title');
            $t->string('excerpt', 400)->nullable();
            $t->longText('body')->nullable();
            $t->string('cover_image')->nullable();
            $t->string('seo_description')->nullable();
            $t->boolean('is_published')->default(false);
            $t->timestamp('published_at')->nullable();
            $t->timestamps();
        });

        Schema::create('article_product', function (Blueprint $t) {
            $t->foreignId('article_id')->constrained()->cascadeOnDelete();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('sort_order')->default(0);
            $t->primary(['article_id', 'product_id']);
        });

        Schema::table('payments', function (Blueprint $t) {
            $t->unsignedBigInteger('refunded_amount')->default(0)->after('amount');
        });
    }

    public function down(): void
    {
        Schema::table('payments', fn (Blueprint $t) => $t->dropColumn('refunded_amount'));
        Schema::dropIfExists('article_product');
        Schema::dropIfExists('articles');
    }
};
