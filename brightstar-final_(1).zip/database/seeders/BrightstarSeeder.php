<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\DeliveryZone;
use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class BrightstarSeeder extends Seeder
{
    public function run(): void
    {
        $tree = [
            'Living Room' => ['Sofas', 'Sectional Sofas', 'Sofa Beds', 'Armchairs', 'Recliners', 'Centre Tables', 'Side Tables', 'TV Consoles', 'TV Stands', 'Bookshelves', 'Display Cabinets', 'Living Room Sets'],
            'Bedroom' => ['Bed Frames', 'Beds with Storage', 'Wardrobes', 'Chest of Drawers', 'Bedside Tables', 'Dressing Tables', 'Bedroom Sets', 'Mattresses', 'Headboards'],
            'Dining Room' => ['Dining Tables', 'Dining Chairs', 'Dining Sets', 'Bar Stools', 'Kitchen Tables', 'Sideboards', 'Dining Cabinets'],
            'Office Furniture' => ['Office Desks', 'Executive Desks', 'Office Chairs', 'Ergonomic Chairs', 'Meeting Tables', 'Filing Cabinets', 'Reception Furniture', 'Office Storage'],
            'Storage and Organisation' => ['Cabinets', 'Shelving Units', 'Shoe Racks', 'Storage Benches', 'Bookcases', 'Multipurpose Storage'],
            'Outdoor Furniture' => ['Garden Chairs', 'Outdoor Tables', 'Patio Sets', 'Balcony Furniture', 'Outdoor Loungers'],
            "Children's Furniture" => ["Children's Beds", 'Bunk Beds', 'Study Desks', "Children's Wardrobes", 'Toy Storage'],
            'Home Accessories' => ['Mirrors', 'Decorative Shelves', 'Lamps', 'Furniture Accessories', 'Interior Decor'],
        ];
        $order = 0;
        foreach ($tree as $parent => $children) {
            $p = Category::firstOrCreate(['slug' => Str::slug($parent)], ['name' => $parent, 'sort_order' => $order++]);
            foreach ($children as $i => $child) {
                Category::firstOrCreate(['slug' => Str::slug($child)], ['name' => $child, 'parent_id' => $p->id, 'sort_order' => $i]);
            }
        }
        // The 12 homepage "Shop by category" cards from the brief (admin can change these with the Featured tick).
        Category::whereIn('slug', ['sofas', 'living-room', 'bed-frames', 'wardrobes', 'mattresses', 'dining-tables', 'office-desks', 'tv-stands', 'centre-tables', 'bookshelves', 'outdoor-furniture', 'furniture-accessories'])
            ->update(['is_featured' => true]);

        // Placeholders only. The owner replaces these in admin; nothing here is a business claim.
        foreach ([
            'store_name' => 'Brightstar Global Furniture', 'currency' => 'NGN',
            'announcement_enabled' => '0', 'announcement_text' => '',
            'whatsapp_phone' => '', // set in admin, international format e.g. +234...
            'wa_floating' => '1', 'cod_enabled' => '0', 'bank_transfer_enabled' => '0',
        ] as $k => $v) Setting::firstOrCreate(['key' => $k], ['value' => $v]);

        DeliveryZone::firstOrCreate(['name' => 'Standard delivery'], ['fee' => 0]);

        // Dev installs (install.sh) provide ADMIN_EMAIL; the web installer creates the admin itself.
        if ($email = env('ADMIN_EMAIL')) {
            static::createAdmin('Store Admin', $email, env('ADMIN_PASSWORD', 'change-me-now'));
        }

        if (app()->environment('local')) {
            $sofas = Category::where('slug', 'sofas')->first();
            $p = Product::firstOrCreate(['sku' => 'DEMO-SOFA-001'], [
                'name' => 'Demo 3-Seater Sofa', 'category_id' => $sofas?->id, 'price' => 45000000, 'sale_price' => 39900000,
                'stock_quantity' => 8, 'status' => 'published', 'is_featured' => true, 'is_new_arrival' => true,
                'short_description' => 'Sample product for local testing.', 'material' => 'Fabric',
            ]);
            foreach ([['Grey', 0], ['Navy', 0], ['Cream', 1500000]] as $n => [$colour, $adj]) {
                $p->variants()->firstOrCreate(['sku' => 'DEMO-SOFA-001-'.($n + 1)], ['colour' => $colour, 'price_adjustment' => $adj, 'stock_quantity' => 3]);
            }
        }
    }

    /** role/email_verified_at are not mass-assignable on the default User model, so use forceFill. */
    public static function createAdmin(string $name, string $email, string $password): User
    {
        $u = User::firstOrNew(['email' => $email]);
        $u->forceFill(['name' => $name, 'password' => Hash::make($password), 'role' => 'admin', 'email_verified_at' => now()])->save();
        return $u;
    }
}
