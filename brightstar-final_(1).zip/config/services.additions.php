<?php
// MERGE these two entries into the array returned by config/services.php

return [
    'paystack' => [
        'enabled' => env('PAYSTACK_ENABLED', false),
        'public' => env('PAYSTACK_PUBLIC_KEY'),
        'secret' => env('PAYSTACK_SECRET_KEY'),
    ],
    'stripe' => [
        'secret' => env('STRIPE_SECRET_KEY'),
        'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),
    ],
    'flutterwave' => [
        'enabled' => env('FLUTTERWAVE_ENABLED', false),
        'secret' => env('FLUTTERWAVE_SECRET_KEY'),
        'webhook_hash' => env('FLUTTERWAVE_WEBHOOK_HASH'),
    ],
];
