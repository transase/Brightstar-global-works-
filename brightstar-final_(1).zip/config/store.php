<?php

return [
    'currency' => env('STORE_CURRENCY', 'NGN'),
    // "public" (local, needs `artisan storage:link`) or "s3" for S3-compatible object storage.
    'media_disk' => env('MEDIA_DISK', 'public'),
];
