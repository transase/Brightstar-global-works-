@extends('layouts.admin')
@section('title', 'Reviews')
@section('content')
<h1 class="text-3xl">Review moderation</h1>
<nav class="mt-4 flex gap-4 text-sm">@foreach(['pending','approved','rejected'] as $s)<a href="{{ route('admin.reviews.index', ['status' => $s]) }}" class="{{ request('status', 'pending') === $s ? 'font-semibold text-brand-red' : '' }}">{{ ucfirst($s) }}</a>@endforeach</nav>
<div class="mt-4 divide-y divide-line rounded-lg border border-line bg-white text-sm">@forelse($reviews as $r)
    <div class="p-4"><p class="font-semibold">{{ $r->author_name }} · {{ $r->rating }}/5 @if($r->is_verified_purchase)<span class="text-brand-green">Verified purchase</span>@endif</p><p class="mt-1 text-muted">{{ $r->body }}</p>
        <div class="mt-2 flex gap-3">@foreach(['approved' => 'Approve', 'rejected' => 'Reject'] as $st => $l)<form method="post" action="{{ route('admin.reviews.update', $r) }}">@csrf @method('PATCH')<input type="hidden" name="status" value="{{ $st }}"><button class="underline">{{ $l }}</button></form>@endforeach
        <form method="post" action="{{ route('admin.reviews.destroy', $r) }}">@csrf @method('DELETE')<button class="text-brand-red underline">Delete</button></form></div></div>@empty<p class="p-5 text-muted">Nothing here.</p>@endforelse</div>
<div class="mt-4">{{ $reviews->links() }}</div>
@endsection
