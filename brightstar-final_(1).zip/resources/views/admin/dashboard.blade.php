@extends('layouts.admin')
@section('title', 'Dashboard')
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v); @endphp
<h1 class="text-3xl">Dashboard</h1>
<div class="mt-6 grid gap-4 sm:grid-cols-3">
    @foreach([['Awaiting confirmation', $pending], ['Orders today', $today], ['Paid revenue (30 days)', $m($revenue30)]] as [$l, $v])
        <div class="rounded-lg border border-line bg-white p-5"><p class="text-sm text-muted">{{ $l }}</p><p class="mt-1 text-2xl font-semibold">{{ $v }}</p></div>
    @endforeach
</div>
<div class="mt-8 grid gap-6 lg:grid-cols-2">
    <section class="rounded-lg border border-line bg-white p-5"><h2 class="text-xl">Recent orders</h2>
        <ul class="mt-3 divide-y divide-line text-sm">@forelse($recent as $o)
            <li class="flex justify-between py-2"><a class="font-medium" href="{{ route('admin.orders.show', $o) }}">{{ $o->number }}</a><span class="text-muted">{{ str_replace('_', ' ', $o->fulfilment_status) }}</span><span>{{ $m($o->total) }}</span></li>
        @empty<li class="py-2 text-muted">No orders yet.</li>@endforelse</ul></section>
    @if(auth()->user()->role !== 'staff')
    <section class="rounded-lg border border-line bg-white p-5"><h2 class="text-xl">Low stock</h2>
        <ul class="mt-3 divide-y divide-line text-sm">@forelse($lowStock as $p)
            <li class="flex justify-between py-2"><a href="{{ route('admin.products.edit', $p) }}">{{ $p->name }}</a><span class="{{ $p->stock_quantity < 1 ? 'text-brand-red' : '' }}">{{ $p->stock_quantity }} left</span></li>
        @empty<li class="py-2 text-muted">Nothing running low.</li>@endforelse</ul></section>
    @endif
</div>
@endsection
