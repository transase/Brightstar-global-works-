@extends('layouts.admin')
@section('title', 'Orders')
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v); @endphp
<h1 class="text-3xl">Orders</h1>
<form class="mt-4 flex flex-wrap gap-2 text-sm">
    <input name="q" value="{{ request('q') }}" placeholder="Order no., email, phone, surname" class="field max-w-xs">
    <select name="fulfilment" class="field w-auto"><option value="">Any status</option>@foreach(\App\Services\OrderService::FULFILMENT as $s)<option value="{{ $s }}" @selected(request('fulfilment') === $s)>{{ str_replace('_', ' ', $s) }}</option>@endforeach</select>
    <select name="payment" class="field w-auto"><option value="">Any payment</option>@foreach(['unpaid','pending','paid','failed','refunded'] as $s)<option @selected(request('payment') === $s)>{{ $s }}</option>@endforeach</select>
    <select name="source" class="field w-auto"><option value="">All sources</option><option value="web" @selected(request('source') === 'web')>Web</option><option value="whatsapp" @selected(request('source') === 'whatsapp')>WhatsApp</option></select>
    <button class="btn-red">Filter</button>
</form>
<div class="mt-4 overflow-x-auto rounded-lg border border-line bg-white"><table class="w-full text-left text-sm">
    <thead class="bg-surface text-muted"><tr><th class="p-3">Order</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Source</th><th>Date</th></tr></thead>
    <tbody class="divide-y divide-line">@foreach($orders as $o)
        <tr><td class="p-3"><a class="font-medium text-brand-red" href="{{ route('admin.orders.show', $o) }}">{{ $o->number }}</a></td><td>{{ $o->first_name }} {{ $o->last_name }}</td><td>{{ $m($o->total) }}</td>
        <td>{{ $o->payment_status }}</td><td>{{ str_replace('_', ' ', $o->fulfilment_status) }}</td><td>{{ $o->source }}</td><td>{{ $o->created_at->format('d M, H:i') }}</td></tr>@endforeach</tbody></table></div>
<div class="mt-4">{{ $orders->links() }}</div>
@endsection
