@php $m = fn ($v) => \App\Services\Money::format($v, $order->currency); $a = $order->shipping_address; @endphp
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Invoice {{ $order->number }}</title>
<style>body{font-family:system-ui,sans-serif;color:#202020;max-width:760px;margin:2rem auto;padding:0 1rem;font-size:14px}table{width:100%;border-collapse:collapse}th,td{padding:8px;border-bottom:1px solid #E5E7EB;text-align:left}td.r,th.r{text-align:right}img{height:56px;width:auto}.no-print{margin-bottom:1rem}@media print{.no-print{display:none}}</style></head>
<body><button class="no-print" onclick="window.print()">Print</button>
<img src="{{ \App\Support\Branding::logo() }}" alt="{{ \App\Models\Setting::get('store_name', 'Brightstar Global Furniture') }}">
<p>{{ \App\Models\Setting::get('store_address') }}<br>{{ \App\Models\Setting::get('store_phone') }} {{ \App\Models\Setting::get('store_email') }}</p>
<h1>Invoice {{ $order->number }}</h1><p>{{ $order->created_at->format('d M Y') }} · Payment: {{ $order->payment_status }} ({{ $order->payment_method }})</p>
<p><strong>{{ $order->first_name }} {{ $order->last_name }}</strong><br>{{ collect([$a['address'] ?? null, $a['city'] ?? null, $a['state'] ?? null, $a['country'] ?? null])->filter()->implode(', ') }}<br>{{ $order->phone }}</p>
<table><thead><tr><th>Item</th><th>SKU</th><th class="r">Qty</th><th class="r">Unit</th><th class="r">Total</th></tr></thead><tbody>
@foreach($order->items as $i)<tr><td>{{ $i->name }}@if($i->variant_label) ({{ $i->variant_label }})@endif</td><td>{{ $i->sku }}</td><td class="r">{{ $i->quantity }}</td><td class="r">{{ $m($i->unit_price) }}</td><td class="r">{{ $m($i->line_total) }}</td></tr>@endforeach</tbody></table>
<p style="text-align:right">Subtotal {{ $m($order->subtotal) }}<br>@if($order->discount)Discount -{{ $m($order->discount) }}<br>@endif @if($order->tax){{ \App\Models\Setting::get('tax_label', 'Tax') }} {{ $m($order->tax) }}<br>@endif Delivery {{ $m($order->delivery_fee) }}<br><strong>Total {{ $m($order->total) }}</strong></p></body></html>
