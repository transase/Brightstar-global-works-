@extends('layouts.admin')
@section('title', 'Order '.$order->number)
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v, $order->currency); $a = $order->shipping_address; @endphp
<div class="flex flex-wrap items-center justify-between gap-3"><h1 class="text-3xl">{{ $order->number }}</h1><a href="{{ route('admin.orders.invoice', $order) }}" target="_blank" class="btn-line">Print invoice</a></div>
<div class="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
    <div class="space-y-6">
        <section class="rounded-lg border border-line bg-white p-5 text-sm"><h2 class="text-xl">Items</h2>
            <ul class="mt-3 divide-y divide-line">@foreach($order->items as $i)<li class="flex justify-between py-2"><span>{{ $i->name }}@if($i->variant_label) ({{ $i->variant_label }})@endif × {{ $i->quantity }}<br><span class="text-muted">SKU {{ $i->sku }} · {{ $m($i->unit_price) }} each</span></span><span>{{ $m($i->line_total) }}</span></li>@endforeach</ul>
            <dl class="mt-3 space-y-1 border-t border-line pt-3"><div class="flex justify-between"><dt>Subtotal</dt><dd>{{ $m($order->subtotal) }}</dd></div>
            @if($order->discount)<div class="flex justify-between"><dt>Discount {{ $order->coupon_code }}</dt><dd>-{{ $m($order->discount) }}</dd></div>@endif
            @if($order->tax)<div class="flex justify-between"><dt>Tax</dt><dd>{{ $m($order->tax) }}</dd></div>@endif
            <div class="flex justify-between"><dt>Delivery</dt><dd>{{ $m($order->delivery_fee) }}</dd></div><div class="flex justify-between text-base font-semibold"><dt>Total</dt><dd>{{ $m($order->total) }}</dd></div></dl></section>
        <section class="rounded-lg border border-line bg-white p-5 text-sm"><h2 class="text-xl">Customer</h2>
            <p class="mt-2">{{ $order->first_name }} {{ $order->last_name }}<br>{{ $order->email }} · {{ $order->phone }}</p>
            <p class="mt-2 text-muted">{{ collect([$a['address'] ?? null, $a['city'] ?? null, $a['state'] ?? null, $a['postal_code'] ?? null, $a['country'] ?? null])->filter()->implode(', ') }}</p>
            @if($order->billing_address)@php $ba = $order->billing_address; @endphp<p class="mt-2 text-muted">Billing: {{ collect([$ba['address'] ?? null, $ba['city'] ?? null, $ba['state'] ?? null, $ba['postal_code'] ?? null, $ba['country'] ?? null])->filter()->implode(', ') }}</p>@endif
            @if($order->delivery_instructions)<p class="mt-2">Instructions: {{ $order->delivery_instructions }}</p>@endif
            @if($wa = \App\Services\WhatsAppService::normalisePhone($order->phone))<a class="btn-whatsapp mt-3" target="_blank" rel="noopener" href="https://wa.me/{{ $wa }}?text={{ rawurlencode('Hello '.$order->first_name.', this is regarding your order '.$order->number.'.') }}">Message customer</a>@endif</section>
        <section class="rounded-lg border border-line bg-white p-5 text-sm"><h2 class="text-xl">Activity</h2>
            <ul class="mt-3 space-y-2">@foreach($order->logs->sortByDesc('id') as $l)<li><span class="text-muted">{{ $l->created_at->format('d M H:i') }}</span> · {{ str_replace('_', ' ', $l->event) }} {{ $l->note }}</li>@endforeach</ul></section>
    </div>
    <aside class="h-fit space-y-4 rounded-lg border border-line bg-white p-5 text-sm">
        <form method="post" action="{{ route('admin.orders.update', $order) }}" class="space-y-3">@csrf @method('PATCH')
            <div><label class="label" for="f">Fulfilment status</label><select id="f" name="fulfilment_status" class="field">@foreach(\App\Services\OrderService::FULFILMENT as $s)<option value="{{ $s }}" @selected($order->fulfilment_status === $s)>{{ str_replace('_', ' ', $s) }}</option>@endforeach</select></div>
            <div><label class="label" for="p">Payment status ({{ $order->payment_method }})</label><select id="p" name="payment_status" class="field">@foreach(['unpaid','pending','paid','failed','refunded','partially_refunded'] as $s)<option @selected($order->payment_status === $s)>{{ $s }}</option>@endforeach</select>
                @if(in_array($order->payment_method, \App\Services\OrderService::GATEWAYS))<p class="mt-1 text-xs text-muted">Online payments become “paid” only through provider verification.</p>@endif</div>
            <div><label class="label" for="n">Internal notes</label><textarea id="n" name="admin_notes" rows="4" class="field">{{ $order->admin_notes }}</textarea></div>
            <button class="btn-red w-full">Save</button>
        </form>
        @if($order->payments->isNotEmpty())<div class="border-t border-line pt-3"><p class="font-semibold">Payments</p>@foreach($order->payments as $p)<p class="mt-1 text-muted">{{ $p->gateway }} · {{ $p->status }} · {{ $p->reference }}@if($p->refunded_amount) · refunded {{ $m($p->refunded_amount) }}@endif</p>
            @if(auth()->user()->role === 'admin' && $p->status === 'successful' && $p->amount > $p->refunded_amount)
                <form method="post" action="{{ route('admin.payments.refund', $p) }}" class="mt-2 flex gap-2" onsubmit="return confirm('Send this refund to the payment provider?')">@csrf
                    <input type="number" step="0.01" min="0.01" max="{{ ($p->amount - $p->refunded_amount) / 100 }}" name="amount" value="{{ ($p->amount - $p->refunded_amount) / 100 }}" class="field" aria-label="Refund amount"><button class="btn-line">Refund</button></form>@endif
            @endforeach</div>@endif
        @if(! in_array($order->payment_status, ['paid', 'refunded', 'partially_refunded'], true) && $order->fulfilment_status !== 'cancelled')
            @php $payLink = \Illuminate\Support\Facades\URL::temporarySignedRoute('order.show', now()->addDays(14), ['number' => $order->number]); @endphp
            <div class="border-t border-line pt-3"><p class="font-semibold">Customer payment link</p>
                <p class="text-xs text-muted">For approved orders (e.g. confirmed on WhatsApp). Opens the order page with online payment buttons; valid 14 days.</p>
                <input readonly value="{{ $payLink }}" class="field mt-2 text-xs" onclick="this.select()" aria-label="Customer payment link">
                @if($wa = \App\Services\WhatsAppService::normalisePhone($order->phone))<a class="btn-whatsapp mt-2 w-full" target="_blank" rel="noopener" href="https://wa.me/{{ $wa }}?text={{ rawurlencode('Hello '.$order->first_name.', your order '.$order->number.' is confirmed. You can pay securely here: '.$payLink) }}">Send link on WhatsApp</a>@endif</div>
        @endif
        @if($order->whatsapp_handoff_at)<p class="text-muted">Customer opened WhatsApp {{ $order->whatsapp_handoff_at->diffForHumans() }} (not proof the message was sent).</p>@endif
    </aside>
</div>
@endsection
