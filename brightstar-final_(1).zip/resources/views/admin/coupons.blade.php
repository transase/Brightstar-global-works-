@extends('layouts.admin')
@section('title', 'Coupons')
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v); @endphp
<h1 class="text-3xl">Coupons</h1>
<form method="post" action="{{ route('admin.coupons.store') }}" class="mt-6 grid gap-3 rounded-lg border border-line bg-white p-5 text-sm sm:grid-cols-3">@csrf
    <input name="code" class="field" placeholder="CODE" aria-label="Code" required>
    <select name="type" class="field" aria-label="Type"><option value="percent">Percent off</option><option value="fixed">Fixed amount off</option></select>
    <input name="value" type="number" step="0.01" class="field" placeholder="Value (% or amount)" aria-label="Value" required>
    <input name="min_subtotal" type="number" step="0.01" class="field" placeholder="Minimum subtotal" aria-label="Minimum subtotal">
    <input name="max_uses" type="number" class="field" placeholder="Max uses" aria-label="Max uses">
    <div class="flex gap-2"><input name="starts_at" type="datetime-local" class="field" aria-label="Starts"><input name="expires_at" type="datetime-local" class="field" aria-label="Expires"></div>
    <button class="btn-red sm:col-span-3">Create coupon</button></form>
<div class="mt-6 divide-y divide-line rounded-lg border border-line bg-white text-sm">@forelse($coupons as $c)
    <div class="flex flex-wrap items-center justify-between gap-3 p-3"><div><strong>{{ $c->code }}</strong> · {{ $c->type === 'percent' ? $c->value.'%' : $m($c->value) }} off · used {{ $c->used_count }}{{ $c->max_uses ? '/'.$c->max_uses : '' }}{{ $c->expires_at ? ' · expires '.$c->expires_at->format('d M Y') : '' }}</div>
        <div class="flex gap-3"><form method="post" action="{{ route('admin.coupons.toggle', $c) }}">@csrf @method('PATCH')<button class="underline">{{ $c->is_active ? 'Disable' : 'Enable' }}</button></form>
        <form method="post" action="{{ route('admin.coupons.destroy', $c) }}">@csrf @method('DELETE')<button class="text-brand-red underline">Delete</button></form></div></div>@empty<p class="p-5 text-muted">No coupons yet.</p>@endforelse</div>
@endsection
