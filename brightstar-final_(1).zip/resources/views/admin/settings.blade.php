@extends('layouts.admin')
@section('title', 'Settings')
@section('content')
@php
    use Illuminate\Support\HtmlString;
    $f = fn ($k, $l, $type = 'text', $hint = null, $attrs = '') => new HtmlString('<div><label class="label" for="'.$k.'">'.e($l).'</label><input id="'.$k.'" type="'.$type.'" name="'.$k.'" value="'.e(old($k, $s($k))).'" class="field" '.$attrs.'>'.($hint ? '<p class="mt-1 text-xs text-muted">'.e($hint).'</p>' : '').'</div>');
    $money = fn ($k) => ($v = $s($k)) ? $v / 100 : '';
    $secret = function ($k, $l, $hint = null) use ($secretSource) {
        $src = $secretSource($k);
        $badge = $src === 'admin' ? '<span class="text-brand-green">Saved (hidden)</span>' : ($src === 'env' ? '<span class="text-muted">Using the value from the server .env</span>' : '<span class="text-brand-red">Not set</span>');
        $clear = $src === 'admin' ? '<label class="mt-1 flex items-center gap-2 text-xs"><input type="checkbox" name="clear_'.$k.'" value="1"> Remove saved value</label>' : '';
        return new HtmlString('<div><label class="label" for="secret_'.$k.'">'.e($l).' — '.$badge.'</label><input id="secret_'.$k.'" type="password" name="secret_'.$k.'" autocomplete="new-password" class="field" placeholder="Type a new value to replace; leave blank to keep">'.($hint ? '<p class="mt-1 text-xs text-muted">'.e($hint).'</p>' : '').$clear.'</div>');
    };
    $box = fn ($k, $l, $default = '0') => new HtmlString('<label class="flex items-center gap-2"><input type="checkbox" name="'.$k.'" value="1" '.((session()->hasOldInput() ? old($k) === '1' : $s($k, $default) === '1') ? 'checked' : '').'> '.e($l).'</label>');
    $card = 'space-y-3 rounded-lg border border-line bg-white p-5';
    $img = fn ($url, $alt) => new HtmlString('<img src="'.e($url).'" alt="'.e($alt).'" class="mb-2 h-14 w-auto rounded border border-line bg-white p-1">');
@endphp
<h1 class="text-3xl">Store settings</h1>
<nav class="mt-3 flex flex-wrap gap-3 text-sm" aria-label="Sections">@foreach(['general' => 'General', 'branding' => 'Branding', 'checkout' => 'Tax & delivery', 'payments' => 'Payments', 'whatsapp' => 'WhatsApp', 'email' => 'Email', 'content' => 'Homepage & social'] as $id => $label)<a class="underline" href="#{{ $id }}">{{ $label }}</a>@endforeach</nav>

<form method="post" enctype="multipart/form-data" action="{{ route('admin.settings.update') }}" class="mt-6 max-w-3xl space-y-6 text-sm">@csrf @method('PUT')

<section id="general" class="{{ $card }}"><h2 class="text-xl">General</h2>
    {!! $f('store_name', 'Store name') !!}{!! $f('store_email', 'Contact email (also receives new-order alerts)', 'email') !!}{!! $f('store_phone', 'Contact phone') !!}{!! $f('store_address', 'Business address') !!}
    <div class="grid gap-3 sm:grid-cols-2">{!! $f('default_country', 'Default country at checkout') !!}{!! $f('order_prefix', 'Order number prefix', 'text', 'Letters/numbers, up to 6 (e.g. BGF).', 'maxlength="6"') !!}</div>
    <div><label class="label" for="currency">Currency</label><select id="currency" name="currency" class="field">@foreach(['NGN','USD','GBP','EUR','GHS'] as $c)<option @selected(old('currency', $s('currency', 'NGN')) === $c)>{{ $c }}</option>@endforeach</select>
        <p class="mt-1 text-xs text-muted">Only choose a currency your payment gateway account supports.</p></div>
    <div><label class="label" for="fa">Footer text</label><textarea id="fa" name="footer_about" rows="2" class="field">{{ old('footer_about', $s('footer_about')) }}</textarea></div></section>

<section id="branding" class="{{ $card }}"><h2 class="text-xl">Branding</h2>
    <div>{!! $img(\App\Support\Branding::logo(), 'Current logo') !!}<label class="label" for="logo">Logo (PNG, JPG or WebP, max 2 MB)</label><input id="logo" type="file" name="logo" accept="image/png,image/jpeg,image/webp" class="field">
        @if($s('logo'))<label class="mt-1 flex items-center gap-2 text-xs"><input type="checkbox" name="reset_logo" value="1"> Remove my logo and use the default</label>@endif</div>
    <div>{!! $img(\App\Support\Branding::favicon(), 'Current favicon') !!}<label class="label" for="favicon">Favicon (PNG or ICO, small square, max 512 KB)</label><input id="favicon" type="file" name="favicon" accept="image/png,image/x-icon,image/webp" class="field">
        @if($s('favicon'))<label class="mt-1 flex items-center gap-2 text-xs"><input type="checkbox" name="reset_favicon" value="1"> Use the logo as favicon again</label>@endif</div>
    <div><p class="label">Brand colours</p><div class="flex flex-wrap gap-4">
        @foreach(['brand_red' => 'Primary (buttons)', 'brand_green' => 'Secondary (WhatsApp)', 'brand_yellow' => 'Accent (badges)'] as $k => $l)
            <label class="text-xs">{{ $l }}<br><input type="color" name="{{ $k }}" value="{{ old($k, \App\Support\Branding::color($k)) }}" class="mt-1 h-10 w-20 rounded border border-line"></label>@endforeach</div>
        <label class="mt-2 flex items-center gap-2 text-xs"><input type="checkbox" name="reset_colors" value="1"> Reset colours to the original brand values</label>
        <p class="mt-1 text-xs text-muted">Check the contrast: white text must stay readable on the primary and secondary colours.</p></div>
    <div>{!! $img(\App\Support\Branding::hero(), 'Current hero image') !!}<label class="label" for="hero_image">Default hero photo (shown when no hero slides are active)</label><input id="hero_image" type="file" name="hero_image" accept="image/*" class="field">
        @if($s('hero_image'))<label class="mt-1 flex items-center gap-2 text-xs"><input type="checkbox" name="reset_hero_image" value="1"> Remove my hero photo</label>@endif</div></section>

<section id="checkout" class="{{ $card }}"><h2 class="text-xl">Tax &amp; delivery</h2>
    <div class="grid gap-3 sm:grid-cols-2">{!! $f('tax_rate', 'Tax rate (%) added at checkout', 'number', '0 = no tax line.', 'step="0.01" min="0" max="100"') !!}{!! $f('tax_label', 'Tax label (e.g. VAT)') !!}</div>
    <div><label class="label" for="fdm">Free delivery above ({{ \App\Services\Money::symbol() }}, 0 = never)</label><input id="fdm" type="number" step="0.01" min="0" name="free_delivery_min" value="{{ old('free_delivery_min', $money('free_delivery_min')) }}" class="field">
        <p class="mt-1 text-xs text-muted">Delivery fees per area are set under <a class="underline" href="{{ route('admin.zones.index') }}">Delivery areas</a>.</p></div>
    {!! $f('low_stock_threshold', 'Low-stock alert at or below', 'number', null, 'min="0"') !!}</section>

<section id="payments" class="{{ $card }}"><h2 class="text-xl">Payments</h2>
    <p class="text-muted">Keys are stored encrypted in the database and never shown again. A gateway appears at checkout only when its secret key is set and it is switched on. Use TEST keys until you have completed the sandbox checks.</p>
    <div class="space-y-3 rounded border border-line p-3">{!! $box('gateway_paystack', 'Paystack enabled', '1') !!}{!! $secret('paystack_secret', 'Paystack secret key') !!}</div>
    <div class="space-y-3 rounded border border-line p-3">{!! $box('gateway_flutterwave', 'Flutterwave enabled', '1') !!}{!! $secret('flutterwave_secret', 'Flutterwave secret key') !!}{!! $secret('flutterwave_webhook_hash', 'Flutterwave webhook secret hash', 'Same value you set in the Flutterwave dashboard.') !!}</div>
    <div class="space-y-3 rounded border border-line p-3">{!! $box('gateway_stripe', 'Stripe enabled (only if your Stripe account supports your currency)', '1') !!}{!! $secret('stripe_secret', 'Stripe secret key') !!}{!! $secret('stripe_webhook_secret', 'Stripe webhook signing secret') !!}</div>
    <p class="text-xs text-muted">Webhook URLs to register: {{ url('/webhooks/paystack') }} · {{ url('/webhooks/flutterwave') }} · {{ url('/webhooks/stripe') }}</p>
    {!! $box('cod_enabled', 'Cash on delivery') !!}{!! $box('bank_transfer_enabled', 'Manual bank transfer') !!}
    <div><label class="label" for="bd">Bank transfer details (shown to customers)</label><textarea id="bd" name="bank_transfer_details" rows="3" class="field">{{ old('bank_transfer_details', $s('bank_transfer_details')) }}</textarea></div></section>

<section id="whatsapp" class="{{ $card }}"><h2 class="text-xl">WhatsApp</h2>
    {!! $f('whatsapp_phone', 'WhatsApp business number (international format, e.g. +2348012345678)') !!}{!! $f('wa_hours_notice', 'Availability notice (e.g. business hours)') !!}
    {!! $box('wa_floating', 'Show floating WhatsApp button', '1') !!}
    <div><label class="label" for="pt">Product enquiry template</label><textarea id="pt" name="wa_product_template" rows="9" class="field font-mono text-xs">{{ old('wa_product_template', $s('wa_product_template')) }}</textarea>
        <p class="mt-1 text-xs text-muted">Placeholders: {store} {product} {sku} {variant} {quantity} {price} {url}. Leave empty for the default.</p></div>
    {!! $f('wa_greeting', 'Default greeting (first line of messages)', 'text', 'Leave empty for “Hello <store name>,”.') !!}
    <div><label class="label" for="ct">Cart / order template</label><textarea id="ct" name="wa_cart_template" rows="8" class="field font-mono text-xs">{{ old('wa_cart_template', $s('wa_cart_template')) }}</textarea>
        <p class="mt-1 text-xs text-muted">Placeholders: {greeting} {store} {items} {subtotal} {discount} {tax} {delivery} {total} {url} {order} {customer} {phone} {address}. Leave empty for the default layout.</p></div>
    <div><label class="label" for="gt">General enquiry template</label><textarea id="gt" name="wa_general_template" rows="2" class="field">{{ old('wa_general_template', $s('wa_general_template')) }}</textarea></div></section>

<section id="email" class="{{ $card }}"><h2 class="text-xl">Email (SMTP)</h2>
    <p class="text-muted">Used for order confirmations and the newsletter. Leave the host empty to use the server's own mail settings.</p>
    <div class="grid gap-3 sm:grid-cols-2">{!! $f('mail_host', 'SMTP host') !!}{!! $f('mail_port', 'Port', 'number', 'Usually 587 (TLS) or 465 (SSL).') !!}{!! $f('mail_username', 'Username') !!}{!! $secret('mail_password', 'Password') !!}</div>
    <div class="grid gap-3 sm:grid-cols-3"><div><label class="label" for="me">Encryption</label><select id="me" name="mail_encryption" class="field">@foreach(['tls' => 'TLS (587)', 'ssl' => 'SSL (465)', 'none' => 'None'] as $k => $l)<option value="{{ $k }}" @selected(old('mail_encryption', $s('mail_encryption', 'tls')) === $k)>{{ $l }}</option>@endforeach</select></div>
        {!! $f('mail_from_address', 'From address', 'email') !!}{!! $f('mail_from_name', 'From name') !!}</div>
    <p class="text-xs text-muted">Save first, then use "Send test email" below. Emails are sent by the queue worker.</p></section>

<section id="content" class="{{ $card }}"><h2 class="text-xl">Homepage &amp; social</h2>
    {!! $box('announcement_enabled', 'Show announcement bar') !!}{!! $f('announcement_text', 'Announcement text') !!}{!! $f('hero_title', 'Default hero headline') !!}{!! $f('hero_text', 'Default hero text') !!}
    {!! $f('facebook_url', 'Facebook URL', 'url') !!}{!! $f('instagram_url', 'Instagram URL', 'url') !!}{!! $f('tiktok_url', 'TikTok URL', 'url') !!}</section>

<div class="sticky bottom-0 -mx-4 border-t border-line bg-white/95 p-4 backdrop-blur"><button class="btn-red">Save all settings</button></div>
</form>
<form method="post" action="{{ route('admin.settings.test-mail') }}" class="mt-4">@csrf<button class="btn-line">Send test email to {{ auth()->user()->email }}</button></form>
@endsection
