@extends('layouts.admin')
@section('title', 'Ideas articles')
@section('content')
<div class="flex items-center justify-between"><h1 class="text-3xl">Ideas for Your Space</h1><a href="{{ route('admin.articles.create') }}" class="btn-red">New article</a></div>
<div class="mt-6 divide-y divide-line rounded-lg border border-line bg-white text-sm">@forelse($articles as $a)
    <div class="flex items-center justify-between p-3"><a class="font-medium text-brand-red" href="{{ route('admin.articles.edit', $a) }}">{{ $a->title }}</a><span class="text-muted">{{ $a->is_published ? 'published' : 'draft' }}</span></div>
@empty<p class="p-5 text-muted">No articles yet.</p>@endforelse</div>
@endsection
