@extends('layouts.admin')
@section('title', 'Article')
@section('content')
@php $v = fn ($k, $d = '') => old($k, $article->{$k} ?? $d); $sel = old('products', $article->exists ? $article->products->pluck('id')->all() : []); @endphp
<h1 class="text-3xl">{{ $article->exists ? 'Edit article' : 'New article' }}</h1>
<form method="post" enctype="multipart/form-data" action="{{ $article->exists ? route('admin.articles.update', $article) : route('admin.articles.store') }}" class="mt-6 max-w-3xl space-y-3 rounded-lg border border-line bg-white p-5 text-sm">
    @csrf @if($article->exists) @method('PUT') @endif
    <input name="title" value="{{ $v('title') }}" class="field" placeholder="Title" aria-label="Title" required>
    <input name="slug" value="{{ $v('slug') }}" class="field" placeholder="slug (auto)" aria-label="Slug">
    <input name="excerpt" value="{{ $v('excerpt') }}" class="field" placeholder="Short summary" aria-label="Summary">
    <textarea name="body" rows="14" class="field" placeholder="Article text. Blank lines separate paragraphs." aria-label="Body">{{ $v('body') }}</textarea>
    <label>Cover image<input type="file" name="cover_image" accept="image/*" class="field"></label>
    <label>Products featured in this article (hold Ctrl/Cmd to select several, max 12)
        <select name="products[]" multiple size="8" class="field">@foreach($products as $p)<option value="{{ $p->id }}" @selected(in_array($p->id, $sel))>{{ $p->name }} ({{ $p->sku }})</option>@endforeach</select></label>
    @if($article->exists && $article->coverUrl() && $article->products->isNotEmpty())
    <div class="rounded border border-line p-3" x-data="{
            active: {{ $article->products->first()->id }},
            pins: {{ \Illuminate\Support\Js::from($article->products->mapWithKeys(fn ($p) => [$p->id => ['x' => $p->pivot->pos_x, 'y' => $p->pivot->pos_y, 'name' => $p->name]])) }},
            place(e) { const r = e.currentTarget.getBoundingClientRect(); this.pins[this.active].x = Math.round((e.clientX - r.left) / r.width * 10000) / 100; this.pins[this.active].y = Math.round((e.clientY - r.top) / r.height * 10000) / 100; }
        }">
        <p class="font-semibold">Product pins on the cover image</p>
        <p class="text-muted">Choose a product, then click the image to place its pin. Save the article to keep pins. Unpinned products still appear in "Shop this look".</p>
        <div class="mt-2 flex flex-wrap items-center gap-2">
            <select x-model.number="active" class="field w-auto" aria-label="Product to place"><template x-for="(p, id) in pins" :key="id"><option :value="id" x-text="p.name"></option></template></select>
            <button type="button" class="underline" @click="pins[active].x = null; pins[active].y = null">Remove this pin</button></div>
        <div class="relative mt-3 inline-block max-w-full cursor-crosshair" @click="place($event)">
            <img src="{{ $article->coverUrl() }}" alt="" class="block max-h-96 w-auto max-w-full rounded">
            <template x-for="(p, id) in pins" :key="id"><span x-show="p.x !== null" class="absolute -ml-3 -mt-3 flex h-6 w-6 items-center justify-center rounded-full border-2 border-white text-xs font-semibold text-white shadow" :class="id == active ? 'bg-brand-red' : 'bg-ink'" :style="`left:${p.x}%;top:${p.y}%`" x-text="Object.keys(pins).indexOf(String(id)) + 1"></span></template>
        </div>
        <template x-for="(p, id) in pins" :key="'h'+id"><div><input type="hidden" :name="`hotspots[${id}][x]`" :value="p.x ?? ''"><input type="hidden" :name="`hotspots[${id}][y]`" :value="p.y ?? ''"></div></template>
    </div>
    @elseif($article->exists)<p class="text-xs text-muted">Add a cover image and products, save, then you can place pins on the image.</p>@endif
    <input name="seo_description" value="{{ $v('seo_description') }}" class="field" placeholder="SEO description" aria-label="SEO description">
    <div class="grid gap-3 sm:grid-cols-2"><label>Publish date<input type="datetime-local" name="published_at" value="{{ old('published_at', $article->published_at?->format('Y-m-d\TH:i')) }}" class="field"></label>
        <label class="flex items-center gap-2 pt-6"><input type="checkbox" name="is_published" value="1" @checked($v('is_published', false))> Published</label></div>
    <button class="btn-red">Save</button>
</form>
@if($article->exists)<form method="post" action="{{ route('admin.articles.destroy', $article) }}" class="mt-4" onsubmit="return confirm('Delete this article?')">@csrf @method('DELETE')<button class="text-sm text-brand-red underline">Delete article</button></form>@endif
@endsection
