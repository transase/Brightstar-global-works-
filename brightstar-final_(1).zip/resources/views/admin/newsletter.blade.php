@extends('layouts.admin')
@section('title', 'Newsletter')
@section('content')
<h1 class="text-3xl">Newsletter</h1>
<p class="mt-1 text-sm text-muted">{{ $active }} active subscribers ({{ $total - $active }} unsubscribed). Every email includes an unsubscribe link. Always send a test to yourself first.</p>
<form method="post" action="{{ route('admin.newsletter.send') }}" class="mt-6 max-w-2xl space-y-3 rounded-lg border border-line bg-white p-5 text-sm">@csrf
    <input name="subject" value="{{ old('subject') }}" class="field" placeholder="Subject" aria-label="Subject" required>
    <textarea name="body" rows="12" class="field" placeholder="Message. Blank lines separate paragraphs." aria-label="Message" required>{{ old('body') }}</textarea>
    <div class="flex gap-2"><button name="test" value="1" class="btn-line">Send test to me</button>
        <button class="btn-red" onclick="return confirm('Send to all {{ $active }} active subscribers?')">Send to subscribers</button></div>
</form>
@endsection
