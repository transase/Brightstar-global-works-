@extends('layouts.admin')
@section('title', 'Category')
@section('content')
@php $v = fn ($k, $d = '') => old($k, $category->{$k} ?? $d); @endphp
<h1 class="text-3xl">{{ $category->exists ? 'Edit category' : 'New category' }}</h1>
<form method="post" enctype="multipart/form-data" action="{{ $category->exists ? route('admin.categories.update', $category) : route('admin.categories.store') }}" class="mt-6 max-w-2xl space-y-4 rounded-lg border border-line bg-white p-5 text-sm">
    @csrf @if($category->exists) @method('PUT') @endif
    <div><label class="label" for="n">Name</label><input id="n" name="name" value="{{ $v('name') }}" class="field" required></div>
    <div class="grid gap-4 sm:grid-cols-2"><div><label class="label" for="s">Slug (auto if empty)</label><input id="s" name="slug" value="{{ $v('slug') }}" class="field"></div>
        <div><label class="label" for="p">Parent category</label><select id="p" name="parent_id" class="field"><option value="">None (top level)</option>@foreach($parents as $p)<option value="{{ $p->id }}" @selected($v('parent_id') == $p->id)>{{ $p->name }}</option>@endforeach</select></div></div>
    <div><label class="label" for="d">Description</label><textarea id="d" name="description" rows="3" class="field">{{ $v('description') }}</textarea></div>
    <div><label class="label" for="i">Image</label><input id="i" type="file" name="image" accept="image/*"></div>
    <div class="grid gap-4 sm:grid-cols-2"><input name="seo_title" value="{{ $v('seo_title') }}" class="field" placeholder="SEO title" aria-label="SEO title"><input type="number" min="0" name="sort_order" value="{{ $v('sort_order', 0) }}" class="field" placeholder="Sort order" aria-label="Sort order"></div>
    <textarea name="seo_description" rows="2" class="field" placeholder="SEO description" aria-label="SEO description">{{ $v('seo_description') }}</textarea>
    <div><label class="label" for="sf">Specification fields for products in this category (comma separated)</label><input id="sf" name="spec_fields" value="{{ $v('spec_fields') }}" class="field" placeholder="e.g. Seats, Frame material, Fabric type">
        <p class="mt-1 text-xs text-muted">These appear as suggested “Label: value” lines on the product form and in the product specifications.</p></div>
    <label class="flex items-center gap-2"><input type="checkbox" name="is_active" value="1" @checked($v('is_active', true))> Visible on the store</label>
    <label class="flex items-center gap-2"><input type="checkbox" name="is_featured" value="1" @checked($v('is_featured', false))> Featured</label>
    <button class="btn-red">Save</button>
</form>
@endsection
