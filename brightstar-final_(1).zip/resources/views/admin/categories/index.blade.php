@extends('layouts.admin')
@section('title', 'Categories')
@section('content')
<div class="flex items-center justify-between"><h1 class="text-3xl">Categories</h1><a href="{{ route('admin.categories.create') }}" class="btn-red">Add category</a></div>
<div class="mt-6 divide-y divide-line rounded-lg border border-line bg-white text-sm">
@forelse($categories as $c)
    @foreach([[$c, 0]] + $c->children->map(fn ($x) => [$x, 1])->all() as [$cat, $depth])
        <div class="flex items-center justify-between gap-3 p-3" style="padding-left: {{ 12 + $depth * 28 }}px">
            <div><a class="font-medium {{ $cat->is_active ? '' : 'text-muted line-through' }}" href="{{ route('admin.categories.edit', $cat) }}">{{ $cat->name }}</a> <span class="text-muted">/{{ $cat->slug }} · order {{ $cat->sort_order }}</span></div>
            <div class="flex items-center gap-3">
                @foreach(['up' => '↑', 'down' => '↓'] as $dir => $arrow)<form method="post" action="{{ route('admin.categories.move', $cat) }}">@csrf<input type="hidden" name="dir" value="{{ $dir }}"><button class="px-1 text-lg" aria-label="Move {{ $cat->name }} {{ $dir }}">{{ $arrow }}</button></form>@endforeach
                <form method="post" action="{{ route('admin.categories.destroy', $cat) }}" onsubmit="return confirm('Delete this category?')">@csrf @method('DELETE')<button class="text-brand-red underline">Delete</button></form></div></div>
    @endforeach
@empty<p class="p-5 text-muted">No categories yet.</p>@endforelse</div>
@endsection
