@extends('layouts.admin')
@section('title', 'Delivery areas')
@section('content')
<h1 class="text-3xl">Delivery areas &amp; fees</h1>
<p class="mt-1 text-sm text-muted">Customers pick one of the active areas at checkout. A free-delivery threshold can be set in Settings → Tax &amp; delivery.</p>
<form method="post" action="{{ route('admin.zones.store') }}" class="mt-6 grid max-w-3xl gap-2 rounded-lg border border-line bg-white p-4 text-sm sm:grid-cols-5">@csrf
    <input name="name" class="field sm:col-span-2" placeholder="Area name (e.g. Lagos Island)" aria-label="Area name" required>
    <input name="state" class="field" placeholder="State (optional)" aria-label="State">
    <input name="fee" type="number" step="0.01" min="0" class="field" placeholder="Fee" aria-label="Fee" required>
    <input type="hidden" name="is_active" value="1"><button class="btn-red">Add</button></form>
<div class="mt-4 max-w-3xl divide-y divide-line rounded-lg border border-line bg-white text-sm">@forelse($zones as $z)
    <div class="p-3"><form method="post" action="{{ route('admin.zones.update', $z) }}" class="grid items-center gap-2 sm:grid-cols-6">@csrf @method('PUT')
        <input name="name" value="{{ $z->name }}" class="field sm:col-span-2" aria-label="Name"><input name="state" value="{{ $z->state }}" class="field" aria-label="State">
        <input name="fee" type="number" step="0.01" min="0" value="{{ $z->fee / 100 }}" class="field" aria-label="Fee">
        <label class="flex items-center gap-2"><input type="checkbox" name="is_active" value="1" @checked($z->is_active)> Active</label>
        <button class="btn-line">Save</button></form>
        <form method="post" action="{{ route('admin.zones.destroy', $z) }}" class="mt-1" onsubmit="return confirm('Delete this area?')">@csrf @method('DELETE')<button class="text-xs text-brand-red underline">Delete</button></form></div>
@empty<p class="p-5 text-muted">No areas yet. Checkout will charge no delivery fee until you add one.</p>@endforelse</div>
@endsection
