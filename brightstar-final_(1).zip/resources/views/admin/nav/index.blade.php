@extends('layouts.admin')
@section('title', 'Navigation')
@section('content')
@php $v = fn ($k, $d = '') => old($k, $item->{$k} ?? $d); @endphp
<div class="flex flex-wrap items-center justify-between gap-3"><h1 class="text-3xl">Navigation &amp; mega-menu</h1>
    @if($tops->isEmpty())<form method="post" action="{{ route('admin.nav.defaults') }}">@csrf<button class="btn-line">Create default menu</button></form>@endif</div>
<p class="mt-2 text-sm text-muted">While no items exist the store shows its built-in menu. Add sub-items under a top-level link to create a mega-menu column (with optional image).</p>
<form method="post" enctype="multipart/form-data" action="{{ $item->exists ? route('admin.nav.update', $item) : route('admin.nav.store') }}" class="mt-6 grid max-w-3xl gap-3 rounded-lg border border-line bg-white p-5 text-sm sm:grid-cols-2">
    @csrf @if($item->exists) @method('PUT') @endif
    <input name="label" value="{{ $v('label') }}" class="field" placeholder="Label" aria-label="Label" required>
    <input name="url" value="{{ $v('url') }}" class="field" placeholder="/category/sofas or https://…" aria-label="URL" required>
    <select name="parent_id" class="field" aria-label="Parent"><option value="">Top-level item</option>@foreach($tops as $t)@if($t->id !== $item->id)<option value="{{ $t->id }}" @selected($v('parent_id') == $t->id)>Under: {{ $t->label }}</option>@endif @endforeach</select>
    <input type="number" min="0" name="sort_order" value="{{ $v('sort_order', 0) }}" class="field" placeholder="Order" aria-label="Order">
    <label class="sm:col-span-2">Image (mega-menu sub-items)<input type="file" name="image" accept="image/*" class="field"></label>
    <label class="flex items-center gap-2"><input type="checkbox" name="is_visible" value="1" @checked($v('is_visible', true))> Visible</label>
    <label class="flex items-center gap-2"><input type="checkbox" name="is_featured" value="1" @checked($v('is_featured', false))> Featured</label>
    <button class="btn-red sm:col-span-2">Save</button>
</form>
<div class="mt-6 divide-y divide-line rounded-lg border border-line bg-white text-sm">
@foreach($tops as $t)
    @foreach([[$t, 0]] + \App\Models\NavItem::where('parent_id', $t->id)->orderBy('sort_order')->get()->map(fn ($c) => [$c, 1])->all() as [$n, $depth])
    <div class="flex items-center justify-between gap-3 p-3" style="padding-left: {{ 12 + $depth * 28 }}px">
        <div class="{{ $n->is_visible ? '' : 'text-muted line-through' }}"><strong>{{ $n->label }}</strong> <span class="text-muted">{{ $n->url }} · #{{ $n->sort_order }}</span></div>
        <div class="flex gap-3"><a class="underline" href="{{ route('admin.nav.edit', $n) }}">Edit</a>
            <form method="post" action="{{ route('admin.nav.destroy', $n) }}" onsubmit="return confirm('Delete?')">@csrf @method('DELETE')<button class="text-brand-red underline">Delete</button></form></div></div>
    @endforeach
@endforeach
</div>
@endsection
