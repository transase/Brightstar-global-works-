@extends('layouts.admin')
@section('title', 'Pages')
@section('content')
@php $v = fn ($k, $d = '') => old($k, $page->{$k} ?? $d); @endphp
<h1 class="text-3xl">Pages</h1>
<p class="mt-1 text-sm text-muted">About Us, Contact Us, delivery, returns, privacy and terms. Only publish policies and guarantees the business has confirmed.</p>
<form method="post" action="{{ $page->exists ? route('admin.pages.update', $page) : route('admin.pages.store') }}" class="mt-6 max-w-3xl space-y-3 rounded-lg border border-line bg-white p-5 text-sm">@csrf @if($page->exists) @method('PUT') @endif
    <div class="grid gap-3 sm:grid-cols-2"><input name="title" value="{{ $v('title') }}" class="field" placeholder="Title" aria-label="Title" required><input name="slug" value="{{ $v('slug') }}" class="field" placeholder="slug (about, contact, delivery…)" aria-label="Slug"></div>
    <textarea name="body" rows="12" class="field" placeholder="Content" aria-label="Content">{{ $v('body') }}</textarea>
    <input name="seo_description" value="{{ $v('seo_description') }}" class="field" placeholder="SEO description" aria-label="SEO description">
    <label class="flex items-center gap-2"><input type="checkbox" name="is_published" value="1" @checked($v('is_published', true))> Published</label><button class="btn-red">Save page</button></form>
<div class="mt-6 divide-y divide-line rounded-lg border border-line bg-white text-sm">@forelse($pages as $p)<div class="flex items-center justify-between p-3"><span><strong>{{ $p->title }}</strong> <span class="text-muted">/{{ $p->slug }}</span></span>
    <span class="flex gap-3"><a class="underline" href="{{ route('admin.pages.edit', $p) }}">Edit</a><form method="post" action="{{ route('admin.pages.destroy', $p) }}" onsubmit="return confirm('Delete?')">@csrf @method('DELETE')<button class="text-brand-red underline">Delete</button></form></span></div>@empty<p class="p-5 text-muted">No pages yet.</p>@endforelse</div>
@endsection
