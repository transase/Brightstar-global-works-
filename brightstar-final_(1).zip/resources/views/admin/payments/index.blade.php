@extends('layouts.admin')
@section('title', 'Payments')
@section('content')
@php $m = fn ($v, $c) => \App\Services\Money::format($v, $c); @endphp
<h1 class="text-3xl">Payments &amp; reconciliation</h1>
<nav class="mt-4 flex gap-4 text-sm"><a href="{{ route('admin.payments.index') }}">All</a><a href="{{ route('admin.payments.index', ['attention' => 1]) }}" class="text-brand-red">Needs attention (failed, or pending over 1 hour)</a></nav>
<div class="mt-4 overflow-x-auto rounded-lg border border-line bg-white"><table class="w-full text-left text-sm"><thead class="bg-surface text-muted"><tr><th class="p-3">Reference</th><th>Order</th><th>Gateway</th><th>Amount</th><th>Status</th><th>Created</th><th></th></tr></thead>
<tbody class="divide-y divide-line">@foreach($payments as $p)<tr><td class="p-3">{{ $p->reference }}</td><td><a class="text-brand-red" href="{{ route('admin.orders.show', $p->order) }}">{{ $p->order->number }}</a></td><td>{{ $p->gateway }}</td><td>{{ $m($p->amount, $p->currency) }}</td><td>{{ $p->status }}@if(! empty($p->meta['needs_review']))<br><span class="text-xs font-semibold text-brand-red">Needs review: {{ str_replace('_', ' ', $p->meta['needs_review']) }}</span>@endif</td><td>{{ $p->created_at->format('d M H:i') }}</td>
<td>@if($p->status !== 'successful')<form method="post" action="{{ route('admin.payments.reverify', $p) }}">@csrf<button class="underline">Re-check</button></form>@endif</td></tr>@endforeach</tbody></table></div>
<div class="mt-4">{{ $payments->links() }}</div>
<p class="mt-4 text-xs text-muted">Refunds are issued by an admin from the order page and sent to the provider; the order is marked refunded only after the provider accepts the request.</p>
@endsection
