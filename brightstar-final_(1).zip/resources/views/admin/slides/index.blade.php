@extends('layouts.admin')
@section('title', 'Hero slides & banners')
@section('content')
@php $v = fn ($k, $d = '') => old($k, $slide->{$k} ?? $d); $dt = fn ($k) => old($k, $slide->{$k}?->format('Y-m-d\TH:i')); @endphp
<h1 class="text-3xl">Hero slides &amp; promo banners</h1>
<form method="post" enctype="multipart/form-data" action="{{ $slide->exists ? route('admin.slides.update', $slide) : route('admin.slides.store') }}" class="mt-6 grid max-w-3xl gap-3 rounded-lg border border-line bg-white p-5 text-sm sm:grid-cols-2">
    @csrf @if($slide->exists) @method('PUT') @endif
    <h2 class="text-xl sm:col-span-2">{{ $slide->exists ? 'Edit' : 'Add' }}</h2>
    <select name="type" class="field" aria-label="Type"><option value="hero" @selected($v('type') === 'hero')>Hero slide</option><option value="promo" @selected($v('type') === 'promo')>Promotional banner</option></select>
    <input name="heading" value="{{ $v('heading') }}" class="field" placeholder="Heading" aria-label="Heading" required>
    <textarea name="description" rows="2" class="field sm:col-span-2" placeholder="Description" aria-label="Description">{{ $v('description') }}</textarea>
    <input name="cta_text" value="{{ $v('cta_text') }}" class="field" placeholder="Button text" aria-label="Button text">
    <input name="url" value="{{ $v('url') }}" class="field" placeholder="/shop or https://…" aria-label="Destination URL">
    <label>Starts<input type="datetime-local" name="starts_at" value="{{ $dt('starts_at') }}" class="field"></label>
    <label>Ends<input type="datetime-local" name="ends_at" value="{{ $dt('ends_at') }}" class="field"></label>
    <label>Image<input type="file" name="image" accept="image/*" class="field"></label>
    <label>Sort order<input type="number" min="0" name="sort_order" value="{{ $v('sort_order', 0) }}" class="field"></label>
    <label class="flex items-center gap-2 sm:col-span-2"><input type="checkbox" name="is_active" value="1" @checked($v('is_active', true))> Active</label>
    <button class="btn-red sm:col-span-2">Save</button>
</form>
<div class="mt-6 divide-y divide-line rounded-lg border border-line bg-white text-sm">@forelse($slides as $s)
    <div class="flex items-center justify-between gap-3 p-3"><div><strong>{{ $s->heading }}</strong> <span class="text-muted">· {{ $s->type }} · {{ $s->is_active ? 'active' : 'hidden' }}{{ $s->starts_at ? ' · from '.$s->starts_at->format('d M') : '' }}{{ $s->ends_at ? ' · to '.$s->ends_at->format('d M') : '' }}</span></div>
        <div class="flex gap-3"><a class="underline" href="{{ route('admin.slides.edit', $s) }}">Edit</a>
        <form method="post" action="{{ route('admin.slides.destroy', $s) }}" onsubmit="return confirm('Delete?')">@csrf @method('DELETE')<button class="text-brand-red underline">Delete</button></form></div></div>@empty<p class="p-5 text-muted">Nothing yet. The homepage uses the text in Settings until you add a hero slide.</p>@endforelse</div>
@endsection
