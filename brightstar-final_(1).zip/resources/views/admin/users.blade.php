@extends('layouts.admin')
@section('title', 'Users')
@section('content')
<h1 class="text-3xl">Staff &amp; customers</h1>
<p class="mt-1 text-sm text-muted"><strong>admin</strong> everything · <strong>manager</strong> catalogue, orders, marketing (no settings, users or refunds) · <strong>staff</strong> orders only · <strong>customer</strong> shop account.</p>
<form method="post" action="{{ route('admin.users.store') }}" class="mt-6 grid max-w-4xl gap-2 rounded-lg border border-line bg-white p-4 text-sm sm:grid-cols-5">@csrf
    <input name="name" class="field" placeholder="Full name" aria-label="Name" required><input name="email" type="email" class="field" placeholder="Email" aria-label="Email" required>
    <select name="role" class="field" aria-label="Role">@foreach($roles as $r)<option @selected($r === 'staff')>{{ $r }}</option>@endforeach</select>
    <input name="password" type="password" autocomplete="new-password" class="field" placeholder="Password (10+ chars)" aria-label="Password" required><button class="btn-red">Create account</button></form>
<form class="mt-4 flex flex-wrap gap-2 text-sm"><input name="q" value="{{ request('q') }}" placeholder="Name or email" class="field max-w-xs"><select name="role" class="field w-auto"><option value="">All roles</option>@foreach($roles as $r)<option @selected(request('role') === $r)>{{ $r }}</option>@endforeach</select><button class="btn-line">Filter</button></form>
<div class="mt-4 divide-y divide-line rounded-lg border border-line bg-white text-sm">@foreach($users as $u)
    <div class="p-3"><form method="post" action="{{ route('admin.users.update', $u) }}" class="grid items-center gap-2 sm:grid-cols-5">@csrf @method('PUT')
        <div class="sm:col-span-2"><strong>{{ $u->name }}</strong><br><span class="text-muted">{{ $u->email }}</span></div>
        <select name="role" class="field" aria-label="Role for {{ $u->name }}">@foreach($roles as $r)<option @selected($u->role === $r)>{{ $r }}</option>@endforeach</select>
        <input name="password" type="password" autocomplete="new-password" class="field" placeholder="New password (optional)" aria-label="New password"><button class="btn-line">Save</button></form>
        @if($u->id !== auth()->id())<form method="post" action="{{ route('admin.users.destroy', $u) }}" class="mt-1" onsubmit="return confirm('Delete this account?')">@csrf @method('DELETE')<button class="text-xs text-brand-red underline">Delete</button></form>@endif</div>
@endforeach</div><div class="mt-4">{{ $users->links() }}</div>
@endsection
