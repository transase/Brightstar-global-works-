@extends('layouts.admin')
@section('title', $product->exists ? 'Edit '.$product->name : 'New product')
@section('content')
@php
    $v = fn ($k, $d = '') => old($k, $product->{$k} ?? $d);
    $mv = fn ($k) => old($k, $product->{$k} !== null ? $product->{$k} / 100 : '');
    $variants = old('variants', $product->exists ? $product->variants->map(fn ($x) => ['id' => $x->id, 'sku' => $x->sku, 'colour' => $x->colour, 'size' => $x->size, 'finish' => $x->finish, 'upholstery' => $x->upholstery, 'price_adjustment' => $x->price_adjustment / 100, 'stock_quantity' => $x->stock_quantity, 'image_url' => $x->image ? \App\Support\Media::url($x->image) : ''])->all() : []);
    $isAdminOrManager = in_array(auth()->user()->role, ['admin', 'manager']);
@endphp
<div class="flex items-center justify-between"><h1 class="text-3xl">{{ $product->exists ? 'Edit product' : 'New product' }}</h1>
    @if($product->exists)<form method="post" action="{{ route('admin.products.duplicate', $product) }}">@csrf<button class="btn-line">Duplicate</button></form>@endif</div>

<form method="post" enctype="multipart/form-data" action="{{ $product->exists ? route('admin.products.update', $product) : route('admin.products.store') }}" class="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]" x-data="{ cat: '{{ $v('category_id') }}', hints: {{ \Illuminate\Support\Js::from($categories->mapWithKeys(fn ($c) => [$c->id => $c->spec_fields])) }} }">
    @csrf @if($product->exists) @method('PUT') @endif
    <div class="space-y-6">
        <section class="space-y-4 rounded-lg border border-line bg-white p-5 text-sm"><h2 class="text-xl">Basics</h2>
            <div><label class="label" for="name">Name</label><input id="name" name="name" value="{{ $v('name') }}" class="field" required></div>
            <div class="grid gap-4 sm:grid-cols-2"><div><label class="label" for="sku">SKU</label><input id="sku" name="sku" value="{{ $v('sku') }}" class="field" required></div>
                <div><label class="label" for="slug">URL slug (auto if empty)</label><input id="slug" name="slug" value="{{ $v('slug') }}" class="field"></div></div>
            <div class="grid gap-4 sm:grid-cols-2"><div><label class="label" for="brand">Brand / manufacturer</label><input id="brand" name="brand" value="{{ $v('brand') }}" class="field"></div></div>
            <div><label class="label" for="sd">Short description</label><input id="sd" name="short_description" value="{{ $v('short_description') }}" class="field"></div>
            <div><label class="label" for="d">Full description</label><textarea id="d" name="description" rows="6" class="field">{{ $v('description') }}</textarea></div>
        </section>

        <section class="space-y-4 rounded-lg border border-line bg-white p-5 text-sm"><h2 class="text-xl">Specifications</h2>
            <div class="grid gap-4 sm:grid-cols-4">@foreach([['width','Width'],['depth','Depth'],['height','Height'],['weight','Weight']] as [$k,$l])<div><label class="label" for="{{ $k }}">{{ $l }}</label><input id="{{ $k }}" type="number" step="any" name="{{ $k }}" value="{{ $v($k) }}" class="field"></div>@endforeach</div>
            <div class="grid gap-4 sm:grid-cols-3"><div><label class="label" for="du">Unit</label><select id="du" name="dimension_unit" class="field">@foreach(['cm','mm','in','m'] as $u)<option @selected($v('dimension_unit', 'cm') === $u)>{{ $u }}</option>@endforeach</select></div>
                <div><label class="label" for="mat">Material</label><input id="mat" name="material" value="{{ $v('material') }}" class="field"></div>
                <div><label class="label" for="fin">Finish / upholstery</label><input id="fin" name="finish" value="{{ $v('finish') }}" class="field"></div></div>
            <div class="grid gap-4 sm:grid-cols-2"><div><label class="label" for="w">Warranty (only if confirmed)</label><input id="w" name="warranty" value="{{ $v('warranty') }}" class="field"></div>
                <div><label class="label" for="dt">Estimated delivery time</label><input id="dt" name="delivery_timeframe" value="{{ $v('delivery_timeframe') }}" class="field"></div></div>
            <div><label class="label" for="di">Delivery information (shown on the product page)</label><textarea id="di" name="delivery_info" rows="2" class="field">{{ $v('delivery_info') }}</textarea></div>
            <div><label class="label" for="specs">Additional specifications (one “Label: value” per line)</label>
                <textarea id="specs" name="specs_text" rows="4" class="field" placeholder="Seats: 3&#10;Frame material: Solid wood">{{ old('specs_text', collect($product->specs ?? [])->map(fn ($val, $k) => "$k: $val")->implode("\n")) }}</textarea>
                <p class="mt-1 text-xs text-muted" x-show="hints[cat]">Suggested for this category: <span x-text="hints[cat]"></span></p></div>
            <label class="flex items-center gap-2"><input type="checkbox" name="assembly_required" value="1" @checked($v('assembly_required', false))> Assembly required</label>
        </section>

        <section class="rounded-lg border border-line bg-white p-5 text-sm" x-data="{ rows: {{ \Illuminate\Support\Js::from(array_values($variants)) }} }">
            <div class="flex items-center justify-between"><h2 class="text-xl">Variants</h2><button type="button" class="btn-line" @click="rows.push({id:'',sku:'',colour:'',size:'',finish:'',upholstery:'',price_adjustment:0,stock_quantity:0,image_url:''})">Add variant</button></div>
            <p class="mt-1 text-muted">Colour, size, finish or upholstery options. The price adjustment is added to the product price (can be negative).</p>
            <template x-for="(r, i) in rows" :key="i"><div class="mt-3 grid gap-2 rounded border border-line p-3 sm:grid-cols-4">
                <input type="hidden" :name="`variants[${i}][id]`" x-model="r.id">
                <input :name="`variants[${i}][sku]`" x-model="r.sku" class="field" placeholder="SKU" aria-label="Variant SKU">
                <input :name="`variants[${i}][colour]`" x-model="r.colour" class="field" placeholder="Colour" aria-label="Colour">
                <input :name="`variants[${i}][size]`" x-model="r.size" class="field" placeholder="Size" aria-label="Size">
                <input :name="`variants[${i}][finish]`" x-model="r.finish" class="field" placeholder="Finish" aria-label="Finish">
                <input :name="`variants[${i}][upholstery]`" x-model="r.upholstery" class="field" placeholder="Upholstery" aria-label="Upholstery">
                <input type="number" step="any" :name="`variants[${i}][price_adjustment]`" x-model="r.price_adjustment" class="field" placeholder="Price +/-" aria-label="Price adjustment">
                <input type="number" min="0" :name="`variants[${i}][stock_quantity]`" x-model="r.stock_quantity" class="field" placeholder="Stock" aria-label="Variant stock">
                <label class="text-xs text-muted sm:col-span-2">Variant image <input type="file" :name="`variants[${i}][image]`" accept="image/*" class="mt-1 block w-full text-xs"><img x-show="r.image_url" :src="r.image_url" alt="" class="mt-1 h-12 w-12 rounded object-cover"></label>
                <button type="button" class="text-left text-brand-red underline" @click="rows.splice(i, 1)">Remove</button></div></template>
        </section>

        <section class="space-y-3 rounded-lg border border-line bg-white p-5 text-sm"><h2 class="text-xl">Images</h2>
            <div><label class="label" for="mi">Main image</label><input id="mi" type="file" name="main_image" accept="image/*">@if($product->main_image)<img src="{{ $product->imageUrl() }}" alt="" class="mt-2 h-24 rounded">@endif</div>
            <div><label class="label" for="g">Add gallery images</label><input id="g" type="file" name="gallery[]" accept="image/*" multiple></div>
            @if($product->exists && $product->images->isNotEmpty())<div class="flex flex-wrap gap-3">@foreach($product->images as $im)
                <div class="text-center"><img src="{{ \App\Support\Media::url($im->path) }}" alt="" class="h-20 w-20 rounded object-cover">
                    <div class="flex justify-center gap-2 text-xs"><button form="mvu-{{ $im->id }}" aria-label="Move earlier">←</button><button form="mvd-{{ $im->id }}" aria-label="Move later">→</button></div>
                    <button form="del-{{ $im->id }}" class="text-xs text-brand-red underline">Delete</button></div>@endforeach</div>
            <p class="text-xs text-muted">To replace an image: delete it and upload a new one. The main image is shown first on the product page.</p>@endif
        </section>

        @if($product->exists && ! empty($all))<section class="rounded-lg border border-line bg-white p-5 text-sm"><h2 class="text-xl">Related products</h2>
            <select name="related[]" multiple size="6" class="field mt-3" aria-label="Related products">@foreach($all as $r)<option value="{{ $r->id }}" @selected($product->related->contains('id', $r->id))>{{ $r->name }} ({{ $r->sku }})</option>@endforeach</select></section>@endif

        <section class="space-y-3 rounded-lg border border-line bg-white p-5 text-sm"><h2 class="text-xl">SEO</h2>
            <input name="seo_title" value="{{ $v('seo_title') }}" class="field" placeholder="SEO title" aria-label="SEO title">
            <textarea name="seo_description" rows="2" class="field" placeholder="SEO description" aria-label="SEO description">{{ $v('seo_description') }}</textarea>
            <label>Social sharing image (used when the link is shared)<input type="file" name="seo_image" accept="image/*" class="field"></label>
            @if($product->seo_image)<img src="{{ \App\Support\Media::url($product->seo_image) }}" alt="" class="h-16 rounded">@endif</section>
    </div>

    <aside class="h-fit space-y-4 rounded-lg border border-line bg-white p-5 text-sm lg:sticky lg:top-4">
        <div><label class="label" for="st">Status</label><select id="st" name="status" class="field">@foreach(['draft','published','archived'] as $s)<option @selected($v('status', 'draft') === $s)>{{ $s }}</option>@endforeach</select></div>
        <div><label class="label" for="cat">Category</label><select id="cat" name="category_id" class="field" x-model="cat"><option value="">None</option>@foreach($categories as $c)<option value="{{ $c->id }}" @selected($v('category_id') == $c->id)>{{ $c->parent_id ? '— ' : '' }}{{ $c->name }}</option>@endforeach</select></div>
        <div><label class="label" for="pr">Regular price ({{ \App\Services\Money::symbol() }})</label><input id="pr" type="number" step="0.01" name="price" value="{{ $mv('price') }}" class="field" required></div>
        <div><label class="label" for="sp">Sale price</label><input id="sp" type="number" step="0.01" name="sale_price" value="{{ $mv('sale_price') }}" class="field"></div>
        @if($isAdminOrManager)<div><label class="label" for="cp">Cost price (staff only)</label><input id="cp" type="number" step="0.01" name="cost_price" value="{{ $mv('cost_price') }}" class="field"></div>@endif
        <div><label class="label" for="sq">Stock quantity</label><input id="sq" type="number" min="0" name="stock_quantity" value="{{ $v('stock_quantity', 0) }}" class="field" required></div>
        @foreach(['track_stock' => 'Track stock', 'allow_backorder' => 'Allow backorders', 'enquiry_only' => 'Enquiry only (price on request)', 'is_featured' => 'Featured', 'is_best_seller' => 'Best seller (manual)', 'is_new_arrival' => 'New arrival'] as $k => $l)
            <label class="flex items-center gap-2"><input type="checkbox" name="{{ $k }}" value="1" @checked($v($k, $k === 'track_stock'))> {{ $l }}</label>@endforeach
        <button class="btn-red w-full">Save product</button>
    </aside>
</form>
@if($product->exists)@foreach($product->images as $im)
<form id="mvu-{{ $im->id }}" method="post" action="{{ route('admin.products.images.move', [$product, $im]) }}">@csrf<input type="hidden" name="dir" value="up"></form>
<form id="mvd-{{ $im->id }}" method="post" action="{{ route('admin.products.images.move', [$product, $im]) }}">@csrf<input type="hidden" name="dir" value="down"></form>
<form id="del-{{ $im->id }}" method="post" action="{{ route('admin.products.images.delete', [$product, $im]) }}" onsubmit="return confirm('Delete this image?')">@csrf @method('DELETE')</form>@endforeach
<form method="post" action="{{ route('admin.products.destroy', $product) }}" class="mt-6" onsubmit="return confirm('Delete this product permanently?')">@csrf @method('DELETE')<button class="text-sm text-brand-red underline">Delete product</button></form>@endif
@endsection
