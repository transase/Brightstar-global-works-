@extends('layouts.admin')
@section('title', 'Products')
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v); @endphp
<div class="flex flex-wrap items-center justify-between gap-3"><h1 class="text-3xl">Products</h1>
    <div class="flex flex-wrap gap-2"><a href="{{ route('admin.products.export') }}" class="btn-line">Export CSV</a><a href="{{ route('admin.products.create') }}" class="btn-red">Add product</a></div></div>

<form method="post" action="{{ route('admin.products.import') }}" enctype="multipart/form-data" class="mt-4 flex flex-wrap items-center gap-2 rounded-lg border border-line bg-white p-3 text-sm">@csrf
    <label for="csv" class="font-medium">Import CSV</label><input id="csv" type="file" name="file" accept=".csv,.txt" required><button class="btn-line">Upload</button>
    <span class="text-muted">Columns: sku, name, price (required); category_slug, sale_price, cost_price, stock_quantity, status, short_description, material, finish.</span></form>
@if(session('import_errors'))<div class="mt-3 rounded border border-brand-red/30 bg-white p-3 text-sm"><p class="font-semibold text-brand-red">Rows skipped</p><ul class="mt-1 list-disc pl-5">@foreach(session('import_errors') as $e)<li>{{ $e }}</li>@endforeach</ul></div>@endif

<form class="mt-4 flex flex-wrap gap-2 text-sm"><input name="q" value="{{ request('q') }}" placeholder="Name or SKU" class="field max-w-xs">
    <select name="status" class="field w-auto"><option value="">Any status</option>@foreach(['draft','published','archived'] as $s)<option @selected(request('status') === $s)>{{ $s }}</option>@endforeach</select>
    <select name="category" class="field w-auto"><option value="">Any category</option>@foreach($categories as $c)<option value="{{ $c->id }}" @selected(request('category') == $c->id)>{{ $c->name }}</option>@endforeach</select><button class="btn-red">Filter</button></form>

<form method="post" action="{{ route('admin.products.bulk') }}" x-data="{ all: false }" class="mt-4">@csrf
    <div class="flex flex-wrap items-center gap-2 text-sm">
        <select name="action" class="field w-auto" required><option value="">Bulk action…</option><option value="publish">Publish</option><option value="unpublish">Unpublish (draft)</option><option value="archive">Archive</option>
            <option value="price_percent">Change price by % (value)</option><option value="stock_set">Set stock to (value)</option><option value="category">Assign category ID (value)</option></select>
        <input name="value" type="number" step="any" class="field w-28" placeholder="Value"><button class="btn-line">Apply to selected</button></div>
    <div class="mt-3 overflow-x-auto rounded-lg border border-line bg-white"><table class="w-full text-left text-sm">
        <thead class="bg-surface text-muted"><tr><th class="p-3"><input type="checkbox" aria-label="Select all" @change="document.querySelectorAll('.row-check').forEach(c => c.checked = $event.target.checked)"></th><th>Product</th><th>SKU</th><th>Price</th><th>Stock</th><th>Status</th></tr></thead>
        <tbody class="divide-y divide-line">@foreach($products as $p)<tr>
            <td class="p-3"><input class="row-check" type="checkbox" name="ids[]" value="{{ $p->id }}" aria-label="Select {{ $p->name }}"></td>
            <td><a class="font-medium text-brand-red" href="{{ route('admin.products.edit', $p) }}">{{ $p->name }}</a><br><span class="text-muted">{{ $p->category?->name }}</span></td>
            <td>{{ $p->sku }}</td><td>{{ $m($p->currentPrice()) }}</td><td class="{{ $p->track_stock && $p->stock_quantity < 1 ? 'text-brand-red' : '' }}">{{ $p->stock_quantity }}</td><td>{{ $p->status }}</td></tr>@endforeach</tbody></table></div>
</form>
<div class="mt-4">{{ $products->links() }}</div>
@endsection
