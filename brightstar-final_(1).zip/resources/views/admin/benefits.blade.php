@extends('layouts.admin')
@section('title', 'Why shop with us')
@section('content')
<h1 class="text-3xl">“Why shop with us” benefits</h1>
<p class="mt-1 text-sm text-muted">Shown on the homepage. <strong>Only publish promises the business has confirmed</strong> (delivery times, installation, warranties). The section stays hidden until you add one.</p>
<form method="post" action="{{ route('admin.benefits.store') }}" class="mt-6 grid max-w-3xl gap-2 rounded-lg border border-line bg-white p-4 text-sm sm:grid-cols-5">@csrf
    <input name="title" class="field sm:col-span-2" placeholder="Title (e.g. Pay securely)" aria-label="Title" required>
    <input name="text" class="field sm:col-span-2" placeholder="Short text" aria-label="Text"><input type="hidden" name="is_active" value="1"><button class="btn-red">Add</button></form>
<div class="mt-4 max-w-3xl divide-y divide-line rounded-lg border border-line bg-white text-sm">@forelse($benefits as $b)
    <div class="p-3"><form method="post" action="{{ route('admin.benefits.update', $b) }}" class="grid items-center gap-2 sm:grid-cols-6">@csrf @method('PUT')
        <input name="title" value="{{ $b->title }}" class="field sm:col-span-2" aria-label="Title"><input name="text" value="{{ $b->text }}" class="field sm:col-span-2" aria-label="Text">
        <input name="sort_order" type="number" min="0" value="{{ $b->sort_order }}" class="field" aria-label="Order">
        <label class="flex items-center gap-2"><input type="checkbox" name="is_active" value="1" @checked($b->is_active)> Show</label><button class="btn-line">Save</button></form>
        <form method="post" action="{{ route('admin.benefits.destroy', $b) }}" class="mt-1" onsubmit="return confirm('Delete?')">@csrf @method('DELETE')<button class="text-xs text-brand-red underline">Delete</button></form></div>
@empty<p class="p-5 text-muted">None yet.</p>@endforelse</div>
@endsection
