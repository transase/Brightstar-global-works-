@extends('layouts.admin')
@section('title', 'Collections')
@section('content')
@php $v = fn ($k, $d = '') => old($k, $collection->{$k} ?? $d); $sel = old('products', $collection->exists ? $collection->products->pluck('id')->all() : []); @endphp
<h1 class="text-3xl">Collections &amp; styles</h1>
<p class="mt-1 text-sm text-muted">Curated groups of products that cut across categories (e.g. “Scandinavian”, “Executive Office”, “Ramadan Sale”).</p>
<form method="post" enctype="multipart/form-data" action="{{ $collection->exists ? route('admin.collections.update', $collection) : route('admin.collections.store') }}" class="mt-6 max-w-3xl space-y-3 rounded-lg border border-line bg-white p-5 text-sm">
    @csrf @if($collection->exists) @method('PUT') @endif
    <div class="grid gap-3 sm:grid-cols-2"><input name="name" value="{{ $v('name') }}" class="field" placeholder="Name" aria-label="Name" required><input name="slug" value="{{ $v('slug') }}" class="field" placeholder="slug (auto)" aria-label="Slug"></div>
    <textarea name="description" rows="3" class="field" placeholder="Description" aria-label="Description">{{ $v('description') }}</textarea>
    <label>Image<input type="file" name="image" accept="image/*" class="field"></label>
    <label>Products (hold Ctrl/Cmd to select several)<select name="products[]" multiple size="8" class="field">@foreach($products as $p)<option value="{{ $p->id }}" @selected(in_array($p->id, $sel))>{{ $p->name }} ({{ $p->sku }})</option>@endforeach</select></label>
    <div class="grid gap-3 sm:grid-cols-2"><input name="seo_title" value="{{ $v('seo_title') }}" class="field" placeholder="SEO title" aria-label="SEO title"><input type="number" min="0" name="sort_order" value="{{ $v('sort_order', 0) }}" class="field" placeholder="Order" aria-label="Order"></div>
    <label class="flex items-center gap-2"><input type="checkbox" name="is_active" value="1" @checked($v('is_active', true))> Visible</label>
    <label class="flex items-center gap-2"><input type="checkbox" name="is_featured" value="1" @checked($v('is_featured', false))> Featured (shown on the homepage)</label>
    <button class="btn-red">Save collection</button></form>
<div class="mt-6 max-w-3xl divide-y divide-line rounded-lg border border-line bg-white text-sm">@forelse($collections as $c)
    <div class="flex items-center justify-between gap-3 p-3"><div><strong>{{ $c->name }}</strong> <span class="text-muted">/{{ $c->slug }} · {{ $c->products_count }} products · {{ $c->is_active ? 'visible' : 'hidden' }}</span></div>
        <div class="flex gap-3"><a class="underline" href="{{ route('admin.collections.edit', $c) }}">Edit</a>
        <form method="post" action="{{ route('admin.collections.destroy', $c) }}" onsubmit="return confirm('Delete?')">@csrf @method('DELETE')<button class="text-brand-red underline">Delete</button></form></div></div>@empty<p class="p-5 text-muted">No collections yet.</p>@endforelse</div>
@endsection
