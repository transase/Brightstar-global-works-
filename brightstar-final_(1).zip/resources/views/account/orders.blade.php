@extends('layouts.store')
@section('title', 'My orders | Brightstar Global Furniture')
@section('content')
@php $m = fn ($v, $c) => \App\Services\Money::format($v, $c); @endphp
<div class="mx-auto max-w-4xl px-4 py-10"><h1 class="text-3xl">My orders</h1>
@forelse($orders as $o)
    <a href="{{ route('account.order', $o->number) }}" class="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line p-4 text-sm hover:border-ink">
        <span class="font-medium">{{ $o->number }}</span><span class="text-muted">{{ $o->created_at->format('d M Y') }}</span>
        <span>{{ str_replace('_', ' ', $o->fulfilment_status) }} · {{ $o->payment_status }}</span><span class="font-semibold">{{ $m($o->total, $o->currency) }}</span></a>
@empty<p class="mt-4 text-muted">You have not placed an order yet. <a class="underline" href="{{ route('shop') }}">Browse furniture</a>.</p>@endforelse
<div class="mt-6">{{ $orders->links() }}</div>
<form method="post" action="{{ route('logout') }}" class="mt-8">@csrf<button class="text-sm text-muted underline">Log out</button></form></div>
@endsection
