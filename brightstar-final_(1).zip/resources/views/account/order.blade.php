@extends('layouts.store')
@section('title', 'Order '.$order->number)
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v, $order->currency); @endphp
<div class="mx-auto max-w-3xl px-4 py-10"><a href="{{ route('account.orders') }}" class="text-sm text-muted">← My orders</a>
<h1 class="mt-2 text-3xl">Order {{ $order->number }}</h1>
<p class="mt-2 text-sm text-muted">Placed {{ $order->created_at->format('d M Y') }} · {{ str_replace('_', ' ', $order->fulfilment_status) }} · payment {{ $order->payment_status }}</p>
<ul class="mt-6 divide-y divide-line text-sm">@foreach($order->items as $i)<li class="flex justify-between py-3"><span>{{ $i->name }}@if($i->variant_label) ({{ $i->variant_label }})@endif × {{ $i->quantity }}</span><span>{{ $m($i->line_total) }}</span></li>@endforeach</ul>
@if($order->tax)<p class="mt-4 text-right text-sm text-muted">{{ \App\Models\Setting::get('tax_label', 'Tax') }} {{ $m($order->tax) }}</p>@endif
<p class="mt-2 text-right text-lg font-semibold">Total {{ $m($order->total) }}</p>
<form method="post" action="{{ route('account.reorder', $order->number) }}" class="mt-6">@csrf<button class="btn-red">Reorder these items</button></form></div>
@endsection
