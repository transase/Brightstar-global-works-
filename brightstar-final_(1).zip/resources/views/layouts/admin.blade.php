@php
    $role = auth()->user()->role;
    $links = [
        ['Dashboard', 'admin.dashboard', ['manager', 'staff']], ['Orders', 'admin.orders.index', ['manager', 'staff']],
        ['Products', 'admin.products.index', ['manager']], ['Categories', 'admin.categories.index', ['manager']],
        ['Coupons', 'admin.coupons.index', ['manager']], ['Reviews', 'admin.reviews.index', ['manager']],
        ['Collections', 'admin.collections.index', ['manager']], ['Why shop with us', 'admin.benefits.index', ['manager']], ['Newsletter', 'admin.newsletter.index', ['manager']], ['Ideas', 'admin.articles.index', ['manager']], ['Pages', 'admin.pages.index', ['manager']], ['Navigation', 'admin.nav.index', ['manager']], ['Slides & banners', 'admin.slides.index', ['manager']], ['Payments', 'admin.payments.index', ['manager']], ['Delivery areas', 'admin.zones.index', ['manager']], ['Users', 'admin.users.index', []], ['Settings', 'admin.settings.edit', []],
    ];
@endphp
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>@yield('title', 'Admin') | Brightstar</title>
<link rel="icon" href="{{ \App\Support\Branding::favicon() }}">
<link href="https://fonts.bunny.net/css?family=newsreader:500,600|inter-tight:400,500,600" rel="stylesheet">
@vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>{!! \App\Support\Branding::css() !!}</style>
</head>
<body class="bg-surface" x-data="{ nav: false }">
<div class="lg:grid lg:grid-cols-[220px_1fr]">
    <aside class="border-b border-line bg-white lg:min-h-screen lg:border-b-0 lg:border-r">
        <div class="flex items-center justify-between p-4">
            <a href="{{ route('admin.dashboard') }}"><img src="{{ \App\Support\Branding::logo() }}" alt="Brightstar admin" class="h-9 w-auto"></a>
            <button class="lg:hidden" @click="nav = !nav" aria-label="Toggle menu">Menu</button>
        </div>
        <nav :class="nav ? '' : 'hidden lg:block'" class="px-2 pb-4 text-sm" aria-label="Admin">
            @foreach($links as [$label, $route, $roles])
                @if($role === 'admin' || in_array($role, $roles))
                    <a href="{{ route($route) }}" class="block rounded px-3 py-2 {{ request()->routeIs($route, Str::beforeLast($route, '.').'.*') ? 'bg-brand-red/10 font-semibold text-brand-red' : 'hover:bg-surface' }}">{{ $label }}</a>
                @endif
            @endforeach
            <a href="{{ route('home') }}" class="mt-4 block px-3 py-2 text-muted" target="_blank">View store</a>
            <form method="post" action="{{ route('logout') }}">@csrf<button class="px-3 py-2 text-muted">Log out</button></form>
        </nav>
    </aside>
    <main class="min-w-0 p-4 md:p-8">
        @if(session('status'))<div class="mb-4 rounded bg-brand-green/10 px-4 py-3 text-sm text-brand-green" role="status">{{ session('status') }}</div>@endif
        @if(session('error'))<div class="mb-4 rounded bg-brand-red/10 px-4 py-3 text-sm text-brand-red" role="alert">{{ session('error') }}</div>@endif
        @if($errors->any())<div class="mb-4 rounded bg-brand-red/10 px-4 py-3 text-sm text-brand-red" role="alert"><ul class="list-disc pl-5">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>@endif
        @yield('content')
    </main>
</div>
</body></html>
