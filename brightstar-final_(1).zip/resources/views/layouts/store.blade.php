@php
    $store = \App\Models\Setting::get('store_name', 'Brightstar Global Furniture');
    $wa = app(\App\Services\WhatsAppService::class);
    $cartCount = app(\App\Services\CartService::class)->count();
    $nav = [
        ['Home', route('home')], ['Shop Furniture', route('shop')], ['Living Room', route('category.show', 'living-room')],
        ['Bedroom', route('category.show', 'bedroom')], ['Dining Room', route('category.show', 'dining-room')],
        ['Office Furniture', route('category.show', 'office-furniture')], ['Outdoor Furniture', route('category.show', 'outdoor-furniture')],
        ['Collections', route('collections.index')], ['New Arrivals', route('shop', ['sort' => 'newest'])],
        ['Best Sellers', route('shop', ['sort' => 'popular'])], ['Offers', route('shop', ['on_sale' => 1])],
        ['About Us', route('page.about')], ['Contact Us', route('page.contact')],
    ];
    $tree = \App\Models\NavItem::tree();
    if ($tree->isNotEmpty()) $nav = $tree->map(fn ($i) => [$i->label, $i->url])->all();
    $announcement = \App\Models\Setting::get('announcement_enabled', '1') ? \App\Models\Setting::get('announcement_text') : null;
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', $store)</title>
    <meta name="description" content="@yield('description', 'Quality furniture for every room, delivered to your door.')">
    <link rel="icon" href="{{ \App\Support\Branding::favicon() }}">
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=newsreader:500,600|inter-tight:400,500,600" rel="stylesheet">
    <link rel="canonical" href="{{ url()->current() }}">
    <meta property="og:title" content="@yield('title', $store)">
    <meta property="og:description" content="@yield('description', 'Quality furniture for every room.')">
    <meta property="og:image" content="@yield('og_image', \App\Support\Branding::logo())">
    @stack('head')
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>{!! \App\Support\Branding::css() !!}</style>
</head>
<body x-data="{ menu: false, search: false, quick: false, quickHtml: '',
    openQuick(url) { this.quickHtml = '<p class=\'p-6 text-sm\'>Loading…</p>'; this.quick = true; fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } }).then(r => r.ok ? r.text() : Promise.reject()).then(h => this.quickHtml = h).catch(() => this.quickHtml = '<p class=\'p-6 text-sm\'>Sorry, this product could not be loaded.</p>'); } }"
      @keydown.escape.window="quick = false">
<a href="#main" class="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-white focus:px-3 focus:py-2">Skip to content</a>
@if($announcement)
    <div class="bg-ink px-4 py-2 text-center text-sm text-white">{{ $announcement }}</div>
@endif

<header class="sticky top-0 z-40 border-b border-line bg-white/95 backdrop-blur">
    <div class="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3">
        <button class="lg:hidden" @click="menu = !menu" :aria-expanded="menu" aria-label="Open menu">
            <svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
        <a href="{{ route('home') }}" class="shrink-0"><img src="{{ \App\Support\Branding::logo() }}" alt="{{ $store }}" class="h-10 w-auto"></a>

        <form action="{{ route('shop') }}" class="mx-auto hidden max-w-md flex-1 md:block" role="search">
            <input name="q" value="{{ request('q') }}" class="field" placeholder="Search sofas, beds, desks or SKU" aria-label="Search products">
        </form>

        <nav class="ml-auto flex items-center gap-3 text-sm" aria-label="Account and cart">
            <button class="md:hidden" @click="search = !search" :aria-expanded="search" aria-label="Search"><svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg></button>
            @if($waShortcut = $wa->link($wa->generalMessage()))<a href="{{ $waShortcut }}" target="_blank" rel="noopener" class="hidden text-brand-green sm:block" aria-label="Chat with us on WhatsApp"><svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zM2.25 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25-4.03 8.25-9 8.25a9.76 9.76 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 2.25 14.265 2.25 12z"/></svg></a>@endif
            <a href="{{ route('wishlist') }}" class="hidden sm:block" aria-label="Wishlist"><svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"/></svg></a>
            <a href="{{ auth()->check() ? route('dashboard') : url('/login') }}" aria-label="{{ auth()->check() ? 'My account' : 'Log in' }}"><svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0"/></svg></a>
            <a href="{{ route('cart.show') }}" class="relative" aria-label="Cart, {{ $cartCount }} items"><svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"/></svg>
                @if($cartCount)<span class="absolute -right-2 -top-2 rounded-full bg-brand-red px-1.5 text-xs font-semibold text-white">{{ $cartCount }}</span>@endif</a>
        </nav>
    </div>
    <div x-show="search" x-cloak class="border-t border-line p-3 md:hidden">
        <form action="{{ route('shop') }}" role="search"><input name="q" class="field" placeholder="Search furniture" aria-label="Search products"></form>
    </div>
    <nav class="hidden border-t border-line lg:block" aria-label="Main">
        <ul class="mx-auto flex max-w-7xl gap-6 px-4 py-2.5 text-sm font-medium">
        @if($tree->isNotEmpty())
            @foreach($tree as $top)
                <li class="relative" x-data="{ open: false }" @mouseenter="open = true" @mouseleave="open = false" @keydown.escape="open = false">
                    <a href="{{ $top->url }}" class="hover:text-brand-red">{{ $top->label }}</a>
                    @if($top->children->isNotEmpty())
                    <div x-show="open" x-cloak class="absolute left-0 top-full z-50 w-[min(52rem,90vw)] rounded-b-lg border border-line bg-white p-5 shadow-lg">
                        <ul class="grid grid-cols-3 gap-4">
                        @foreach($top->children as $c)
                            <li><a href="{{ $c->url }}" class="block hover:text-brand-red">
                                @if($c->imageUrl())<img src="{{ $c->imageUrl() }}" alt="" loading="lazy" class="mb-2 aspect-[4/3] w-full rounded object-cover">@endif
                                <span class="{{ $c->is_featured ? 'font-semibold' : '' }}">{{ $c->label }}</span></a></li>
                        @endforeach
                        </ul></div>
                    @endif
                </li>
            @endforeach
        @else
            @foreach($nav as [$label, $href])<li><a href="{{ $href }}" class="hover:text-brand-red">{{ $label }}</a></li>@endforeach
        @endif
        </ul>
    </nav>
    <nav x-show="menu" x-cloak class="border-t border-line lg:hidden" aria-label="Mobile">
        <ul class="divide-y divide-line px-4">
        @if($tree->isNotEmpty())
            @foreach($tree as $top)
                <li><a href="{{ $top->url }}" class="block py-3 text-sm font-medium">{{ $top->label }}</a>
                @foreach($top->children as $c)<a href="{{ $c->url }}" class="block pb-2 pl-4 text-sm text-muted">{{ $c->label }}</a>@endforeach</li>
            @endforeach
        @else
            @foreach($nav as [$label, $href])<li><a href="{{ $href }}" class="block py-3 text-sm font-medium">{{ $label }}</a></li>@endforeach
        @endif
        </ul>
    </nav>
</header>

<main id="main" tabindex="-1">
    @if(session('status'))<div class="mx-auto mt-4 max-w-7xl rounded-md bg-brand-green/10 px-4 py-3 text-sm text-brand-green" role="status">{{ session('status') }}</div>@endif
    @if(session('error'))<div class="mx-auto mt-4 max-w-7xl rounded-md bg-brand-red/10 px-4 py-3 text-sm text-brand-red" role="alert">{{ session('error') }}</div>@endif
    @yield('content')
</main>

<footer class="mt-24 border-t border-line bg-surface">
    <div class="mx-auto grid max-w-7xl gap-8 px-4 py-12 md:grid-cols-2 lg:grid-cols-4">
        <div>
            <img src="{{ \App\Support\Branding::logo() }}" alt="{{ $store }}" class="h-12 w-auto">
            @if($about = \App\Models\Setting::get('footer_about'))<p class="mt-4 text-sm text-muted">{{ $about }}</p>@endif
            <p class="mt-2 text-sm text-muted">{{ \App\Models\Setting::get('store_address') }}</p>
            <p class="text-sm text-muted">{{ \App\Models\Setting::get('store_phone') }} {{ \App\Models\Setting::get('store_email') }}</p>
            @if($link = $wa->link($wa->generalMessage()))<a href="{{ $link }}" class="btn-whatsapp mt-4" target="_blank" rel="noopener">Chat on WhatsApp</a>@endif
        </div>
        <div class="text-sm">
            <h2 class="font-display text-lg">Shop</h2>
            <ul class="mt-3 space-y-2 text-muted">@foreach($nav as [$label, $href])<li><a href="{{ $href }}">{{ $label }}</a></li>@endforeach
                @foreach(\App\Models\Category::where('is_active', true)->whereNull('parent_id')->orderBy('sort_order')->take(8)->get(['slug', 'name']) as $fc)<li><a href="{{ route('category.show', $fc->slug) }}">{{ $fc->name }}</a></li>@endforeach
                @foreach(\App\Models\Page::where('is_published', true)->whereNotIn('slug', ['about', 'contact'])->orderBy('title')->get(['slug', 'title']) as $pg)<li><a href="{{ route('page.show', $pg->slug) }}">{{ $pg->title }}</a></li>@endforeach</ul>
        </div>
        <div class="text-sm">
            <h2 class="font-display text-lg">Follow &amp; pay</h2>
            <ul class="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-muted">
                @foreach(['facebook_url' => 'Facebook', 'instagram_url' => 'Instagram', 'tiktok_url' => 'TikTok'] as $k => $label)@if($u = \App\Models\Setting::get($k))<li><a href="{{ $u }}" target="_blank" rel="noopener">{{ $label }}</a></li>@endif @endforeach
            </ul>
            @php $methods = array_keys(app(\App\Services\PaymentService::class)->enabledGateways()); @endphp
            @if($methods || \App\Models\Setting::get('cod_enabled') || \App\Models\Setting::get('bank_transfer_enabled'))
            <p class="mt-4 text-xs text-muted">We accept</p>
            <ul class="mt-1 flex flex-wrap gap-2 text-xs">
                @foreach($methods as $m)<li class="rounded border border-line bg-white px-2 py-1">{{ ucfirst($m) }}</li>@endforeach
                @if(\App\Models\Setting::get('bank_transfer_enabled'))<li class="rounded border border-line bg-white px-2 py-1">Bank transfer</li>@endif
                @if(\App\Models\Setting::get('cod_enabled'))<li class="rounded border border-line bg-white px-2 py-1">Cash on delivery</li>@endif
            </ul>@endif
        </div>
        <div>
            <h2 class="font-display text-lg">Stay in the loop</h2>
            <form method="post" action="{{ route('newsletter') }}" class="mt-3 flex gap-2">@csrf
                <input type="email" name="email" required class="field" placeholder="Email address" aria-label="Email address">
                <button class="btn-red">Subscribe</button>
            </form>
            <p class="mt-2 text-xs text-muted">By subscribing you agree to receive occasional emails from us. Unsubscribe any time.</p>
        </div>
    </div>
    <p class="border-t border-line py-4 text-center text-xs text-muted">© {{ date('Y') }} {{ $store }}</p>
</footer>

<div x-show="quick" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-label="Quick view" @click.self="quick = false">
    <div class="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-lg bg-white p-6 shadow-xl">
        <button type="button" class="absolute right-3 top-3 text-2xl leading-none" @click="quick = false" aria-label="Close quick view">×</button>
        <div x-html="quickHtml"></div>
    </div>
</div>

@if(\App\Models\Setting::get('wa_floating', '1') && ($link = $wa->link($wa->generalMessage())))
    <a href="{{ $link }}" target="_blank" rel="noopener" aria-label="Chat on WhatsApp"
       class="fixed bottom-5 right-5 z-50 rounded-full bg-brand-green px-5 py-3 text-sm font-semibold text-white shadow-lg">WhatsApp</a>
@endif
</body>
</html>
