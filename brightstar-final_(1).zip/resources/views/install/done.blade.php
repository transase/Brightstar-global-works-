@extends('install.layout')
@section('title', 'Installed')
@section('content')
<h1>✔ Installation complete</h1>
<div class="card">
<p>Your store is ready. Sign in as <strong>{{ $adminEmail }}</strong>.</p>
<p><a href="{{ $url }}/login"><strong>Log in to the admin</strong></a> → then open <strong>Admin → Settings</strong> to add your logo, WhatsApp number, payment keys and email settings.</p>
<p class="hint">The installer has locked itself and can no longer be opened. {{ $mediaDisk === 'uploads' ? 'Your host blocks symbolic links, so images are saved in public/uploads.' : '' }}</p>
<p class="hint">Next: add the cron job described in CPANEL.md so scheduled tasks (cleanup of abandoned orders) run.</p>
</div>
@endsection
