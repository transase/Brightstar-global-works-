@extends('install.layout')
@section('title', 'Install')
@section('content')
<h1>Install Brightstar Global Furniture</h1>
<p class="hint">This takes about two minutes. You need the database details from cPanel → MySQL Databases.</p>
@if(session('error'))<div class="err" role="alert">{{ session('error') }}</div>@endif
@if($errors->any())<div class="err" role="alert"><ul style="margin:0;padding-left:18px">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>@endif

<div class="card"><h2 style="margin-top:0">1. Server check</h2>
<ul class="checks">@foreach($checks as $c)
    <li><span class="{{ $c['ok'] ? 'ok' : ($c['required'] ? 'bad' : 'warn') }}">{{ $c['ok'] ? '✔' : ($c['required'] ? '✘' : '!') }}</span> {{ $c['label'] }}@if(! $c['ok'])<br><span class="hint">{{ $c['hint'] }}</span>@endif</li>@endforeach</ul>
@if($blocked)<p class="bad"><strong>Fix the red items above, then refresh this page.</strong></p>@endif</div>

<form method="post" action="{{ route('install.store') }}" class="card" autocomplete="off">@csrf
<h2 style="margin-top:0">2. Database</h2>
<div class="row"><div><label for="db_host">Host</label><input id="db_host" name="db_host" value="{{ old('db_host', 'localhost') }}" required></div><div><label for="db_port">Port</label><input id="db_port" name="db_port" type="number" value="{{ old('db_port', 3306) }}" required></div></div>
<label for="db_name">Database name</label><input id="db_name" name="db_name" value="{{ old('db_name') }}" required>
<div class="row"><div><label for="db_user">Database user</label><input id="db_user" name="db_user" value="{{ old('db_user') }}" required></div><div><label for="db_pass">Database password</label><input id="db_pass" name="db_pass" type="password" autocomplete="new-password"></div></div>

<h2>3. Your store and admin account</h2>
<label for="store_name">Store name</label><input id="store_name" name="store_name" value="{{ old('store_name', 'Brightstar Global Furniture') }}" required>
<label for="app_url">Website address</label><input id="app_url" name="app_url" type="url" value="{{ old('app_url', $appUrl) }}" required>
<div class="row"><div><label for="admin_name">Your name</label><input id="admin_name" name="admin_name" value="{{ old('admin_name') }}" required></div><div><label for="admin_email">Admin email</label><input id="admin_email" name="admin_email" type="email" value="{{ old('admin_email') }}" required></div></div>
<div class="row"><div><label for="admin_password">Admin password (10+ characters)</label><input id="admin_password" name="admin_password" type="password" minlength="10" autocomplete="new-password" required></div><div><label for="admin_password_confirmation">Repeat password</label><input id="admin_password_confirmation" name="admin_password_confirmation" type="password" minlength="10" autocomplete="new-password" required></div></div>

@if($needsCode)<h2>4. Install code</h2><p class="hint">In cPanel File Manager open <code>brightstar/storage/app/INSTALL-CODE.txt</code> and copy the code. This stops strangers from installing your site first.</p>
<label for="install_code">Install code</label><input id="install_code" name="install_code" value="{{ old('install_code') }}" required>@endif

<button @disabled($blocked) onclick="this.form.submit(); this.disabled = true; this.textContent = 'Installing… please wait';">Install now</button>
</form>
@endsection
