<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>@yield('title', 'Install') | Brightstar</title>
<style>
 :root{--red:#E51B23;--green:#078B2B;--ink:#202020;--muted:#6B7280;--line:#E5E7EB;--bg:#F8F9FA}
 *{box-sizing:border-box}body{margin:0;font-family:system-ui,Segoe UI,Arial,sans-serif;color:var(--ink);background:var(--bg);line-height:1.5}
 main{max-width:720px;margin:0 auto;padding:24px 16px 64px}h1{font-family:Georgia,serif;font-size:1.9rem;margin:.2em 0}
 .card{background:#fff;border:1px solid var(--line);border-radius:10px;padding:20px;margin-top:16px}
 label{display:block;font-weight:600;font-size:.9rem;margin:12px 0 4px}input{width:100%;padding:10px;border:1px solid var(--line);border-radius:6px;font-size:1rem}
 input:focus{outline:2px solid var(--red);outline-offset:1px}.row{display:grid;gap:12px;grid-template-columns:1fr 1fr}@media(max-width:560px){.row{grid-template-columns:1fr}}
 button{background:var(--red);color:#fff;border:0;border-radius:6px;padding:12px 20px;font-size:1rem;font-weight:600;cursor:pointer;margin-top:18px}button:disabled{opacity:.5;cursor:not-allowed}
 .ok{color:var(--green)}.bad{color:var(--red)}.warn{color:#9a6700}.hint{color:var(--muted);font-size:.85rem}
 .err{background:#fdecec;border:1px solid #f5b5b8;color:#8a1016;padding:12px;border-radius:6px;margin-top:16px}ul.checks{list-style:none;padding:0;margin:0}ul.checks li{padding:6px 0;border-bottom:1px solid var(--line)}
</style></head><body><main>@yield('content')</main></body></html>
