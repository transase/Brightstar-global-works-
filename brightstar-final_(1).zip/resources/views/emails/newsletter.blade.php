<!DOCTYPE html><html lang="en"><body style="font-family:Arial,sans-serif;color:#202020;max-width:600px;margin:auto;padding:16px">
<img src="{{ \App\Support\Branding::logo() }}" alt="{{ \App\Models\Setting::get('store_name', 'Brightstar Global Furniture') }}" height="48">
<div style="margin-top:16px;line-height:1.6">{!! nl2br(e($body)) !!}</div>
<p style="color:#6B7280;font-size:12px;margin-top:32px">{{ \App\Models\Setting::get('store_name', 'Brightstar Global Furniture') }} · {{ \App\Models\Setting::get('store_address') }}<br>
You are receiving this because you subscribed on our website. <a href="{{ $unsubscribeUrl }}">Unsubscribe</a></p></body></html>
