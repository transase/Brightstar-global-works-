@php $m = fn ($v) => \App\Services\Money::format($v, $order->currency); $store = \App\Models\Setting::get('store_name', 'Brightstar Global Furniture'); @endphp
<!DOCTYPE html><html lang="en"><body style="font-family:Arial,sans-serif;color:#202020;max-width:600px;margin:auto;padding:16px">
<img src="{{ \App\Support\Branding::logo() }}" alt="{{ $store }}" height="48">
@if($kind === 'admin')
    <h2>New order {{ $order->number }}</h2>
    <p>{{ $order->first_name }} {{ $order->last_name }} · {{ $order->phone }} · {{ $order->email }}<br>Method: {{ $order->payment_method }} · Source: {{ $order->source }}</p>
@elseif($kind === 'status')
    <h2>Your order is {{ str_replace('_', ' ', $status) }}</h2>
    <p>Hello {{ $order->first_name }}, the status of order <strong>{{ $order->number }}</strong> is now <strong>{{ str_replace('_', ' ', $status) }}</strong>.</p>
@elseif($kind === 'paid')
    <h2>Payment confirmed</h2><p>Hello {{ $order->first_name }}, thank you. We have confirmed your payment for order <strong>{{ $order->number }}</strong>.</p>
@else
    <h2>We received your order</h2>
    <p>Hello {{ $order->first_name }}, thank you for ordering. Order <strong>{{ $order->number }}</strong> is awaiting confirmation by our team; we will contact you shortly.</p>
@endif
<table width="100%" cellpadding="6" style="border-collapse:collapse;font-size:14px">
@foreach($order->items as $i)<tr style="border-bottom:1px solid #E5E7EB"><td>{{ $i->name }}@if($i->variant_label) ({{ $i->variant_label }})@endif × {{ $i->quantity }}</td><td align="right">{{ $m($i->line_total) }}</td></tr>@endforeach
<tr><td align="right"><strong>Total</strong></td><td align="right"><strong>{{ $m($order->total) }}</strong></td></tr></table>
@if($kind === 'admin')<p><a href="{{ route('admin.orders.show', $order) }}">Open in admin</a></p>@endif
<p style="color:#6B7280;font-size:12px">{{ $store }} · {{ \App\Models\Setting::get('store_phone') }}</p></body></html>
