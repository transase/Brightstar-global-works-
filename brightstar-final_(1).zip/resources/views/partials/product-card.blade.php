@php
    $list = ($layout ?? 'grid') === 'list';
    $hasOptions = $product->variants->where('is_active', true)->isNotEmpty();
    $waOn = \App\Services\WhatsAppService::normalisePhone((string) \App\Models\Setting::get('whatsapp_phone', '')) !== null;
    $canBuy = ! $product->enquiry_only && ! $hasOptions && $product->canBePurchased(1);
@endphp
<article class="group flex {{ $list ? 'flex-row gap-4' : 'flex-col' }}">
    <a href="{{ route('product.show', $product) }}" class="relative block aspect-[4/3] overflow-hidden rounded-lg bg-surface {{ $list ? 'w-40 shrink-0 sm:w-56' : '' }}">
        <img src="{{ $product->cardImageUrl() }}" alt="{{ $product->name }}" loading="lazy" class="h-full w-full object-cover">
        @if($product->isOnSale())<span class="absolute left-3 top-3 rounded bg-brand-yellow px-2 py-1 text-xs font-semibold text-ink">-{{ $product->discountPercent() }}%</span>@endif
    </a>
    <div class="{{ $list ? 'flex-1' : '' }}">
        <h3 class="mt-3 text-lg leading-snug {{ $list ? 'mt-0' : '' }}"><a href="{{ route('product.show', $product) }}">{{ $product->name }}</a></h3>
        <p class="mt-1 text-sm text-muted">{{ $product->stockLabel() }}</p>
        <p class="mt-1 font-semibold">
            @if($product->enquiry_only) Price on request
            @else {{ $hasOptions ? 'From ' : '' }}{{ \App\Services\Money::format($product->currentPrice()) }}
                @if($product->isOnSale())<s class="ml-2 text-sm font-normal text-muted">{{ \App\Services\Money::format($product->price) }}</s>@endif
            @endif
        </p>
        <div class="mt-2 flex flex-wrap items-center gap-x-3 gap-y-2 text-xs">
            @if($canBuy)
                <form method="post" action="{{ route('cart.add', $product) }}">@csrf<input type="hidden" name="quantity" value="1"><button class="rounded-md bg-brand-red px-3 py-2 font-semibold text-white hover:bg-brand-red-dark">Add to cart</button></form>
            @elseif(! $product->enquiry_only)
                <a href="{{ route('product.show', $product) }}" class="rounded-md border border-line px-3 py-2 font-semibold hover:border-ink">{{ $hasOptions ? 'Choose options' : 'View' }}</a>
            @endif
            @if($waOn)<a href="{{ route('product.whatsapp', $product) }}" target="_blank" rel="noopener" class="font-semibold text-brand-green underline">{{ $product->enquiry_only ? 'Enquire on WhatsApp' : 'Order on WhatsApp' }}</a>@endif
            <button type="button" class="underline" @click="openQuick('{{ route('product.quick', $product) }}')">Quick view</button>
            <form method="post" action="{{ route('wishlist.toggle', $product) }}">@csrf<button class="text-muted underline" aria-label="Save {{ $product->name }} to wishlist">♡ Wishlist</button></form>
        </div>
    </div>
</article>
