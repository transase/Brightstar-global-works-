{{-- Overrides Breeze's default logo so login, register and password-reset pages show the Brightstar logo.
     Classes passed by Breeze (fixed square sizes) are ignored so the logo keeps its aspect ratio. --}}
<img src="{{ \App\Support\Branding::logo() }}" alt="{{ \App\Models\Setting::get('store_name', 'Brightstar Global Furniture') }}" {{ $attributes->except('class') }} class="h-16 w-auto max-w-[16rem] object-contain">
