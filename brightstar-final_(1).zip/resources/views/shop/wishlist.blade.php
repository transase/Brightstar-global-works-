@extends('layouts.store')
@section('title', 'Your wishlist | Brightstar Global Furniture')
@section('content')
<div class="mx-auto max-w-7xl px-4 py-10"><h1 class="text-3xl">Your wishlist</h1>
@if($products->isEmpty())<p class="mt-4 text-muted">Nothing saved yet. <a class="underline" href="{{ route('shop') }}">Browse furniture</a>.</p>
@else<div class="mt-6 grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-4">@foreach($products as $product) @include('partials.product-card', ['product' => $product]) @endforeach</div>@endif</div>
@endsection
