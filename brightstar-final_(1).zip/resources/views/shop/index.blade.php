@extends('layouts.store')
@section('title', ($category?->seo_title ?: ($category?->name ?? 'Shop Furniture')).' | Brightstar Global Furniture')
@section('content')
@php
    $labels = ['q' => 'Search', 'category' => 'Category', 'min_price' => 'Min', 'max_price' => 'Max', 'material' => 'Material', 'colour' => 'Colour', 'size' => 'Size', 'collection' => 'Collection', 'in_stock' => 'In stock', 'on_sale' => 'On sale'];
    $chips = collect($labels)->filter(fn ($l, $k) => request()->filled($k) && (! in_array($k, ['in_stock', 'on_sale']) || request()->boolean($k)))->map(fn ($l, $k) => [
        'label' => in_array($k, ['in_stock', 'on_sale']) ? $l : $l.': '.request($k), 'url' => request()->fullUrlWithoutQuery([$k, 'page']),
    ]);
@endphp
<div class="mx-auto max-w-7xl px-4 py-10">
    <h1 class="text-3xl md:text-4xl">{{ $category?->name ?? 'Shop Furniture' }}</h1>
    <div class="mt-1 flex flex-wrap items-center justify-between gap-2 text-sm text-muted">
        <p>{{ $products->total() }} {{ \Illuminate\Support\Str::plural('product', $products->total()) }}</p>
        <div class="flex gap-3" role="group" aria-label="Layout">
            <a href="{{ request()->fullUrlWithQuery(['view' => 'grid']) }}" class="{{ $view === 'grid' ? 'font-semibold text-ink' : '' }}" aria-current="{{ $view === 'grid' ? 'true' : 'false' }}">Grid</a>
            <a href="{{ request()->fullUrlWithQuery(['view' => 'list']) }}" class="{{ $view === 'list' ? 'font-semibold text-ink' : '' }}" aria-current="{{ $view === 'list' ? 'true' : 'false' }}">List</a>
        </div>
    </div>

    @if($chips->isNotEmpty())
    <div class="mt-3 flex flex-wrap items-center gap-2 text-xs" aria-label="Active filters">
        <span class="text-muted">Active filters:</span>
        @foreach($chips as $chip)<a href="{{ $chip['url'] }}" class="rounded-full border border-line bg-surface px-3 py-1 hover:border-ink" aria-label="Remove filter {{ $chip['label'] }}">{{ $chip['label'] }} ×</a>@endforeach
        <a href="{{ url()->current() }}" class="underline">Clear all</a>
    </div>@endif

    <div class="mt-8 grid gap-8 lg:grid-cols-[240px_1fr]">
        <form method="get" class="space-y-5 text-sm">
            <input type="hidden" name="view" value="{{ $view }}">
            <div><label class="label" for="q">Search</label><input id="q" name="q" value="{{ request('q') }}" class="field" placeholder="Name, SKU or keyword"></div>
            <div><label class="label" for="cat">Category</label>
                <select id="cat" name="category" class="field"><option value="">All</option>
                    @foreach($categories as $c)
                        <option value="{{ $c->slug }}" @selected(request('category') === $c->slug)>{{ $c->name }}</option>
                        @foreach($c->children as $ch)<option value="{{ $ch->slug }}" @selected(request('category') === $ch->slug)>&nbsp;&nbsp;{{ $ch->name }}</option>@endforeach
                    @endforeach
                </select></div>
            @if($collections->isNotEmpty())<div><label class="label" for="col">Collection</label><select id="col" name="collection" class="field"><option value="">Any</option>@foreach($collections as $c)<option value="{{ $c->slug }}" @selected(request('collection') === $c->slug)>{{ $c->name }}</option>@endforeach</select></div>@endif
            <div class="grid grid-cols-2 gap-2">
                <div><label class="label" for="min">Min price</label><input id="min" type="number" min="0" name="min_price" value="{{ request('min_price') }}" class="field"></div>
                <div><label class="label" for="max">Max price</label><input id="max" type="number" min="0" name="max_price" value="{{ request('max_price') }}" class="field"></div>
            </div>
            @if($materials->isNotEmpty())<div><label class="label" for="mat">Material</label><select id="mat" name="material" class="field"><option value="">Any</option>@foreach($materials as $m)<option @selected(request('material') === $m)>{{ $m }}</option>@endforeach</select></div>@endif
            @if($colours->isNotEmpty())<div><label class="label" for="col2">Colour</label><select id="col2" name="colour" class="field"><option value="">Any</option>@foreach($colours as $m)<option @selected(request('colour') === $m)>{{ $m }}</option>@endforeach</select></div>@endif
            @if($sizes->isNotEmpty())<div><label class="label" for="siz">Size</label><select id="siz" name="size" class="field"><option value="">Any</option>@foreach($sizes as $m)<option @selected(request('size') === $m)>{{ $m }}</option>@endforeach</select></div>@endif
            <label class="flex items-center gap-2"><input type="checkbox" name="in_stock" value="1" @checked(request()->boolean('in_stock'))> In stock only</label>
            <label class="flex items-center gap-2"><input type="checkbox" name="on_sale" value="1" @checked(request()->boolean('on_sale'))> On sale</label>
            <div><label class="label" for="sort">Sort by</label>
                <select id="sort" name="sort" class="field">
                    @foreach(['newest' => 'Newest', 'price_asc' => 'Price: low to high', 'price_desc' => 'Price: high to low', 'popular' => 'Popularity', 'name' => 'Name'] as $k => $v)
                        <option value="{{ $k }}" @selected(request('sort', 'newest') === $k)>{{ $v }}</option>
                    @endforeach
                </select></div>
            <div class="flex gap-2"><button class="btn-red flex-1">Apply</button><a href="{{ url()->current() }}" class="btn-line">Clear all</a></div>
        </form>

        <div>
            @if($products->isEmpty())
                <div class="rounded-lg border border-line p-10 text-center">
                    <p class="font-display text-xl">No furniture matches those filters</p>
                    <p class="mt-2 text-sm text-muted">Try removing a filter, checking the spelling, searching a broader word (e.g. “sofa” instead of “3-seater sofa”), or browsing a category.</p>
                    <div class="mt-5 flex flex-wrap justify-center gap-2"><a href="{{ route('shop') }}" class="btn-red">Browse all furniture</a>
                        @foreach($categories->take(4) as $c)<a href="{{ route('category.show', $c->slug) }}" class="btn-line">{{ $c->name }}</a>@endforeach</div>
                </div>
            @else
                <div class="{{ $view === 'list' ? 'space-y-6' : 'grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-3' }}">
                    @foreach($products as $product) @include('partials.product-card', ['product' => $product, 'layout' => $view]) @endforeach
                </div>
                <div class="mt-10">{{ $products->links() }}</div>
            @endif
        </div>
    </div>
</div>
@endsection
