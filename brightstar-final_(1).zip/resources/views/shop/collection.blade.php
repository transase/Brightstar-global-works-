@extends('layouts.store')
@section('title', ($collection->seo_title ?: $collection->name).' | Brightstar Global Furniture')
@section('description', $collection->seo_description ?: $collection->description)
@section('content')
<div class="mx-auto max-w-7xl px-4 py-10"><a href="{{ route('collections.index') }}" class="text-sm text-muted">← All collections</a>
<h1 class="mt-2 text-4xl">{{ $collection->name }}</h1>@if($collection->description)<p class="mt-2 max-w-2xl text-muted">{{ $collection->description }}</p>@endif
@if($products->isEmpty())<p class="mt-8 text-muted">No products in this collection right now.</p>
@else<div class="mt-8 grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-4">@foreach($products as $product) @include('partials.product-card', ['product' => $product]) @endforeach</div><div class="mt-8">{{ $products->links() }}</div>@endif</div>
@endsection
