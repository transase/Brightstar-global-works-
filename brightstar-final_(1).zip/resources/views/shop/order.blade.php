@extends('layouts.store')
@section('title', 'Order '.$order->number)
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v, $order->currency); @endphp
<div class="mx-auto max-w-3xl px-4 py-10">
    <h1 class="text-3xl">Order {{ $order->number }}</h1>
    <p class="mt-2 text-sm text-muted">Payment: <strong>{{ str_replace('_', ' ', $order->payment_status) }}</strong> · Status: <strong>{{ str_replace('_', ' ', $order->fulfilment_status) }}</strong></p>

    @if($order->payment_method === 'whatsapp' && $waLink)
        <div class="mt-6 rounded-lg border border-line p-5 text-sm">
            <p class="font-semibold">Next step: send your order on WhatsApp</p>
            <p class="mt-1 text-muted">Your order is saved as <em>pending confirmation</em>. Opening WhatsApp does not send the message for you, and the store has not accepted the order until a team member confirms it.</p>
            <a href="{{ $waLink }}" target="_blank" rel="noopener" class="btn-whatsapp mt-4"
               onclick="fetch('{{ route('order.whatsapp', $order->number) }}', {method:'POST', headers:{'X-CSRF-TOKEN':'{{ csrf_token() }}'}})">Open WhatsApp</a>
        </div>
    @endif
    @if($bankDetails)
        <div class="mt-6 rounded-lg border border-line p-5 text-sm"><p class="font-semibold">Pay by bank transfer</p>
            <p class="mt-2 whitespace-pre-line">{{ $bankDetails }}</p>
            <p class="mt-2 text-muted">Use <strong>{{ $order->number }}</strong> as the payment reference. Your order is confirmed after our team reviews the payment.</p></div>
    @endif
    @if(! empty($payGateways))
        <div class="mt-6 rounded-lg border border-line p-5 text-sm"><p class="font-semibold">{{ $order->payment_status === 'failed' ? 'Payment did not go through. Try again' : 'Pay online' }}</p>
            <div class="mt-3 flex flex-wrap gap-2">@foreach($payGateways as $g)
                <form method="post" action="{{ route('order.pay', [$order->number, $g]) }}">@csrf<button class="btn-red">Pay {{ $m($order->total) }} with {{ ucfirst($g) }}</button></form>@endforeach</div></div>
    @endif
    @if($order->payment_method !== 'whatsapp' && ($order->payment_status === 'failed' || $order->payment_status === 'unpaid'))
        <p class="mt-6 rounded bg-surface p-4 text-sm">We have your order. Once payment is confirmed or our team confirms it, you will get an email at {{ $order->email }}.</p>
    @endif

    <ul class="mt-8 divide-y divide-line text-sm">@foreach($order->items as $i)
        <li class="flex justify-between py-3"><span>{{ $i->name }}@if($i->variant_label) ({{ $i->variant_label }})@endif × {{ $i->quantity }}<br><span class="text-muted">SKU {{ $i->sku }}</span></span><span>{{ $m($i->line_total) }}</span></li>@endforeach</ul>
    @if($order->tax)<p class="mt-4 text-right text-sm text-muted">{{ \App\Models\Setting::get('tax_label', 'Tax') }} {{ $m($order->tax) }}</p>@endif
    <p class="mt-2 text-right text-lg font-semibold">Total {{ $m($order->total) }}</p>
</div>
@endsection
