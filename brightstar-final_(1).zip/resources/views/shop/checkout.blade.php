@extends('layouts.store')
@section('title', 'Checkout | Brightstar Global Furniture')
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v); $u = auth()->user(); @endphp
<div class="mx-auto max-w-6xl px-4 py-10">
    <h1 class="text-3xl">Checkout</h1>
    @php $net = max(0, $totals['subtotal'] - $totals['discount']); @endphp
    <form method="post" action="{{ route('checkout.store') }}" class="mt-8 grid gap-10 md:grid-cols-[1fr_340px]"
          x-data="{ zone: {{ $zones->first()?->id ?? 'null' }}, fees: {{ \Illuminate\Support\Js::from($zones->mapWithKeys(fn ($z) => [$z->id => $z->fee / 100])) }},
                    net: {{ $net / 100 }}, tax: {{ $totals['tax'] / 100 }}, freeFrom: {{ (int) \App\Models\Setting::get('free_delivery_min', 0) / 100 }},
                    delivery() { const f = this.fees[this.zone] ?? 0; return (this.freeFrom > 0 && this.net >= this.freeFrom) ? 0 : f; },
                    fmt(v) { return '{{ \App\Services\Money::symbol() }}' + Number(v).toLocaleString('en', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); } }">@csrf
        <div class="space-y-5">
            <div class="grid gap-4 sm:grid-cols-2">
                @foreach([['first_name','First name', $u?->name],['last_name','Last name',null],['email','Email', $u?->email],['phone','Phone number', $u?->phone]] as [$n,$l,$d])
                    <div><label class="label" for="{{ $n }}">{{ $l }}</label><input id="{{ $n }}" name="{{ $n }}" value="{{ old($n, $d) }}" class="field" required>
                        @error($n)<p class="mt-1 text-xs text-brand-red">{{ $message }}</p>@enderror</div>
                @endforeach
            </div>
            <div><label class="label" for="address">Delivery address</label><input id="address" name="address" value="{{ old('address') }}" class="field" required>@error('address')<p class="mt-1 text-xs text-brand-red">{{ $message }}</p>@enderror</div>
            <div class="grid gap-4 sm:grid-cols-2">
                @foreach([['city','City or town'],['state','State or region'],['postal_code','Postal code (optional)'],['country','Country']] as [$n,$l])
                    <div><label class="label" for="{{ $n }}">{{ $l }}</label><input id="{{ $n }}" name="{{ $n }}" value="{{ old($n, $n === 'country' ? \App\Models\Setting::get('default_country', 'Nigeria') : '') }}" class="field" @required($n !== 'postal_code')></div>
                @endforeach
            </div>
            @if($zones->isNotEmpty())
                <div><label class="label" for="zone">Delivery area</label><select id="zone" name="delivery_zone_id" class="field" x-model.number="zone">
                    @foreach($zones as $z)<option value="{{ $z->id }}">{{ $z->name }} ({{ $m($z->fee) }})</option>@endforeach</select></div>
            @endif
            <div><label class="label" for="di">Delivery instructions (optional)</label><textarea id="di" name="delivery_instructions" rows="3" class="field">{{ old('delivery_instructions') }}</textarea></div>

            <div x-data="{ same: {{ old('billing_same', '1') == '0' ? 'false' : 'true' }} }" class="rounded-md border border-line p-4">
                <input type="hidden" name="billing_same" :value="same ? 1 : 0">
                <label class="flex items-center gap-2"><input type="checkbox" x-model="same"> Billing address is the same as delivery</label>
                <div x-show="!same" x-cloak class="mt-4 grid gap-4 sm:grid-cols-2">
                    @foreach([['address', 'Billing address', 'sm:col-span-2'], ['city', 'City or town', ''], ['state', 'State or region', ''], ['postal_code', 'Postal code (optional)', ''], ['country', 'Country', '']] as [$n, $l, $cls])
                        <div class="{{ $cls }}"><label class="label" for="b_{{ $n }}">{{ $l }}</label><input id="b_{{ $n }}" name="billing[{{ $n }}]" value="{{ old('billing.'.$n) }}" class="field" :disabled="same"></div>
                    @endforeach
                </div>
            </div>

            <fieldset><legend class="label">Payment method</legend>
                @forelse($methods as $k => $label)
                    <label class="mt-2 flex items-center gap-3 rounded-md border border-line p-3 text-sm"><input type="radio" name="payment_method" value="{{ $k }}" @checked(old('payment_method', array_key_first($methods)) === $k) required> {{ $label }}</label>
                @empty <p class="text-sm text-brand-red">No payment methods are enabled yet. Please contact the store.</p> @endforelse
                @error('payment_method')<p class="mt-1 text-xs text-brand-red">{{ $message }}</p>@enderror
                <p class="mt-3 text-xs text-muted">Choosing WhatsApp saves your order as pending. Opening WhatsApp does not confirm it; our team confirms it with you in chat.</p>
            </fieldset>
        </div>
        <aside class="h-fit rounded-lg border border-line p-5 text-sm">
            <h2 class="font-display text-xl">Order summary</h2>
            <ul class="mt-3 divide-y divide-line">@foreach($totals['lines'] as $l)
                <li class="flex justify-between gap-3 py-2"><span>{{ $l['name'] }}@if($l['variant_label']) <span class="text-muted">({{ $l['variant_label'] }})</span>@endif × {{ $l['quantity'] }}<span class="block text-xs text-muted">{{ $m($l['unit_price']) }} each</span></span><span>{{ $m($l['line_total']) }}</span></li>@endforeach</ul>
            <dl class="mt-3 space-y-1">
                <div class="flex justify-between"><dt>Subtotal</dt><dd>{{ $m($totals['subtotal']) }}</dd></div>
                @if($totals['discount'])<div class="flex justify-between"><dt>Discount</dt><dd>-{{ $m($totals['discount']) }}</dd></div>@endif
                @if($totals['tax'])<div class="flex justify-between"><dt>{{ \App\Models\Setting::get('tax_label', 'Tax') }}</dt><dd>{{ $m($totals['tax']) }}</dd></div>@endif
                <div class="flex justify-between"><dt>Delivery</dt><dd x-text="delivery() === 0 ? (Object.keys(fees).length ? 'Free' : '—') : fmt(delivery())">—</dd></div>
                <div class="flex justify-between border-t border-line pt-2 text-base font-semibold"><dt>Total</dt><dd x-text="fmt(net + tax + delivery())">{{ $m($totals['total']) }}</dd></div>
            </dl>
            <button class="btn-red mt-5 w-full" @disabled(empty($methods))>Place order</button>
        </aside>
    </form>
</div>
@endsection
