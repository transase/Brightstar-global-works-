@extends('layouts.store')
@section('title', ($product->seo_title ?: $product->name).' | Brightstar Global Furniture')
@section('description', $product->seo_description ?: $product->short_description)
@section('og_image', $product->seo_image ? \App\Support\Media::url($product->seo_image) : $product->imageUrl())
@php
    $m = fn ($v) => \App\Services\Money::format($v);
    $avg = $product->averageRating();
    $reviewCount = $product->reviews()->where('status', 'approved')->count();
    $waOn = \App\Services\WhatsAppService::normalisePhone((string) \App\Models\Setting::get('whatsapp_phone', '')) !== null;
    $hours = \App\Models\Setting::get('wa_hours_notice');
    $firstVariant = $product->variants->first();
    // Gallery: main image first, then the rest.
    $gallery = collect([$product->main_image ? ['url' => $product->imageUrl(), 'alt' => $product->name] : null])
        ->merge($product->images->map(fn ($i) => ['url' => \App\Support\Media::url($i->path), 'alt' => $i->alt ?: $product->name]))->filter()->values();
    $variantImages = $product->variants->filter(fn ($v) => $v->image)->mapWithKeys(fn ($v) => [$v->id => \App\Support\Media::url($v->image)]);
    $specRows = collect([
        'Brand' => $product->brand, 'Material' => $product->material, 'Finish' => $product->finish,
        'Dimensions' => collect([$product->width, $product->depth, $product->height])->filter()->isNotEmpty() ? "{$product->width} × {$product->depth} × {$product->height} {$product->dimension_unit} (W × D × H)" : null,
        'Weight' => $product->weight ? $product->weight.' kg' : null,
        'Assembly' => $product->assembly_required ? 'Assembly required' : null, 'Warranty' => $product->warranty,
        'Estimated delivery' => $product->delivery_timeframe,
    ])->merge($product->specs ?? [])->filter();
@endphp
@push('head')
<script type="application/ld+json">{!! json_encode(array_filter([
    '@context' => 'https://schema.org', '@type' => 'Product', 'name' => $product->name, 'sku' => $product->sku,
    'image' => $product->imageUrl(), 'description' => $product->short_description, 'brand' => $product->brand ? ['@type' => 'Brand', 'name' => $product->brand] : null,
    'aggregateRating' => $avg ? ['@type' => 'AggregateRating', 'ratingValue' => $avg, 'reviewCount' => $reviewCount] : null,
    'offers' => $product->enquiry_only ? null : ['@type' => 'Offer', 'priceCurrency' => \App\Services\Money::currency(), 'price' => number_format($product->currentPrice() / 100, 2, '.', ''),
        'availability' => $product->canBePurchased(1) ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock', 'url' => route('product.show', $product)],
]), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!}</script>
@endpush
@section('content')
<div class="mx-auto max-w-7xl px-4 py-8" x-data="{ variant: {{ $firstVariant?->id ?? 'null' }}, qty: 1, main: {{ \Illuminate\Support\Js::from($gallery->first()['url'] ?? $product->imageUrl()) }}, lightbox: false,
    variantImages: {{ \Illuminate\Support\Js::from($variantImages) }},
    prices: {{ \Illuminate\Support\Js::from($product->variants->mapWithKeys(fn ($v) => [$v->id => $product->priceFor($v) / 100])) }}, base: {{ $product->currentPrice() / 100 }},
    pick() { if (this.variant && this.variantImages[this.variant]) this.main = this.variantImages[this.variant]; },
    copied: false, copy() { navigator.clipboard.writeText('{{ route('product.show', $product) }}').then(() => { this.copied = true; setTimeout(() => this.copied = false, 2000); }); } }"
    @keydown.escape.window="lightbox = false">
    <nav class="text-sm text-muted" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Home</a> / <a href="{{ route('shop') }}">Shop</a>
        @if($product->category) / <a href="{{ route('category.show', $product->category) }}">{{ $product->category->name }}</a>@endif
        / <span aria-current="page">{{ $product->name }}</span>
    </nav>

    <div class="mt-6 grid gap-10 md:grid-cols-2">
        <div>
            <button type="button" class="block w-full cursor-zoom-in" @click="lightbox = true" aria-label="Enlarge image">
                <img :src="main" alt="{{ $product->name }}" class="aspect-square w-full rounded-lg bg-surface object-cover"></button>
            @if($gallery->count() > 1)<div class="mt-3 flex gap-2 overflow-x-auto">
                @foreach($gallery as $g)
                    <button type="button" @click="main = {{ \Illuminate\Support\Js::from($g['url']) }}" class="h-16 w-16 shrink-0 overflow-hidden rounded border border-line" aria-label="Show image {{ $loop->iteration }}">
                        <img src="{{ $g['url'] }}" alt="" loading="lazy" class="h-full w-full object-cover"></button>
                @endforeach</div>@endif
            <div x-show="lightbox" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" role="dialog" aria-modal="true" aria-label="Image viewer" @click="lightbox = false">
                <button type="button" class="absolute right-4 top-4 text-3xl text-white" @click="lightbox = false" aria-label="Close image viewer">×</button>
                <img :src="main" alt="{{ $product->name }}" class="max-h-full max-w-full object-contain"></div>
        </div>

        <div>
            <h1 class="text-3xl md:text-4xl">{{ $product->name }}</h1>
            <p class="mt-1 text-sm text-muted">SKU {{ $product->sku }} · {{ $product->stockLabel() }}</p>
            @if($avg)<p class="mt-1 text-sm" aria-label="Rated {{ $avg }} out of 5 from {{ $reviewCount }} reviews">★ {{ $avg }} <span class="text-muted">({{ $reviewCount }} {{ \Illuminate\Support\Str::plural('review', $reviewCount) }})</span></p>@endif
            <p class="mt-4 text-2xl font-semibold">
                @if($product->enquiry_only) Price on request @else
                    <span x-text="'{{ \App\Services\Money::symbol() }}' + (variant && prices[variant] !== undefined ? prices[variant] : base).toLocaleString('en', {minimumFractionDigits: 2})">{{ $m($product->currentPrice()) }}</span>
                    @if($product->isOnSale())<s class="ml-2 text-base font-normal text-muted">{{ $m($product->price) }}</s><span class="ml-2 rounded bg-brand-yellow px-2 py-0.5 text-xs">-{{ $product->discountPercent() }}%</span>@endif
                @endif
            </p>
            <p class="mt-4 text-muted">{{ $product->short_description }}</p>

            <form method="post" action="{{ route('cart.add', $product) }}" class="mt-6 space-y-4">@csrf
                @if($product->variants->isNotEmpty())
                    <div><label class="label" for="variant">Option</label>
                        <select id="variant" name="variant_id" x-model.number="variant" @change="pick()" class="field">
                            @foreach($product->variants as $v)<option value="{{ $v->id }}" @disabled($v->stock_quantity < 1 && $product->track_stock && ! $product->allow_backorder)>{{ $v->label() }}@if($v->price_adjustment) ({{ $v->price_adjustment > 0 ? '+' : '-' }}{{ $m(abs($v->price_adjustment)) }})@endif</option>@endforeach
                        </select></div>
                @endif
                <div><label class="label" for="qty">Quantity</label><input id="qty" type="number" name="quantity" min="1" max="99" x-model.number="qty" class="field w-24"></div>

                @if($product->enquiry_only)
                    <p class="text-sm text-muted">This item is priced on request. Message us for a quote.</p>
                @else
                    <div class="flex flex-wrap gap-3">
                        <button class="btn-red flex-1" @disabled(! $product->canBePurchased(1, $firstVariant))>Add to cart</button>
                        <button class="btn-line" name="buy_now" value="1" @disabled(! $product->canBePurchased(1, $firstVariant))>Buy now</button>
                    </div>
                @endif
                @if($waOn)
                    <a :href="'{{ route('product.whatsapp', $product) }}?variant=' + (variant ?? '') + '&qty=' + (qty || 1)" target="_blank" rel="noopener" class="btn-whatsapp w-full">{{ $product->enquiry_only ? 'Enquire on WhatsApp' : 'Order on WhatsApp' }}</a>
                    @if($hours)<p class="text-xs text-muted">{{ $hours }}</p>@endif
                @endif
            </form>

            <div class="mt-4 flex flex-wrap items-center gap-4 text-sm">
                <form method="post" action="{{ route('wishlist.toggle', $product) }}">@csrf<button class="underline">♡ Save to wishlist</button></form>
                <span class="text-muted">Share:</span>
                <button type="button" class="underline" @click="copy()"><span x-show="!copied">Copy link</span><span x-show="copied" x-cloak>Copied!</span></button>
                <a class="underline" target="_blank" rel="noopener" href="https://wa.me/?text={{ rawurlencode($product->name.' '.route('product.show', $product)) }}">WhatsApp</a>
                <a class="underline" target="_blank" rel="noopener" href="https://www.facebook.com/sharer/sharer.php?u={{ rawurlencode(route('product.show', $product)) }}">Facebook</a>
            </div>

            @if($product->delivery_info)<div class="mt-6 rounded-lg bg-surface p-4 text-sm"><p class="font-semibold">Delivery</p><p class="mt-1 text-muted">{!! nl2br(e($product->delivery_info)) !!}</p></div>@endif

            @if($specRows->isNotEmpty())<dl class="mt-8 divide-y divide-line border-y border-line text-sm"><h2 class="sr-only">Specifications</h2>
                @foreach($specRows as $k => $val)<div class="flex justify-between gap-4 py-3"><dt class="text-muted">{{ $k }}</dt><dd class="text-right">{{ $val }}</dd></div>@endforeach</dl>@endif
            @if($product->description)<div class="mt-6 text-sm leading-relaxed">{!! nl2br(e($product->description)) !!}</div>@endif
        </div>
    </div>

    <section class="mt-16"><h2 class="text-2xl">Customer reviews</h2>
        @forelse($reviews as $r)
            <div class="mt-4 border-b border-line pb-4 text-sm"><p class="font-semibold">{{ $r->author_name }} · {{ $r->rating }}/5 @if($r->is_verified_purchase)<span class="text-brand-green">Verified purchase</span>@endif</p><p class="mt-1 text-muted">{{ $r->body }}</p></div>
        @empty <p class="mt-3 text-sm text-muted">No reviews yet.</p> @endforelse
        <form method="post" action="{{ route('reviews.store', $product) }}" class="mt-6 max-w-md space-y-3 text-sm">@csrf
            <p class="font-semibold">Write a review</p>
            <input name="author_name" class="field" placeholder="Your name" aria-label="Your name" value="{{ auth()->user()?->name }}" required>
            <select name="rating" class="field" aria-label="Rating">@for($i = 5; $i >= 1; $i--)<option value="{{ $i }}">{{ $i }} / 5</option>@endfor</select>
            <textarea name="body" rows="3" class="field" placeholder="Your experience" aria-label="Review"></textarea>
            <button class="btn-line">Submit review</button></form>
    </section>

    @foreach([['You may also like', $product->related], ['Recently viewed', $recentlyViewed]] as [$t, $set])
        @if($set->isNotEmpty())<section class="mt-16"><h2 class="text-2xl">{{ $t }}</h2>
            <div class="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">@foreach($set->load('variants') as $rel) @include('partials.product-card', ['product' => $rel]) @endforeach</div></section>@endif
    @endforeach
</div>
@endsection
