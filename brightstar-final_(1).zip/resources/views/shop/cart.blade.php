@extends('layouts.store')
@section('title', 'Your cart | Brightstar Global Furniture')
@section('content')
@php $m = fn ($v) => \App\Services\Money::format($v); @endphp
<div class="mx-auto max-w-5xl px-4 py-10">
    <h1 class="text-3xl">Your cart</h1>
    @foreach($totals['issues'] as $issue)<p class="mt-3 rounded bg-brand-red/10 px-3 py-2 text-sm text-brand-red">{{ $issue }}</p>@endforeach

    @if(! $totals['lines'])
        <div class="mt-8 rounded-lg border border-line p-10 text-center"><p class="font-display text-xl">Your cart is empty</p>
            <a href="{{ route('shop') }}" class="btn-red mt-5">Browse furniture</a></div>
    @else
    <div class="mt-8 grid gap-8 md:grid-cols-[1fr_320px]">
        <ul class="divide-y divide-line">
            @foreach($totals['lines'] as $l)
            <li class="flex gap-4 py-4">
                <img src="{{ $l['product']->imageUrl() }}" alt="" class="h-24 w-24 rounded object-cover">
                <div class="flex-1 text-sm">
                    <a href="{{ route('product.show', $l['product']) }}" class="font-display text-lg">{{ $l['name'] }}</a>
                    @php $opts = $l['product']->variants->where('is_active', true); @endphp
                    @if($opts->count() > 1)
                        <form method="post" action="{{ route('cart.update', $l['item_id']) }}" class="mt-1">@csrf @method('PATCH')
                            <label class="sr-only" for="opt-{{ $l['item_id'] }}">Option</label>
                            <select id="opt-{{ $l['item_id'] }}" name="variant_id" class="field w-auto py-1.5 text-xs" onchange="this.form.submit()">@foreach($opts as $o)<option value="{{ $o->id }}" @selected($o->id === $l['variant']?->id)>{{ $o->label() }}</option>@endforeach</select></form>
                    @elseif($l['variant_label'])<p class="text-muted">{{ $l['variant_label'] }}</p>@endif
                    <p class="text-muted">{{ $m($l['unit_price']) }} each</p>
                    <div class="mt-2 flex items-center gap-3">
                        <form method="post" action="{{ route('cart.update', $l['item_id']) }}">@csrf @method('PATCH')
                            <input type="number" name="quantity" min="0" max="99" value="{{ $l['quantity'] }}" class="field w-20" aria-label="Quantity" onchange="this.form.submit()"></form>
                        <form method="post" action="{{ route('cart.remove', $l['item_id']) }}">@csrf @method('DELETE')<button class="text-brand-red underline">Remove</button></form>
                    </div>
                </div>
                <p class="font-semibold">{{ $m($l['line_total']) }}</p>
            </li>
            @endforeach
        </ul>
        <aside class="h-fit rounded-lg border border-line p-5 text-sm">
            <form method="post" action="{{ route('cart.coupon') }}" class="mb-4 flex gap-2">@csrf
                <input name="code" value="{{ $totals['coupon']?->code }}" class="field" placeholder="Coupon code" aria-label="Coupon code"><button class="btn-line">Apply</button></form>
            <dl class="space-y-2">
                <div class="flex justify-between"><dt>Subtotal</dt><dd>{{ $m($totals['subtotal']) }}</dd></div>
                @if($totals['discount'])<div class="flex justify-between text-brand-green"><dt>Discount</dt><dd>-{{ $m($totals['discount']) }}</dd></div>@endif
                @if($totals['tax'])<div class="flex justify-between"><dt>{{ \App\Models\Setting::get('tax_label', 'Tax') }}</dt><dd>{{ $m($totals['tax']) }}</dd></div>@endif
                <div class="flex justify-between text-muted"><dt>Delivery</dt><dd>Calculated at checkout</dd></div>
                <div class="flex justify-between border-t border-line pt-2 text-base font-semibold"><dt>Total</dt><dd>{{ $m($totals['total']) }}</dd></div>
            </dl>
            <a href="{{ route('checkout.show') }}" class="btn-red mt-5 w-full">Checkout</a>
            @if($waLink)<a href="{{ $waLink }}" target="_blank" rel="noopener" class="btn-whatsapp mt-2 w-full">Order cart on WhatsApp</a>@endif
        </aside>
    </div>
    @endif
</div>
@endsection
