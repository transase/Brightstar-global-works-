@extends('layouts.store')
@section('title', 'Collections | Brightstar Global Furniture')
@section('content')
<div class="mx-auto max-w-7xl px-4 py-10"><h1 class="text-4xl">Collections</h1>
<div class="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">@forelse($collections as $c)
    <a href="{{ route('collections.show', $c->slug) }}" class="group block">
        @if($c->imageUrl())<img src="{{ $c->imageUrl() }}" alt="" loading="lazy" class="aspect-[4/3] w-full rounded-lg object-cover">@endif
        <h2 class="mt-3 text-xl group-hover:text-brand-red">{{ $c->name }}</h2><p class="text-sm text-muted">{{ $c->products_count }} {{ \Illuminate\Support\Str::plural('piece', $c->products_count) }}</p></a>
@empty<p class="text-muted">Collections are coming soon. <a class="underline" href="{{ route('shop') }}">Browse all furniture</a>.</p>@endforelse</div></div>
@endsection
