@extends('layouts.store')
@section('title', 'Ideas for Your Space | Brightstar Global Furniture')
@section('content')
<div class="mx-auto max-w-7xl px-4 py-10"><h1 class="text-4xl">Ideas for Your Space</h1>
<div class="mt-8 grid gap-8 md:grid-cols-3">@forelse($articles as $a)
    <a href="{{ route('ideas.show', $a->slug) }}" class="group block">@if($a->coverUrl())<img src="{{ $a->coverUrl() }}" alt="" loading="lazy" class="aspect-[4/3] w-full rounded-lg object-cover">@endif
        <h2 class="mt-3 text-xl group-hover:text-brand-red">{{ $a->title }}</h2><p class="mt-1 text-sm text-muted">{{ $a->excerpt }}</p></a>
@empty<p class="text-muted">New ideas are coming soon.</p>@endforelse</div><div class="mt-8">{{ $articles->links() }}</div></div>
@endsection
