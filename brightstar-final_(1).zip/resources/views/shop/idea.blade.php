@extends('layouts.store')
@section('title', $article->title.' | Brightstar Global Furniture')
@section('description', $article->seo_description ?: $article->excerpt)
@section('og_image', $article->coverUrl() ?: \App\Support\Branding::logo())
@section('content')
<article class="mx-auto max-w-3xl px-4 py-10"><a href="{{ route('ideas.index') }}" class="text-sm text-muted">← All ideas</a>
    <h1 class="mt-2 text-4xl">{{ $article->title }}</h1>
    @if($article->coverUrl())
    @php $pins = $products->filter(fn ($p) => $p->pivot->pos_x !== null && $p->pivot->pos_y !== null)->values(); @endphp
    <div class="relative mt-6" x-data="{ open: null }" @keydown.escape="open = null" @click.outside="open = null">
        <img src="{{ $article->coverUrl() }}" alt="" class="block w-full rounded-lg">
        @foreach($pins as $i => $p)
            <div class="absolute" style="left: {{ (float) $p->pivot->pos_x }}%; top: {{ (float) $p->pivot->pos_y }}%">
                <button type="button" @click="open = open === {{ $p->id }} ? null : {{ $p->id }}" :aria-expanded="open === {{ $p->id }}"
                        aria-label="Show {{ $p->name }}" class="-ml-4 -mt-4 flex h-8 w-8 items-center justify-center rounded-full border-2 border-white bg-brand-red text-sm font-semibold text-white shadow-lg">{{ $i + 1 }}</button>
                <div x-show="open === {{ $p->id }}" x-cloak class="absolute z-10 mt-2 w-48 -translate-x-1/2 rounded-lg border border-line bg-white p-3 text-sm shadow-lg">
                    <a href="{{ route('product.show', $p) }}" class="font-display text-base hover:text-brand-red">{{ $p->name }}</a>
                    <p class="mt-1 font-semibold">{{ $p->enquiry_only ? 'Price on request' : \App\Services\Money::format($p->currentPrice()) }}</p>
                    <a href="{{ route('product.show', $p) }}" class="mt-2 inline-block text-brand-red underline">View product</a>
                </div>
            </div>
        @endforeach
    </div>
    @endif
    <div class="mt-6 space-y-4 leading-relaxed">{!! nl2br(e($article->body)) !!}</div></article>
@if($products->isNotEmpty())<section class="mx-auto mt-6 max-w-7xl px-4"><h2 class="text-2xl">Shop this look</h2>
    <div class="mt-6 grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-4">@foreach($products as $product) @include('partials.product-card', ['product' => $product]) @endforeach</div></section>@endif
@endsection
