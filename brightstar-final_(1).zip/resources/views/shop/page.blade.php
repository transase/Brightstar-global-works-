@extends('layouts.store')
@section('title', $page->title.' | Brightstar Global Furniture')
@section('description', $page->seo_description ?: $page->title)
@section('content')
@php $wa = app(\App\Services\WhatsAppService::class); @endphp
<div class="mx-auto max-w-3xl px-4 py-12"><h1 class="text-4xl">{{ $page->title }}</h1>
    @if($page->body)<div class="mt-6 space-y-4 leading-relaxed">{!! nl2br(e($page->body)) !!}</div>@endif
    @if($page->slug === 'contact')
        <dl class="mt-8 space-y-2 text-sm">
            @foreach(['Address' => 'store_address', 'Phone' => 'store_phone', 'Email' => 'store_email', 'Hours' => 'wa_hours_notice'] as $l => $k)@if($x = \App\Models\Setting::get($k))<div><dt class="inline font-semibold">{{ $l }}:</dt> <dd class="inline">{{ $x }}</dd></div>@endif @endforeach</dl>
        @if($link = $wa->link($wa->generalMessage()))<a href="{{ $link }}" target="_blank" rel="noopener" class="btn-whatsapp mt-6">Chat on WhatsApp</a>@endif
    @endif
</div>
@endsection
