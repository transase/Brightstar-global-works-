@php $hasOptions = $product->variants->where('is_active', true)->isNotEmpty(); @endphp
<div class="grid gap-5 sm:grid-cols-2">
    <img src="{{ $product->imageUrl() }}" alt="{{ $product->name }}" class="aspect-square w-full rounded-lg bg-surface object-cover">
    <div class="text-sm">
        <h2 class="text-2xl">{{ $product->name }}</h2>
        <p class="mt-1 text-muted">SKU {{ $product->sku }} · {{ $product->stockLabel() }}</p>
        <p class="mt-3 text-xl font-semibold">{{ $product->enquiry_only ? 'Price on request' : ($hasOptions ? 'From ' : '').\App\Services\Money::format($product->currentPrice()) }}
            @if($product->isOnSale())<s class="ml-2 text-sm font-normal text-muted">{{ \App\Services\Money::format($product->price) }}</s>@endif</p>
        <p class="mt-3 text-muted">{{ $product->short_description }}</p>
        @if(! $product->enquiry_only && ! $hasOptions && $product->canBePurchased(1))
            <form method="post" action="{{ route('cart.add', $product) }}" class="mt-4">@csrf<input type="hidden" name="quantity" value="1"><button class="btn-red w-full">Add to cart</button></form>
        @endif
        <a href="{{ route('product.show', $product) }}" class="btn-line mt-2 w-full">{{ $hasOptions ? 'Choose options' : 'View full details' }}</a>
    </div>
</div>
