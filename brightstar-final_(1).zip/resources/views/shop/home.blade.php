@extends('layouts.store')
@section('title', 'Brightstar Global Furniture | Quality furniture for every room')
@section('content')
@if($heroSlides->isNotEmpty())
<section class="bg-surface" x-data="{ i: 0, n: {{ $heroSlides->count() }} }" x-init="if (n > 1 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) setInterval(() => i = (i + 1) % n, 6000)" aria-roledescription="carousel">
    @foreach($heroSlides as $k => $sl)
    <div x-show="i === {{ $k }}" @unless($k === 0) x-cloak @endunless class="mx-auto grid max-w-7xl items-center gap-8 px-4 py-14 md:grid-cols-2 md:py-24">
        <div><h1 class="text-4xl leading-tight md:text-6xl">{{ $sl->heading }}</h1>
            @if($sl->description)<p class="mt-5 max-w-md text-lg text-muted">{{ $sl->description }}</p>@endif
            @if($sl->cta_text && $sl->url)<a href="{{ $sl->url }}" class="btn-red mt-8">{{ $sl->cta_text }}</a>@endif</div>
        @if($sl->imageUrl())<img src="{{ $sl->imageUrl() }}" alt="" class="aspect-[4/3] w-full rounded-lg object-cover" @if($k) loading="lazy" @endif>@endif
    </div>@endforeach
    @if($heroSlides->count() > 1)<div class="flex justify-center gap-2 pb-4">@foreach($heroSlides as $k => $sl)<button type="button" @click="i = {{ $k }}" class="h-2 w-2 rounded-full" :class="i === {{ $k }} ? 'bg-brand-red' : 'bg-line'" aria-label="Show slide {{ $k + 1 }}"></button>@endforeach</div>@endif
</section>
@else
<section class="bg-surface">
    <div class="mx-auto grid max-w-7xl items-center gap-8 px-4 py-14 md:grid-cols-2 md:py-24">
        <div>
            <h1 class="text-4xl leading-tight md:text-6xl">{{ \App\Models\Setting::get('hero_title', 'Transform Your Space with Timeless Furniture') }}</h1>
            <p class="mt-5 max-w-md text-lg text-muted">{{ \App\Models\Setting::get('hero_text', 'Discover stylish, comfortable and quality furniture designed to make every space feel like home.') }}</p>
            <div class="mt-8 flex flex-wrap gap-3">
                <a href="{{ route('shop') }}" class="btn-red">Shop Furniture</a>
                <a href="{{ route('collections.index') }}" class="btn-line">Explore Collections</a>
            </div>
        </div>
        <img src="{{ \App\Support\Branding::hero() }}" alt="" class="aspect-[4/3] w-full rounded-lg object-cover">
    </div>
</section>
@endif
@foreach($promos as $pr)
<section class="mx-auto mt-12 max-w-7xl px-4"><div class="flex flex-wrap items-center justify-between gap-4 rounded-lg bg-ink p-8 text-white">
    <div><h2 class="text-2xl">{{ $pr->heading }}</h2>@if($pr->description)<p class="mt-1 text-white/80">{{ $pr->description }}</p>@endif</div>
    @if($pr->cta_text && $pr->url)<a href="{{ $pr->url }}" class="btn bg-brand-yellow text-ink">{{ $pr->cta_text }}</a>@endif</div></section>
@endforeach

<section class="mx-auto max-w-7xl px-4 pt-16">
    <h2 class="text-3xl">Shop by category</h2>
    <div class="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        @forelse($categories as $c)
            <a href="{{ route('category.show', $c) }}" class="rounded-lg border border-line p-4 hover:border-ink">
                @if($c->image)<img src="{{ \App\Support\Media::url($c->image) }}" alt="" loading="lazy" class="mb-3 aspect-square w-full rounded object-cover">@endif
                <span class="font-display text-lg">{{ $c->name }}</span>
            </a>
        @empty
            <p class="col-span-full text-muted">No categories yet. Add some in the admin panel.</p>
        @endforelse
    </div>
</section>

@foreach([['Featured furniture', $featured], ['New arrivals', $newArrivals], ['Best sellers', $bestSellers]] as [$title, $set])
    @if($set->isNotEmpty())
    <section class="mx-auto max-w-7xl px-4 pt-16">
        <h2 class="text-3xl">{{ $title }}</h2>
        <div class="mt-6 grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-4">
            @foreach($set as $product) @include('partials.product-card', ['product' => $product]) @endforeach
        </div>
    </section>
    @endif
@endforeach
@if($collections->isNotEmpty())
<section class="mx-auto max-w-7xl px-4 pt-16"><div class="flex items-end justify-between"><h2 class="text-3xl">Collections</h2><a href="{{ route('collections.index') }}" class="text-sm underline">View all</a></div>
    <div class="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">@foreach($collections as $c)<a href="{{ route('collections.show', $c->slug) }}" class="group block">
        @if($c->imageUrl())<img src="{{ $c->imageUrl() }}" alt="" loading="lazy" class="aspect-[4/3] w-full rounded-lg object-cover">@endif<h3 class="mt-3 text-xl group-hover:text-brand-red">{{ $c->name }}</h3></a>@endforeach</div></section>
@endif

@if($rooms->isNotEmpty())
<section class="mx-auto max-w-7xl px-4 pt-16"><h2 class="text-3xl">Shop by room</h2>
    <div class="mt-6 grid grid-cols-2 gap-4 md:grid-cols-5">@foreach($rooms as $room)
        <a href="{{ route('category.show', $room->slug) }}" class="group relative block overflow-hidden rounded-lg bg-surface">
            @if($room->image)<img src="{{ \App\Support\Media::url($room->image) }}" alt="" loading="lazy" class="aspect-[3/4] w-full object-cover transition-transform group-hover:scale-105">@else<div class="aspect-[3/4]"></div>@endif
            <span class="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-3 font-display text-lg text-white">{{ $room->slug === 'office-furniture' ? 'Home Office' : ($room->slug === 'outdoor-furniture' ? 'Outdoor Space' : $room->name) }}</span></a>@endforeach</div></section>
@endif

@if($benefits->isNotEmpty())
<section class="mx-auto max-w-7xl px-4 pt-16" aria-labelledby="why-title"><h2 id="why-title" class="text-3xl">Why shop with us?</h2>
    <ul class="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">@foreach($benefits as $b)
        <li class="rounded-lg border border-line p-5"><h3 class="text-lg">{{ $b->title }}</h3>@if($b->text)<p class="mt-1 text-sm text-muted">{{ $b->text }}</p>@endif</li>@endforeach</ul></section>
@endif

@if($testimonials->isNotEmpty())
<section class="mx-auto max-w-7xl px-4 pt-16"><h2 class="text-3xl">Customer reviews</h2>
    <div class="mt-6 grid gap-4 md:grid-cols-3">@foreach($testimonials as $t)
        <figure class="rounded-lg border border-line p-5"><p class="text-sm" aria-label="{{ $t->rating }} out of 5">{{ str_repeat('★', $t->rating) }}{{ str_repeat('☆', 5 - $t->rating) }}</p>
            <blockquote class="mt-2 text-sm">{{ \Illuminate\Support\Str::limit($t->body, 220) }}</blockquote>
            <figcaption class="mt-3 text-xs text-muted">{{ $t->author_name }}@if($t->is_verified_purchase) · <span class="text-brand-green">Verified purchase</span>@endif</figcaption></figure>@endforeach</div></section>
@endif

@if($ideas->isNotEmpty())
<section class="mx-auto max-w-7xl px-4 pt-16"><div class="flex items-end justify-between"><h2 class="text-3xl">Ideas for Your Space</h2><a href="{{ route('ideas.index') }}" class="text-sm underline">View all</a></div>
    <div class="mt-6 grid gap-6 md:grid-cols-3">@foreach($ideas as $a)<a href="{{ route('ideas.show', $a->slug) }}" class="group block">
        @if($a->coverUrl())<img src="{{ $a->coverUrl() }}" alt="" loading="lazy" class="aspect-[4/3] w-full rounded-lg object-cover">@endif
        <h3 class="mt-3 text-xl group-hover:text-brand-red">{{ $a->title }}</h3></a>@endforeach</div></section>
@endif
@endsection
