# BRIGHTSTAR GLOBAL FURNITURE — Laravel e-commerce site + admin panel

Simple, mobile-first furniture shop for Nigeria: product browsing, WhatsApp ordering, optional Paystack payments,
and an admin panel for products, categories, orders, enquiries and site settings.

**Stack:** Laravel 11/12 · PHP 8.2+ · MySQL · Blade · Bootstrap 5 (CDN) · no build step (no Node/Vite needed).

## What's in this package

`overlay/` contains every application file (models, controllers, services, form requests, migrations, seeders,
Blade views, CSS/JS, tests, routes, `bootstrap/app.php`). It is meant to be copied on top of a fresh Laravel install,
which `install.sh` does for you.

## Install

Requirements: PHP 8.2+ with `gd`, `mbstring`, `pdo_mysql` (and `pdo_sqlite` for tests), Composer, MySQL.

```bash
./install.sh brightstar-app          # creates a fresh Laravel project and copies the overlay in
cd brightstar-app
nano .env                            # DB credentials, APP_URL, ADMIN_EMAIL, mail settings
php artisan migrate --seed           # tables + admin + 9 categories + demo products + default settings
php artisan serve
```

* Site: `http://localhost:8000` · Admin: `http://localhost:8000/admin/login`
* If `ADMIN_PASSWORD` is empty, a random password is **printed once** by the seeder. Change it under Admin → Settings.
* Production: set `APP_ENV=production`, `APP_DEBUG=false`, `SEED_DEMO_PRODUCTS=false`, run
  `php artisan config:cache route:cache view:cache`, and point the web root at `public/`.

Manual install (without the script): create a Laravel project, copy `overlay/*` over it (including dotfile
`.env.example.brightstar`, merge it into `.env`), delete `public/robots.txt`, then `php artisan storage:link`
and `php artisan migrate --seed`.

## First-time setup checklist (Admin → Settings)

1. Company name, logo, favicon, phone, **WhatsApp number** (e.g. `08012345678`; auto-converted to `234…`), email, address.
2. Hero image/headline, About page text, Privacy Policy and Terms (replace the placeholder text).
3. Delete the sample products (they are fictional, with placeholder pictures) and add real ones with photos.
4. Online payments (optional): paste Paystack public + secret keys, tick **Enable online payments**, and set the
   Paystack dashboard webhook URL to `https://your-domain/paystack/webhook`.

## How the key flows work

**WhatsApp ordering** — product page, product cards, floating button and cart all open `wa.me/<number>?text=…` with a
message built from live data (names, quantities, prices, total, customer details). From the cart, the order is also
saved in the database (status *Pending*, payment *Unpaid*) before WhatsApp opens, so nothing is lost.

**Online payment (Paystack)** — checkout creates the order + a pending payment, redirects to Paystack, and **never
trusts the browser redirect**. Both the callback and the signed webhook (HMAC-SHA512) call Paystack's verify API and
only mark the order paid when status, currency and amount (in kobo) all match. Idempotent. Secret key is stored
encrypted and never rendered in any page.

**Orders** — item names/prices are snapshotted. Order status and payment status are separate. Cancelling returns tracked
stock once. WhatsApp/bank-transfer orders can be marked paid manually (recorded as an admin-verified payment).
"Total sales" on the dashboard sums successful payments only.

**Safety rules** — categories with products can't be deleted; deleting a product leaves old orders intact; uploads are
validated (type + size) and re-encoded to WebP/JPEG (max 1400px) which strips metadata and saves mobile data.

## Security measures included

CSRF on all forms (webhook excluded, signature-verified instead) · password hashing · `is_admin` not mass-assignable ·
admin-only middleware on every `/admin` route · login/reset/checkout/enquiry throttling · reset-password responses don't
reveal whether an email exists · form requests on all inputs · Eloquent parameter binding (no raw SQL; `LIKE` input
escaped) · Blade escaping everywhere user text is shown · Google Maps embed URL restricted to google.com/maps ·
spam honeypot on the contact form.

## Tests

```bash
php artisan test
```

Covers storefront pages, search/filter/sort, cart + WhatsApp message/redirect, order snapshots, stock rules,
checkout validation, Paystack init/callback/webhook (bad signature, amount mismatch, abandoned, unreachable gateway,
idempotency), admin auth and authorisation, product/category CRUD, upload rejection, status/payment updates,
settings and secret encryption, and enquiries.

## Project map

```
app/Services      Cart · OrderService · Paystack · WhatsApp · ImageService
app/Http          Controllers (public + Admin/) · Requests · Middleware/EnsureAdmin
app/Models        Category Product ProductImage Order OrderItem Payment Enquiry Setting StockMovement User
database          migrations (+ is_admin on users) · seeders (admin, settings, categories, demo products)
resources/views   layouts/ · home · shop/ · cart/ · pages/ · admin/
public            css/site.css · js/site.js · images/placeholder.svg
```

## Known limitations / notes

* Customer-facing images come from what you upload — the demo products have no photos.
* The cart is session-based (no accounts); there is no customer login by design.
* Bootstrap and icons load from the jsDelivr CDN; self-host them if you need offline/zero-third-party loading.
* "Why Choose Us" text is deliberately generic — edit `resources/views/home.blade.php` only with claims you can verify.
* Add a scheduled backup of the database and `storage/app/public` on your host.
