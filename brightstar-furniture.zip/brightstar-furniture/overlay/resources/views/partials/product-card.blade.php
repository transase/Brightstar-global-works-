<div class="p-card">
    <a class="p-img" href="{{ route('product', $product->slug) }}">
        <img src="{{ $product->image_url }}" alt="{{ $product->images->first()?->alt ?: $product->name }}" loading="lazy" width="400" height="300">
        @if($product->has_discount)<span class="badge-sale">-{{ $product->discount_percent }}%</span>@endif
        @if($product->is_new)<span class="badge-new">NEW</span>@endif
    </a>
    <div class="p-body">
        <a class="p-name" href="{{ route('product', $product->slug) }}">{{ $product->name }}</a>
        <div>
            <span class="price">{{ naira($product->price) }}</span>
            @if($product->has_discount)<span class="old-price">{{ naira($product->old_price) }}</span>@endif
        </div>
        <div class="stock {{ $product->is_available ? 'in' : 'out' }}">{{ $product->availability_label }}</div>
        <div class="p-actions">
            <a class="btn btn-outline-brand btn-sm" href="{{ route('product', $product->slug) }}">View Details</a>
            @if($product->is_available)
                <a class="btn btn-wa btn-sm" href="{{ \App\Services\WhatsApp::forProduct($product) }}" target="_blank" rel="noopener">
                    <i class="bi bi-whatsapp"></i> Order on WhatsApp
                </a>
            @endif
        </div>
    </div>
</div>
