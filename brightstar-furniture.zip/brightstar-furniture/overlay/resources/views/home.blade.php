@extends('layouts.app')

@section('content')
@php $hero = setting('hero_image'); @endphp
<section class="hero {{ $hero ? '' : 'hero-plain' }}" @if($hero) style="background-image:url('{{ media_url($hero) }}')" @endif>
    <div class="container">
        <h1>{{ setting('hero_title', 'Quality Furniture for Every Home') }}</h1>
        <p class="mt-3">{{ setting('hero_subtitle') }}</p>
        <div class="d-flex flex-wrap gap-2 mt-4">
            <a class="btn btn-brand btn-lg" style="{{ $hero ? '' : 'background:#fff;color:#E51B23;border-color:#fff' }}" href="{{ route('shop') }}">{{ setting('hero_btn1_text', 'Shop Furniture') }}</a>
            <a class="btn btn-wa btn-lg" href="{{ \App\Services\WhatsApp::general() }}" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> {{ setting('hero_btn2_text', 'Chat with Us on WhatsApp') }}</a>
        </div>
    </div>
</section>

@if($categories->isNotEmpty())
<section class="section">
    <div class="container">
        <h2 class="section-title">Shop by Category</h2>
        <div class="row g-3 mt-2">
            @foreach($categories as $c)
                <div class="col-6 col-md-4 col-lg-3">
                    <a class="cat-card" href="{{ route('category', $c->slug) }}">
                        <img src="{{ $c->image_url }}" alt="{{ $c->name }}" loading="lazy">
                        <span>{{ $c->name }}</span>
                    </a>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif

@if($featured->isNotEmpty())
<section class="section bg-soft">
    <div class="container">
        <h2 class="section-title">Featured Products</h2>
        <div class="row g-3 mt-2">
            @foreach($featured as $product)<div class="col-6 col-md-4 col-lg-3">@include('partials.product-card', ['product' => $product])</div>@endforeach
        </div>
    </div>
</section>
@endif

@if($newArrivals->isNotEmpty())
<section class="section">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end">
            <h2 class="section-title">New Arrivals</h2>
            <a href="{{ route('shop') }}" class="fw-semibold">View all</a>
        </div>
        <div class="row g-3 mt-2">
            @foreach($newArrivals as $product)<div class="col-6 col-md-4 col-lg-3">@include('partials.product-card', ['product' => $product])</div>@endforeach
        </div>
    </div>
</section>
@endif

@if($offers->isNotEmpty())
<section class="section bg-soft">
    <div class="container">
        <h2 class="section-title">Special Offers</h2>
        <div class="row g-3 mt-2">
            @foreach($offers as $product)<div class="col-6 col-md-4 col-lg-3">@include('partials.product-card', ['product' => $product])</div>@endforeach
        </div>
    </div>
</section>
@endif

<section class="section">
    <div class="container">
        <h2 class="section-title text-center mx-auto" style="max-width:fit-content">Why Choose Us?</h2>
        <div class="row g-3 mt-3">
            @foreach([
                ['bi-award','Quality Furniture','Pieces chosen for comfort, strength and lasting use.'],
                ['bi-palette','Stylish Designs','A range of designs to suit different homes and offices.'],
                ['bi-whatsapp','Convenient Ordering','Order on WhatsApp or pay online, whichever suits you.'],
                ['bi-headset','Customer Support','Questions about a product? Talk to us before you buy.'],
            ] as [$icon,$title,$text])
                <div class="col-6 col-lg-3"><div class="benefit"><div class="ico"><i class="bi {{ $icon }}"></i></div><h3 class="h6 fw-bold">{{ $title }}</h3><p class="small text-muted mb-0">{{ $text }}</p></div></div>
            @endforeach
        </div>
    </div>
</section>

<section class="pb-4">
    <div class="container">
        <div class="cta">
            <h2 class="fw-bold">Ready to furnish your space?</h2>
            <p class="mb-4">Explore the collection or contact us with any question.</p>
            <a class="btn btn-light fw-bold me-2" href="{{ route('shop') }}">Explore Furniture</a>
            <a class="btn btn-outline-light fw-bold" href="{{ route('contact') }}">Contact Us</a>
        </div>
    </div>
</section>
@endsection
