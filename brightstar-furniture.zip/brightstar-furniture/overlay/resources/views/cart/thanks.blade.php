@extends('layouts.app')
@section('title', 'Order '.$order->order_number)

@section('content')
<div class="container py-5" style="max-width:720px">
    <div class="text-center mb-4">
        @if($order->payment_status === 'paid')
            <i class="bi bi-check-circle-fill text-success" style="font-size:3rem"></i>
            <h1 class="h3 fw-bold mt-2">Payment received. Thank you!</h1>
        @elseif($order->payment_status === 'failed')
            <i class="bi bi-x-circle-fill text-danger" style="font-size:3rem"></i>
            <h1 class="h3 fw-bold mt-2">Payment was not completed</h1>
            <p class="text-muted">Your order is saved but not paid. You can try again from the cart or order via WhatsApp.</p>
        @else
            <i class="bi bi-hourglass-split" style="font-size:3rem;color:#E51B23"></i>
            <h1 class="h3 fw-bold mt-2">Order received</h1>
            <p class="text-muted">We are waiting for payment confirmation. This page will show “paid” once it is verified.</p>
        @endif
        <p class="mb-0">Order number: <strong>{{ $order->order_number }}</strong></p>
    </div>

    <div class="border border-line rounded-3 p-3 mb-3">
        @foreach($order->items as $i)
            <div class="d-flex justify-content-between small py-1"><span>{{ $i->quantity }} × {{ $i->product_name }}</span><span>{{ naira($i->line_total) }}</span></div>
        @endforeach
        <hr class="my-2">
        <div class="d-flex justify-content-between fw-bold"><span>Total</span><span class="price">{{ naira($order->total) }}</span></div>
    </div>

    <div class="d-grid gap-2">
        <a class="btn btn-wa" href="{{ $waUrl }}" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> Send this order on WhatsApp</a>
        <a class="btn btn-outline-brand" href="{{ route('shop') }}">Continue Shopping</a>
    </div>
</div>
@endsection
