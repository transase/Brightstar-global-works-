@extends('layouts.app')
@section('title', 'Your Cart | '.setting('company_name'))

@section('content')
<div class="container py-4">
    <h1 class="h3 fw-bold mb-3">Your Cart</h1>

    @if($errors->has('cart'))<div class="alert alert-danger">{{ $errors->first('cart') }}</div>@endif

    @if($lines->isEmpty())
        <div class="text-center py-5">
            <p class="text-muted">Your cart is empty.</p>
            <a class="btn btn-brand" href="{{ route('shop') }}">Browse Furniture</a>
        </div>
    @else
    <div class="row g-4">
        <div class="col-lg-7">
            @foreach($lines as $l)
                <div class="d-flex gap-3 border border-line rounded-3 p-2 mb-2 align-items-center">
                    <img src="{{ $l->product->image_url }}" alt="{{ $l->product->name }}" width="84" height="64" style="object-fit:cover;border-radius:.4rem">
                    <div class="flex-fill">
                        <a class="fw-semibold" style="color:inherit" href="{{ route('product', $l->product->slug) }}">{{ $l->product->name }}</a>
                        <div class="small text-muted">{{ collect([$l->colour, $l->size])->filter()->implode(' · ') }}</div>
                        <div class="price">{{ naira($l->unit_price) }}</div>
                        <div class="d-flex gap-2 mt-1 align-items-center">
                            <form method="post" action="{{ route('cart.update') }}" class="d-flex gap-1">
                                @csrf
                                <input type="hidden" name="key" value="{{ $l->key }}">
                                <input type="number" name="qty" value="{{ $l->qty }}" min="1" max="99" class="form-control form-control-sm" style="width:72px" aria-label="Quantity">
                                <button class="btn btn-outline-secondary btn-sm">Update</button>
                            </form>
                            <form method="post" action="{{ route('cart.remove') }}">
                                @csrf <input type="hidden" name="key" value="{{ $l->key }}">
                                <button class="btn btn-link text-danger btn-sm p-0" style="min-height:0">Remove</button>
                            </form>
                        </div>
                    </div>
                    <div class="fw-bold text-nowrap">{{ naira($l->line_total) }}</div>
                </div>
            @endforeach
        </div>

        <div class="col-lg-5">
            <div class="border border-line rounded-3 p-3">
                <div class="d-flex justify-content-between"><span>Subtotal</span><strong>{{ naira($subtotal) }}</strong></div>
                <div class="d-flex justify-content-between"><span>Delivery</span>
                    <span>{{ $deliveryFee > 0 ? naira($deliveryFee) : 'Confirmed on order' }}</span></div>
                <hr>
                <div class="d-flex justify-content-between fs-5"><span>Total</span><strong class="price">{{ naira($subtotal + $deliveryFee) }}</strong></div>
                @if(setting('delivery_info'))<p class="small text-muted mt-2 mb-0">{{ setting('delivery_info') }}</p>@endif
            </div>

            <form method="post" action="{{ route('checkout') }}" class="border border-line rounded-3 p-3 mt-3">
                @csrf
                <h2 class="h6 fw-bold">Your details</h2>
                @if($errors->hasAny(['method','customer_name','phone','email','address']))
                    <div class="alert alert-danger py-2 small"><ul class="mb-0 ps-3">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>
                @endif
                <div class="mb-2"><label class="form-label small mb-1">Full name *</label><input class="form-control" name="customer_name" value="{{ old('customer_name') }}" required autocomplete="name"></div>
                <div class="mb-2"><label class="form-label small mb-1">Phone number *</label><input class="form-control" type="tel" name="phone" value="{{ old('phone') }}" required autocomplete="tel"></div>
                <div class="mb-2"><label class="form-label small mb-1">Email address {{ $paystackEnabled ? '(required for online payment)' : '(optional)' }}</label><input class="form-control" type="email" name="email" value="{{ old('email') }}" autocomplete="email"></div>
                <div class="mb-2"><label class="form-label small mb-1">Delivery address *</label><textarea class="form-control" name="address" rows="2" required>{{ old('address') }}</textarea></div>
                <div class="mb-3"><label class="form-label small mb-1">Notes (optional)</label><textarea class="form-control" name="notes" rows="2">{{ old('notes') }}</textarea></div>

                <div class="d-grid gap-2">
                    <button class="btn btn-wa" name="method" value="whatsapp"><i class="bi bi-whatsapp"></i> Order on WhatsApp</button>
                    @if($paystackEnabled)
                        <button class="btn btn-brand" name="method" value="paystack"><i class="bi bi-credit-card"></i> Pay Online</button>
                    @endif
                </div>
                <p class="small text-muted mt-2 mb-0">Please review your order above before submitting.</p>
            </form>
        </div>
    </div>
    @endif
</div>
@endsection
