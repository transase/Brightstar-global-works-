<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Admin | {{ setting('company_name', 'BRIGHTSTAR GLOBAL FURNITURE') }}</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body style="background:#F8F9FA">
<div class="container d-flex align-items-center justify-content-center" style="min-height:100vh">
    <div class="card shadow-sm border-0 p-4" style="width:100%;max-width:420px;border-top:4px solid #E51B23 !important">
        <div class="text-center mb-3"><span class="brand-text">{{ setting('company_name', 'BRIGHTSTAR GLOBAL FURNITURE') }}</span></div>
        @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
        @if($errors->any())<div class="alert alert-danger py-2 small">{{ $errors->first() }}</div>@endif
        @yield('content')
    </div>
</div>
</body>
</html>
