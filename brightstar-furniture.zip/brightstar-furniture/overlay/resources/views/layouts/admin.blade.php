<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>@yield('title', 'Admin') | {{ setting('company_name', 'BRIGHTSTAR GLOBAL FURNITURE') }}</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
    <style>
        body{background:#F8F9FA}
        .adm-side{background:#202020;min-height:100vh}
        .adm-side a{color:#d1d5db;display:block;padding:.6rem 1rem;border-radius:.5rem;font-weight:500}
        .adm-side a:hover,.adm-side a.on{background:#E51B23;color:#fff}
        .stat{background:#fff;border:1px solid #E5E7EB;border-radius:.75rem;padding:1rem}
        .stat .n{font-size:1.5rem;font-weight:800;color:#E51B23}
        .card{border-color:#E5E7EB}
        @media print{.adm-side,.no-print{display:none!important}}
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <aside class="col-lg-2 adm-side p-3 no-print">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="{{ route('admin.dashboard') }}" class="fw-bold text-white p-0 fs-6">{{ setting('company_name', 'Admin') }}</a>
                <button class="btn btn-sm btn-outline-light d-lg-none" data-bs-toggle="collapse" data-bs-target="#admNav"><i class="bi bi-list"></i></button>
            </div>
            <nav class="collapse d-lg-block" id="admNav">
                @php $nav = [
                    ['admin.dashboard','bi-speedometer2','Dashboard'], ['admin.products.index','bi-box-seam','Products'],
                    ['admin.categories.index','bi-tags','Categories'], ['admin.orders.index','bi-receipt','Orders'],
                    ['admin.enquiries.index','bi-envelope','Enquiries'], ['admin.settings.edit','bi-gear','Settings'],
                ]; @endphp
                @foreach($nav as [$r,$i,$l])
                    <a class="{{ request()->routeIs($r === 'admin.dashboard' ? $r : \Illuminate\Support\Str::beforeLast($r,'.').'.*') ? 'on' : '' }}" href="{{ route($r) }}"><i class="bi {{ $i }} me-2"></i>{{ $l }}</a>
                @endforeach
                <a href="{{ route('home') }}" target="_blank"><i class="bi bi-box-arrow-up-right me-2"></i>View website</a>
                <form method="post" action="{{ route('admin.logout') }}" class="mt-2">@csrf
                    <button class="btn btn-outline-light btn-sm w-100">Log out</button></form>
            </nav>
        </aside>
        <main class="col-lg-10 p-3 p-lg-4">
            @if(session('success'))<div class="alert alert-success no-print">{{ session('success') }}</div>@endif
            @if($errors->any())<div class="alert alert-danger no-print"><ul class="mb-0 ps-3">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>@endif
            @yield('content')
        </main>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
