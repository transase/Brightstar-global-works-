@php
    $company = setting('company_name', 'BRIGHTSTAR GLOBAL FURNITURE');
    $logo = setting('logo');
    $metaTitle = trim($__env->yieldContent('title')) ?: setting('seo_title', $company);
    $metaDesc = trim($__env->yieldContent('description')) ?: setting('seo_description');
    $ogImage = trim($__env->yieldContent('og_image')) ?: ($logo ? media_url($logo) : '');
@endphp
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $metaTitle }}</title>
    <meta name="description" content="{{ $metaDesc }}">
    <link rel="canonical" href="{{ url()->current() }}">
    <meta property="og:site_name" content="{{ $company }}">
    <meta property="og:type" content="@yield('og_type', 'website')">
    <meta property="og:title" content="{{ $metaTitle }}">
    <meta property="og:description" content="{{ $metaDesc }}">
    <meta property="og:url" content="{{ url()->current() }}">
    @if($ogImage)<meta property="og:image" content="{{ $ogImage }}">@endif
    <meta name="twitter:card" content="summary_large_image">
    @if(setting('favicon'))<link rel="icon" href="{{ media_url(setting('favicon')) }}">@endif
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
    @stack('head')
</head>
<body>
@if(setting('promo_banner_text'))
    <div class="promo-bar">
        @if(setting('promo_banner_link')) <a href="{{ setting('promo_banner_link') }}">{{ setting('promo_banner_text') }}</a>
        @else {{ setting('promo_banner_text') }} @endif
    </div>
@endif

<header class="site-header">
    <nav class="navbar navbar-expand-lg py-2">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="{{ route('home') }}">
                @if($logo)<img class="brand-logo" src="{{ media_url($logo) }}" alt="{{ $company }}">
                @else<span class="brand-text">{{ $company }}</span>@endif
            </a>

            <div class="d-flex align-items-center ms-auto order-lg-3">
                <a class="icon-btn" href="{{ route('shop') }}#search" aria-label="Search"><i class="bi bi-search fs-5"></i></a>
                <a class="icon-btn" href="{{ route('cart.index') }}" aria-label="Cart">
                    <i class="bi bi-bag fs-5"></i>
                    @if($cartCount > 0)<span class="cart-badge">{{ $cartCount }}</span>@endif
                </a>
                <a class="btn btn-wa btn-sm ms-2 d-none d-md-inline-flex" href="{{ \App\Services\WhatsApp::general() }}" target="_blank" rel="noopener">
                    <i class="bi bi-whatsapp"></i> WhatsApp
                </a>
                <button class="navbar-toggler border-0 ms-1" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-label="Menu">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>

            <div class="collapse navbar-collapse order-lg-2 ms-lg-4" id="mainNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link {{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}">Home</a></li>
                    <li class="nav-item"><a class="nav-link {{ request()->routeIs('shop','product') ? 'active' : '' }}" href="{{ route('shop') }}">Shop</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Categories</a>
                        <ul class="dropdown-menu">
                            @foreach($navCategories as $c)
                                <li><a class="dropdown-item" href="{{ route('category', $c->slug) }}">{{ $c->name }}</a></li>
                            @endforeach
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link {{ request()->routeIs('about') ? 'active' : '' }}" href="{{ route('about') }}">About Us</a></li>
                    <li class="nav-item"><a class="nav-link {{ request()->routeIs('contact') ? 'active' : '' }}" href="{{ route('contact') }}">Contact</a></li>
                </ul>
                <form class="search-form d-flex my-2 my-lg-0" action="{{ route('shop') }}" method="get" role="search">
                    <input class="form-control" type="search" name="q" value="{{ request('q') }}" placeholder="Search furniture…" aria-label="Search">
                    <button class="btn btn-brand" type="submit" aria-label="Search"><i class="bi bi-search"></i></button>
                </form>
            </div>
        </div>
    </nav>
</header>

<main>
    @if(session('success'))
        <div class="container mt-3"><div class="alert alert-success mb-0">{{ session('success') }}</div></div>
    @endif
    @yield('content')
</main>

<footer class="site-footer mt-5 pt-5">
    <div class="container">
        <div class="row g-4 pb-4">
            <div class="col-lg-4">
                @if($logo)<img src="{{ media_url($logo) }}" alt="{{ $company }}" style="height:44px;background:#fff;padding:4px;border-radius:6px" class="mb-3">
                @else<h6 class="fs-5">{{ $company }}</h6>@endif
                <p>{{ setting('company_description') }}</p>
                <div class="d-flex gap-3 fs-5">
                    @foreach(['facebook'=>'facebook','instagram'=>'instagram','twitter'=>'twitter-x','tiktok'=>'tiktok'] as $k=>$icon)
                        @if(setting($k))<a href="{{ setting($k) }}" target="_blank" rel="noopener" aria-label="{{ ucfirst($k) }}"><i class="bi bi-{{ $icon }}"></i></a>@endif
                    @endforeach
                </div>
            </div>
            <div class="col-6 col-lg-2">
                <h6>Quick Links</h6>
                <ul class="list-unstyled">
                    <li><a href="{{ route('home') }}">Home</a></li>
                    <li><a href="{{ route('shop') }}">Shop</a></li>
                    <li><a href="{{ route('about') }}">About Us</a></li>
                    <li><a href="{{ route('contact') }}">Contact</a></li>
                    <li><a href="{{ route('cart.index') }}">Cart</a></li>
                </ul>
            </div>
            <div class="col-6 col-lg-3">
                <h6>Furniture</h6>
                <ul class="list-unstyled">
                    @foreach($navCategories->take(7) as $c)
                        <li><a href="{{ route('category', $c->slug) }}">{{ $c->name }}</a></li>
                    @endforeach
                </ul>
            </div>
            <div class="col-lg-3">
                <h6>Contact</h6>
                <ul class="list-unstyled">
                    @if(setting('phone'))<li><i class="bi bi-telephone me-2"></i><a href="tel:{{ preg_replace('/\s+/', '', setting('phone')) }}">{{ setting('phone') }}</a></li>@endif
                    @if(\App\Services\WhatsApp::number())<li><i class="bi bi-whatsapp me-2"></i><a href="{{ \App\Services\WhatsApp::general() }}" target="_blank" rel="noopener">Chat on WhatsApp</a></li>@endif
                    @if(setting('email'))<li><i class="bi bi-envelope me-2"></i><a href="mailto:{{ setting('email') }}">{{ setting('email') }}</a></li>@endif
                    @if(setting('address'))<li><i class="bi bi-geo-alt me-2"></i>{{ setting('address') }}</li>@endif
                </ul>
            </div>
        </div>
        @if(setting('footer_text'))<p class="small text-center pb-3 mb-0">{{ setting('footer_text') }}</p>@endif
        <div class="copy py-3 d-flex flex-wrap justify-content-between gap-2 small">
            <span>&copy; {{ date('Y') }} {{ $company }}. All rights reserved.</span>
            <span><a href="{{ route('privacy') }}">Privacy Policy</a> &middot; <a href="{{ route('terms') }}">Terms and Conditions</a></span>
        </div>
    </div>
</footer>

@if(\App\Services\WhatsApp::number())
<a class="wa-float" href="{{ \App\Services\WhatsApp::general() }}" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">
    <svg viewBox="0 0 24 24"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21c5.46 0 9.91-4.45 9.91-9.91S17.5 2 12.04 2zm5.8 14.2c-.24.68-1.42 1.3-1.96 1.35-.5.05-1.13.07-1.82-.11-.42-.13-.96-.31-1.65-.61-2.9-1.25-4.79-4.17-4.94-4.37-.14-.2-1.18-1.57-1.18-3s.75-2.13 1.01-2.42c.26-.29.57-.36.76-.36l.55.01c.18.01.42-.07.65.5.24.58.82 2.01.89 2.16.07.14.12.31.02.5-.09.2-.14.31-.28.48l-.42.49c-.14.14-.29.3-.12.58.16.29.73 1.2 1.57 1.95 1.08.96 1.99 1.26 2.28 1.4.29.14.46.12.63-.07.17-.2.72-.84.91-1.13.19-.29.38-.24.65-.14.26.1 1.67.79 1.96.93.29.14.48.22.55.34.07.12.07.7-.17 1.38z"/></svg>
</a>
@endif

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="{{ asset('js/site.js') }}"></script>
@stack('scripts')
</body>
</html>
