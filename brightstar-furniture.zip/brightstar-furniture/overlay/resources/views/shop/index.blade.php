@extends('layouts.app')
@section('title', ($activeCategory ? $activeCategory->name.' | ' : 'Shop Furniture | ').setting('company_name'))
@section('description', $activeCategory?->description ?: 'Browse our furniture collection.')

@section('content')
<div class="container py-4" id="search">
    <h1 class="h3 fw-bold mb-3">{{ $activeCategory?->name ?? 'Shop Furniture' }}</h1>

    <form method="get" action="{{ $activeCategory ? route('category', $activeCategory->slug) : route('shop') }}" class="row g-2 mb-4 align-items-end">
        <div class="col-12 col-md-4"><input class="form-control" name="q" value="{{ request('q') }}" placeholder="Search by product name"></div>
        @unless($activeCategory)
        <div class="col-6 col-md-2">
            <select class="form-select" name="category">
                <option value="">All categories</option>
                @foreach($categories as $c)<option value="{{ $c->slug }}" @selected(request('category') === $c->slug)>{{ $c->name }}</option>@endforeach
            </select>
        </div>
        @endunless
        <div class="col-3 col-md-1"><input class="form-control" type="number" min="0" name="min_price" value="{{ request('min_price') }}" placeholder="Min ₦"></div>
        <div class="col-3 col-md-1"><input class="form-control" type="number" min="0" name="max_price" value="{{ request('max_price') }}" placeholder="Max ₦"></div>
        <div class="col-6 col-md-2">
            <select class="form-select" name="sort">
                <option value="newest" @selected(request('sort','newest')==='newest')>Newest</option>
                <option value="price_asc" @selected(request('sort')==='price_asc')>Price: low to high</option>
                <option value="price_desc" @selected(request('sort')==='price_desc')>Price: high to low</option>
            </select>
        </div>
        <div class="col-6 col-md-2 d-grid"><button class="btn btn-brand">Apply</button></div>
    </form>

    @if($products->isEmpty())
        <div class="text-center py-5 text-muted">No products found. <a href="{{ route('shop') }}">Clear filters</a></div>
    @else
        <div class="row g-3">
            @foreach($products as $product)<div class="col-6 col-md-4 col-xl-3">@include('partials.product-card', ['product' => $product])</div>@endforeach
        </div>
        <div class="mt-4 d-flex justify-content-center">{{ $products->links() }}</div>
    @endif
</div>
@endsection
