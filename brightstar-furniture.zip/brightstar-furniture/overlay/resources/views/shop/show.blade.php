@extends('layouts.app')
@section('title', $product->seo_title ?: $product->name.' | '.setting('company_name'))
@section('description', $product->seo_description ?: \Illuminate\Support\Str::limit(strip_tags((string) $product->description), 155))
@section('og_image', $product->image_url)
@section('og_type', 'product')

@push('head')
<script type="application/ld+json">
{!! json_encode(array_filter([
    '@context' => 'https://schema.org', '@type' => 'Product',
    'name' => $product->name,
    'image' => $product->images->map->url->all() ?: [$product->image_url],
    'description' => strip_tags((string) $product->description),
    'category' => $product->category->name,
    'offers' => [
        '@type' => 'Offer', 'url' => url()->current(), 'priceCurrency' => 'NGN',
        'price' => (string) $product->price,
        'availability' => $product->is_available ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
    ],
]), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) !!}
</script>
@endpush

@section('content')
<div class="container py-4">
    <nav class="small mb-3"><a href="{{ route('home') }}">Home</a> / <a href="{{ route('category', $product->category->slug) }}">{{ $product->category->name }}</a> / <span class="text-muted">{{ $product->name }}</span></nav>

    @if($errors->any())<div class="alert alert-danger">{{ $errors->first() }}</div>@endif

    <div class="row g-4">
        <div class="col-md-6">
            <img id="gallery-main" class="gallery-main" src="{{ $product->image_url }}" alt="{{ $product->images->first()?->alt ?: $product->name }}" width="800" height="600">
            @if($product->images->count() > 1)
                <div class="d-flex gap-2 mt-2 flex-wrap">
                    @foreach($product->images as $i => $img)
                        <img class="thumb {{ $i === 0 ? 'active' : '' }}" data-thumb="{{ $img->url }}" src="{{ $img->url }}" alt="{{ $img->alt ?: $product->name }}" loading="lazy">
                    @endforeach
                </div>
            @endif
        </div>

        <div class="col-md-6">
            <h1 class="h3 fw-bold">{{ $product->name }}</h1>
            <div class="mb-2">
                <span class="price fs-3">{{ naira($product->price) }}</span>
                @if($product->has_discount)
                    <span class="old-price fs-6">{{ naira($product->old_price) }}</span>
                    <span class="badge" style="background:#F2DF00;color:#202020">Save {{ $product->discount_percent }}%</span>
                @endif
            </div>
            <div class="stock {{ $product->is_available ? 'in' : 'out' }} mb-3">
                <i class="bi {{ $product->is_available ? 'bi-check-circle-fill' : 'bi-x-circle' }}"></i> {{ $product->availability_label }}
            </div>

            @if($product->description)<p>{!! nl2br(e($product->description)) !!}</p>@endif

            <table class="table table-sm spec-table">
                <tr><th>Category</th><td>{{ $product->category->name }}</td></tr>
                @if($product->dimensions)<tr><th>Dimensions</th><td>{{ $product->dimensions }}</td></tr>@endif
                @if($product->material)<tr><th>Material</th><td>{{ $product->material }}</td></tr>@endif
            </table>

            <form method="post" action="{{ route('cart.add') }}" id="add-form">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">

                @if($product->colour_list)
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Colour</label>
                        <div class="d-flex flex-wrap gap-2">
                            @foreach($product->colour_list as $c)
                                <input type="radio" class="btn-check" name="colour" id="c{{ $loop->index }}" value="{{ $c }}" @checked(old('colour', $loop->first ? $c : null) === $c)>
                                <label class="btn btn-outline-secondary btn-sm" for="c{{ $loop->index }}">{{ $c }}</label>
                            @endforeach
                        </div>
                    </div>
                @endif
                @if($product->size_list)
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Size</label>
                        <div class="d-flex flex-wrap gap-2">
                            @foreach($product->size_list as $s)
                                <input type="radio" class="btn-check" name="size" id="s{{ $loop->index }}" value="{{ $s }}" @checked(old('size', $loop->first ? $s : null) === $s)>
                                <label class="btn btn-outline-secondary btn-sm" for="s{{ $loop->index }}">{{ $s }}</label>
                            @endforeach
                        </div>
                    </div>
                @endif

                @if($product->is_available)
                <div class="d-flex flex-wrap gap-2 align-items-stretch">
                    <input type="number" id="qty" name="qty" class="form-control" style="max-width:90px;min-height:44px" value="1" min="1" max="{{ $product->track_stock ? max(1, $product->stock_qty) : 99 }}" aria-label="Quantity">
                    <button class="btn btn-brand flex-fill" type="submit"><i class="bi bi-bag-plus"></i> Add to Cart</button>
                </div>
                <a id="wa-product-btn" class="btn btn-wa w-100 mt-2" target="_blank" rel="noopener"
                   href="{{ \App\Services\WhatsApp::forProduct($product) }}"
                   data-base="{{ 'https://wa.me/'.\App\Services\WhatsApp::number() }}"
                   data-company="{{ setting('company_name') }}" data-name="{{ $product->name }}"
                   data-price="{{ $product->price }}" data-symbol="{{ setting('currency_symbol', '₦') }}">
                    <i class="bi bi-whatsapp"></i> Order on WhatsApp
                </a>
                @else
                    <a class="btn btn-wa w-100" target="_blank" rel="noopener" href="{{ \App\Services\WhatsApp::general() }}"><i class="bi bi-whatsapp"></i> Ask about availability</a>
                @endif
            </form>
        </div>
    </div>

    @if($related->isNotEmpty())
        <h2 class="section-title mt-5">Related Products</h2>
        <div class="row g-3 mt-1">
            @foreach($related as $p)<div class="col-6 col-md-3">@include('partials.product-card', ['product' => $p])</div>@endforeach
        </div>
    @endif
</div>
@endsection
