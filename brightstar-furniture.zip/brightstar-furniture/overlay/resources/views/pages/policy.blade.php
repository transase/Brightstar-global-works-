@extends('layouts.app')
@section('title', $title.' | '.setting('company_name'))

@section('content')
<div class="container py-5" style="max-width:820px">
    <h1 class="fw-bold mb-3">{{ $title }}</h1>
    <div>{!! nl2br(e($body)) !!}</div>
</div>
@endsection
