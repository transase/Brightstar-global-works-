@extends('layouts.app')
@section('title', setting('about_title', 'About Us').' | '.setting('company_name'))

@section('content')
<div class="container py-5">
    <div class="row g-4 align-items-center">
        <div class="{{ setting('about_image') ? 'col-md-6' : 'col-md-9 mx-auto' }}">
            <h1 class="fw-bold">{{ setting('about_title', 'About Us') }}</h1>
            <div class="mt-3">{!! nl2br(e(setting('about_body'))) !!}</div>
            @php $values = array_filter(array_map('trim', explode("\n", (string) setting('about_values')))); @endphp
            @if($values)
                <h2 class="h5 fw-bold mt-4">Our values</h2>
                <ul class="list-unstyled">@foreach($values as $v)<li class="mb-1"><i class="bi bi-check-circle-fill text-success me-2"></i>{{ $v }}</li>@endforeach</ul>
            @endif
            <a class="btn btn-brand mt-3" href="{{ route('contact') }}">Contact Us</a>
        </div>
        @if(setting('about_image'))
        <div class="col-md-6"><img class="img-fluid rounded-3" src="{{ media_url(setting('about_image')) }}" alt="{{ setting('company_name') }} showroom" loading="lazy"></div>
        @endif
    </div>
</div>
@endsection
