@extends('layouts.app')
@section('title', 'Contact Us | '.setting('company_name'))

@section('content')
<div class="container py-5">
    <h1 class="fw-bold mb-4">Contact Us</h1>
    <div class="row g-4">
        <div class="col-md-5">
            <ul class="list-unstyled">
                @if(setting('phone'))<li class="mb-2"><i class="bi bi-telephone me-2 text-danger"></i><a href="tel:{{ preg_replace('/\s+/', '', setting('phone')) }}">{{ setting('phone') }}</a></li>@endif
                @if(\App\Services\WhatsApp::number())<li class="mb-2"><i class="bi bi-whatsapp me-2 text-success"></i><a href="{{ \App\Services\WhatsApp::general() }}" target="_blank" rel="noopener">Chat on WhatsApp</a></li>@endif
                @if(setting('email'))<li class="mb-2"><i class="bi bi-envelope me-2 text-danger"></i><a href="mailto:{{ setting('email') }}">{{ setting('email') }}</a></li>@endif
                @if(setting('address'))<li class="mb-2"><i class="bi bi-geo-alt me-2 text-danger"></i>{{ setting('address') }}</li>@endif
                @if(setting('business_hours'))<li class="mb-2"><i class="bi bi-clock me-2 text-danger"></i>{{ setting('business_hours') }}</li>@endif
            </ul>
            @if(setting('maps_embed_url'))
                <iframe src="{{ setting('maps_embed_url') }}" class="w-100 rounded-3 border-0" height="260" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Map"></iframe>
            @endif
        </div>
        <div class="col-md-7">
            <form method="post" action="{{ route('contact.send') }}" class="border border-line rounded-3 p-3">
                @csrf
                <h2 class="h5 fw-bold">Send an enquiry</h2>
                @if($errors->any())<div class="alert alert-danger py-2 small"><ul class="mb-0 ps-3">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>@endif
                <div style="position:absolute;left:-9999px" aria-hidden="true"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>
                <div class="mb-2"><label class="form-label small mb-1">Name *</label><input class="form-control" name="name" value="{{ old('name') }}" required></div>
                <div class="row g-2 mb-2">
                    <div class="col-sm-6"><label class="form-label small mb-1">Email</label><input class="form-control" type="email" name="email" value="{{ old('email') }}"></div>
                    <div class="col-sm-6"><label class="form-label small mb-1">Phone</label><input class="form-control" type="tel" name="phone" value="{{ old('phone') }}"></div>
                </div>
                <div class="mb-3"><label class="form-label small mb-1">Message *</label><textarea class="form-control" name="message" rows="5" required>{{ old('message') }}</textarea></div>
                <button class="btn btn-brand">Send Enquiry</button>
            </form>
        </div>
    </div>
</div>
@endsection
