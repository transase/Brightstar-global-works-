@extends('layouts.admin')
@section('title', 'Orders')
@section('content')
<h1 class="h4 fw-bold mb-3">Orders</h1>
<form class="row g-2 mb-3" method="get">
    <div class="col-12 col-md-3"><input class="form-control" name="q" value="{{ request('q') }}" placeholder="Order no, name, phone, email"></div>
    <div class="col-6 col-md-2"><select class="form-select" name="status"><option value="">Any status</option>@foreach(\App\Models\Order::STATUSES as $k=>$l)<option value="{{ $k }}" @selected(request('status')===$k)>{{ $l }}</option>@endforeach</select></div>
    <div class="col-6 col-md-2"><select class="form-select" name="payment_status"><option value="">Any payment</option>@foreach(\App\Models\Order::PAYMENT_STATUSES as $k=>$l)<option value="{{ $k }}" @selected(request('payment_status')===$k)>{{ $l }}</option>@endforeach</select></div>
    <div class="col-6 col-md-2"><input type="date" class="form-control" name="from" value="{{ request('from') }}" aria-label="From"></div>
    <div class="col-6 col-md-2"><input type="date" class="form-control" name="to" value="{{ request('to') }}" aria-label="To"></div>
    <div class="col-auto"><button class="btn btn-outline-secondary">Filter</button></div>
</form>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th>Order</th><th>Customer</th><th>Date</th><th class="text-end">Total</th><th>Method</th><th>Payment</th><th>Status</th></tr></thead><tbody>
    @forelse($orders as $o)
        <tr><td><a href="{{ route('admin.orders.show', $o) }}" class="fw-semibold">{{ $o->order_number }}</a></td>
            <td>{{ $o->customer_name }}<div class="small text-muted">{{ $o->phone }}</div></td>
            <td>{{ $o->created_at->format('d M Y, H:i') }}</td><td class="text-end">{{ naira($o->total) }}</td>
            <td>{{ $o->payment_method_label }}</td>
            <td><span class="badge {{ $o->payment_status === 'paid' ? 'text-bg-success' : ($o->payment_status === 'failed' ? 'text-bg-danger' : 'text-bg-secondary') }}">{{ $o->payment_status_label }}</span></td>
            <td><span class="badge text-bg-dark">{{ $o->status_label }}</span></td></tr>
    @empty <tr><td colspan="7" class="text-center text-muted py-4">No orders found.</td></tr> @endforelse
    </tbody></table></div></div>
<div class="mt-3">{{ $orders->links() }}</div>
@endsection
