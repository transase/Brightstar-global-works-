<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Receipt {{ $order->order_number }}</title>
<style>
 body{font-family:Arial,sans-serif;color:#202020;max-width:720px;margin:24px auto;padding:0 16px}
 h1{color:#E51B23;margin:0 0 4px} table{width:100%;border-collapse:collapse;margin-top:16px}
 th,td{padding:8px;border-bottom:1px solid #E5E7EB;text-align:left} .r{text-align:right}
 .muted{color:#6B7280;font-size:13px} @media print{.np{display:none}}
</style></head>
<body>
<button class="np" onclick="window.print()">Print</button>
<h1>{{ setting('company_name') }}</h1>
<div class="muted">{{ setting('address') }} {{ setting('phone') ? '· '.setting('phone') : '' }} {{ setting('email') ? '· '.setting('email') : '' }}</div>
<hr>
<p><strong>Receipt / Order:</strong> {{ $order->order_number }}<br><strong>Date:</strong> {{ $order->created_at->format('d M Y, H:i') }}<br>
<strong>Customer:</strong> {{ $order->customer_name }}, {{ $order->phone }}<br><strong>Delivery address:</strong> {{ $order->address }}<br>
<strong>Payment:</strong> {{ $order->payment_method_label }} — {{ $order->payment_status_label }}</p>
<table><thead><tr><th>Item</th><th class="r">Price</th><th class="r">Qty</th><th class="r">Total</th></tr></thead><tbody>
@foreach($order->items as $i)<tr><td>{{ $i->product_name }}@if($i->colour||$i->size)<div class="muted">{{ collect([$i->colour,$i->size])->filter()->implode(' · ') }}</div>@endif</td>
<td class="r">{{ naira($i->unit_price) }}</td><td class="r">{{ $i->quantity }}</td><td class="r">{{ naira($i->line_total) }}</td></tr>@endforeach
</tbody><tfoot>
<tr><td colspan="3" class="r">Subtotal</td><td class="r">{{ naira($order->subtotal) }}</td></tr>
<tr><td colspan="3" class="r">Delivery</td><td class="r">{{ naira($order->delivery_charge) }}</td></tr>
<tr><th colspan="3" class="r">Total</th><th class="r">{{ naira($order->total) }}</th></tr></tfoot></table>
<p class="muted" style="margin-top:24px">Thank you for shopping with {{ setting('company_name') }}.</p>
</body></html>
