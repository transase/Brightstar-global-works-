@extends('layouts.admin')
@section('title', 'Order '.$order->order_number)
@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4 fw-bold mb-0">Order {{ $order->order_number }}</h1>
    <div><a class="btn btn-outline-secondary btn-sm" href="{{ route('admin.orders.receipt', $order) }}" target="_blank"><i class="bi bi-printer"></i> Print receipt</a>
        <a class="btn btn-link btn-sm" href="{{ route('admin.orders.index') }}">Back</a></div>
</div>
<div class="row g-3">
    <div class="col-lg-8">
        <div class="card mb-3"><div class="table-responsive"><table class="table mb-0 align-middle">
            <thead><tr><th>Product</th><th class="text-end">Price</th><th class="text-end">Qty</th><th class="text-end">Total</th></tr></thead><tbody>
            @foreach($order->items as $i)
                <tr><td>{{ $i->product_name }}<div class="small text-muted">{{ collect([$i->colour, $i->size])->filter()->implode(' · ') }}</div></td>
                    <td class="text-end">{{ naira($i->unit_price) }}</td><td class="text-end">{{ $i->quantity }}</td><td class="text-end">{{ naira($i->line_total) }}</td></tr>
            @endforeach
            </tbody>
            <tfoot>
                <tr><td colspan="3" class="text-end">Subtotal</td><td class="text-end">{{ naira($order->subtotal) }}</td></tr>
                <tr><td colspan="3" class="text-end">Delivery charge</td><td class="text-end">{{ naira($order->delivery_charge) }}</td></tr>
                <tr><th colspan="3" class="text-end">Total</th><th class="text-end">{{ naira($order->total) }}</th></tr>
            </tfoot></table></div></div>
        <div class="card card-body"><h2 class="h6 fw-bold">Payments</h2>
            @forelse($order->payments as $p)
                <div class="small border-bottom py-1">{{ ucfirst($p->gateway) }} · {{ $p->reference }} · {{ naira($p->amount) }} · <strong>{{ ucfirst($p->status) }}</strong>{{ $p->paid_at ? ' · '.$p->paid_at->format('d M Y H:i') : '' }}</div>
            @empty <div class="small text-muted">No payment records.</div> @endforelse
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card card-body mb-3">
            <h2 class="h6 fw-bold">Customer</h2>
            <div>{{ $order->customer_name }}</div>
            <div><a href="tel:{{ $order->phone }}">{{ $order->phone }}</a></div>
            @if($order->email)<div>{{ $order->email }}</div>@endif
            <div class="mt-2 small text-muted">Delivery address</div><div>{{ $order->address }}</div>
            @if($order->notes)<div class="mt-2 small text-muted">Notes</div><div>{{ $order->notes }}</div>@endif
            <div class="mt-2 small text-muted">Placed {{ $order->created_at->format('d M Y, H:i') }} · {{ $order->payment_method_label }}</div>
        </div>
        <div class="card card-body mb-3">
            <h2 class="h6 fw-bold">Order status</h2>
            <form method="post" action="{{ route('admin.orders.status', $order) }}" class="d-flex gap-2">@csrf @method('PATCH')
                <select name="status" class="form-select" @disabled($order->status === 'cancelled')>@foreach(\App\Models\Order::STATUSES as $k=>$l)<option value="{{ $k }}" @selected($order->status===$k)>{{ $l }}</option>@endforeach</select>
                <button class="btn btn-brand" @disabled($order->status === 'cancelled')>Save</button></form>
        </div>
        <div class="card card-body">
            <h2 class="h6 fw-bold">Payment status</h2>
            <form method="post" action="{{ route('admin.orders.payment', $order) }}" class="d-flex gap-2">@csrf @method('PATCH')
                <select name="payment_status" class="form-select">@foreach(\App\Models\Order::PAYMENT_STATUSES as $k=>$l)<option value="{{ $k }}" @selected($order->payment_status===$k)>{{ $l }}</option>@endforeach</select>
                <button class="btn btn-brand">Save</button></form>
            <div class="small text-muted mt-2">Online payments are marked paid automatically after server-side verification. Use this for WhatsApp / bank-transfer orders you have confirmed yourself.</div>
        </div>
    </div>
</div>
@endsection
