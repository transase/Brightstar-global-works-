@extends('layouts.admin')
@section('title', 'Categories')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-3"><h1 class="h4 fw-bold mb-0">Categories</h1>
    <a class="btn btn-brand" href="{{ route('admin.categories.create') }}"><i class="bi bi-plus-lg"></i> Add category</a></div>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th></th><th>Name</th><th>Order</th><th>Products</th><th>Status</th><th></th></tr></thead><tbody>
    @foreach($categories as $c)
        <tr><td><img src="{{ $c->image_url }}" width="56" height="42" style="object-fit:cover;border-radius:4px" alt=""></td>
            <td class="fw-semibold">{{ $c->name }}</td><td>{{ $c->sort_order }}</td><td>{{ $c->products_count }}</td>
            <td>{!! $c->is_active ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Hidden</span>' !!}</td>
            <td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-secondary" href="{{ route('admin.categories.edit', $c) }}">Edit</a>
                <form class="d-inline" method="post" action="{{ route('admin.categories.destroy', $c) }}" onsubmit="return confirm('Delete this category?')">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Delete</button></form></td></tr>
    @endforeach
    </tbody></table></div></div>
@endsection
