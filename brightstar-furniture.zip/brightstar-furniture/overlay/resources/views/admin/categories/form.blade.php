@extends('layouts.admin')
@php $editing = $category->exists; @endphp
@section('title', $editing ? 'Edit category' : 'Add category')
@section('content')
<h1 class="h4 fw-bold mb-3">{{ $editing ? 'Edit category' : 'Add category' }}</h1>
<form class="card card-body" style="max-width:640px" method="post" enctype="multipart/form-data" action="{{ $editing ? route('admin.categories.update', $category) : route('admin.categories.store') }}">
    @csrf @if($editing) @method('PUT') @endif
    <div class="mb-3"><label class="form-label">Name *</label><input class="form-control" name="name" value="{{ old('name', $category->name) }}" required></div>
    <div class="mb-3"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="3">{{ old('description', $category->description) }}</textarea></div>
    <div class="mb-3"><label class="form-label">Display order (lower shows first)</label><input type="number" min="0" class="form-control" name="sort_order" value="{{ old('sort_order', $category->sort_order) }}"></div>
    <div class="mb-3"><label class="form-label">Image</label>@if($category->image)<div class="mb-2"><img src="{{ $category->image_url }}" width="140" style="border-radius:6px" alt=""></div>@endif
        <input type="file" class="form-control" name="image" accept="image/jpeg,image/png,image/webp"></div>
    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="is_active" id="act" value="1" @checked(old('is_active', $category->is_active))><label class="form-check-label" for="act">Active (visible on website)</label></div>
    <div><button class="btn btn-brand">Save</button> <a class="btn btn-link" href="{{ route('admin.categories.index') }}">Cancel</a></div>
</form>
@endsection
