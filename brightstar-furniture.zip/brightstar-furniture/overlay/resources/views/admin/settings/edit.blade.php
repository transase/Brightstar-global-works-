@extends('layouts.admin')
@section('title', 'Settings')
@php
    $v = fn ($k, $d = null) => old($k, setting($k, $d));
    $field = function ($k, $label, $type = 'text', $hint = null) use ($v) {
        return '<div class="mb-3"><label class="form-label">'.e($label).'</label><input class="form-control" type="'.$type.'" name="'.$k.'" value="'.e($v($k)).'">'.($hint ? '<div class="form-text">'.e($hint).'</div>' : '').'</div>';
    };
    $area = fn ($k, $label, $rows = 3) => '<div class="mb-3"><label class="form-label">'.e($label).'</label><textarea class="form-control" rows="'.$rows.'" name="'.$k.'">'.e($v($k)).'</textarea></div>';
    $file = function ($k, $label) {
        $cur = setting($k);
        return '<div class="mb-3"><label class="form-label">'.e($label).'</label>'.($cur ? '<div class="mb-1"><img src="'.e(media_url($cur)).'" style="max-height:60px;border-radius:4px" alt=""></div>' : '')
            .'<input class="form-control" type="file" name="'.$k.'" accept="image/png,image/jpeg,image/webp'.($k === 'favicon' ? ',image/x-icon,.ico' : '').'"></div>';
    };
@endphp
@section('content')
<h1 class="h4 fw-bold mb-3">Website settings</h1>

<form method="post" action="{{ route('admin.settings.update') }}" enctype="multipart/form-data">
@csrf @method('PUT')
<div class="accordion" id="acc">
  @php
  $sections = [
    'Company & contact' => fn () => $field('company_name','Company name').$file('logo','Logo').$file('favicon','Favicon')
        .$field('phone','Contact phone number').$field('whatsapp','WhatsApp number','text','Digits, e.g. 08012345678 or 2348012345678')
        .$field('email','Email address','email').$area('address','Business address').$field('business_hours','Business hours')
        .$field('maps_embed_url','Google Maps embed URL','url','Google Maps → Share → Embed a map → copy the src="…" link').$area('company_description','Short company description (footer)'),
    'Social media' => fn () => $field('facebook','Facebook URL','url').$field('instagram','Instagram URL','url').$field('twitter','X / Twitter URL','url').$field('tiktok','TikTok URL','url'),
    'Homepage' => fn () => $file('hero_image','Hero image').$field('hero_title','Hero headline').$area('hero_subtitle','Hero subheading').$field('hero_btn1_text','Button 1 text').$field('hero_btn2_text','WhatsApp button text')
        .$field('promo_banner_text','Promotional banner text (leave empty to hide)').$field('promo_banner_link','Promotional banner link (optional)'),
    'About page' => fn () => $field('about_title','Title').$area('about_body','Introduction text',8).$area('about_values','Business values (one per line)',4).$file('about_image','Showroom / store image'),
    'Delivery & currency' => fn () => $field('currency_symbol','Currency symbol').$field('delivery_fee','Flat delivery charge (₦, 0 = confirm on order)','number').$area('delivery_info','Delivery information'),
    'Footer, SEO & policies' => fn () => $area('footer_text','Footer text',2).$field('seo_title','Default SEO title').$area('seo_description','Default SEO description',2).$area('privacy_policy','Privacy Policy',6).$area('terms','Terms and Conditions',6),
  ];
  @endphp
  @foreach($sections as $title => $render)
    <div class="accordion-item">
      <h2 class="accordion-header"><button class="accordion-button {{ $loop->first ? '' : 'collapsed' }}" type="button" data-bs-toggle="collapse" data-bs-target="#s{{ $loop->index }}">{{ $title }}</button></h2>
      <div id="s{{ $loop->index }}" class="accordion-collapse collapse {{ $loop->first ? 'show' : '' }}" data-bs-parent="#acc"><div class="accordion-body">{!! $render() !!}</div></div>
    </div>
  @endforeach

  <div class="accordion-item">
    <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#spay">Online payments (Paystack)</button></h2>
    <div id="spay" class="accordion-collapse collapse" data-bs-parent="#acc"><div class="accordion-body">
        <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="payments_enabled" id="pe" value="1" @checked(setting('payments_enabled','0') === '1')><label class="form-check-label" for="pe">Enable online payments</label></div>
        {!! $field('paystack_public_key','Paystack public key') !!}
        <div class="mb-3"><label class="form-label">Paystack secret key</label>
            <input class="form-control" type="password" name="paystack_secret_key" autocomplete="new-password" placeholder="{{ setting('paystack_secret_key') ? '•••••••• saved (leave blank to keep)' : 'sk_live_…' }}">
            <div class="form-text">Stored encrypted. Never shown on the website.</div></div>
        <div class="small text-muted">Set your Paystack dashboard webhook URL to <code>{{ route('paystack.webhook') }}</code></div>
    </div></div>
  </div>
</div>
<button class="btn btn-brand mt-3">Save settings</button>
</form>

<div class="card card-body mt-4" style="max-width:520px">
    <h2 class="h6 fw-bold">Change admin password</h2>
    <form method="post" action="{{ route('admin.account.password') }}">@csrf @method('PUT')
        <input class="form-control mb-2" type="password" name="current_password" placeholder="Current password" required autocomplete="current-password">
        <input class="form-control mb-2" type="password" name="password" placeholder="New password (10+ chars, letters & numbers)" required autocomplete="new-password">
        <input class="form-control mb-2" type="password" name="password_confirmation" placeholder="Confirm new password" required autocomplete="new-password">
        <button class="btn btn-outline-secondary">Change password</button>
    </form>
</div>
@endsection
