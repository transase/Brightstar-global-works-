@extends('layouts.auth')
@section('content')
<h1 class="h4 fw-bold mb-3">Choose a new password</h1>
<form method="post" action="{{ route('admin.password.update') }}">
    @csrf
    <input type="hidden" name="token" value="{{ $token }}">
    <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" value="{{ old('email', $email) }}" class="form-control" required></div>
    <div class="mb-3"><label class="form-label">New password (10+ characters, letters and numbers)</label><input type="password" name="password" class="form-control" required></div>
    <div class="mb-3"><label class="form-label">Confirm password</label><input type="password" name="password_confirmation" class="form-control" required></div>
    <button class="btn btn-brand w-100">Reset password</button>
</form>
@endsection
