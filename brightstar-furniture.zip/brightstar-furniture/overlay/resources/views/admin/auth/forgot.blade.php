@extends('layouts.auth')
@section('content')
<h1 class="h4 fw-bold mb-3">Reset password</h1>
<form method="post" action="{{ route('admin.password.email') }}">
    @csrf
    <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" value="{{ old('email') }}" class="form-control" required autofocus></div>
    <button class="btn btn-brand w-100">Email reset link</button>
</form>
<p class="text-center mt-3 mb-0 small"><a href="{{ route('admin.login') }}">Back to sign in</a></p>
@endsection
