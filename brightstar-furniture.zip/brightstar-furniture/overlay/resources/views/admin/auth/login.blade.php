@extends('layouts.auth')
@section('content')
<h1 class="h4 fw-bold mb-3">Admin sign in</h1>
<form method="post" action="{{ route('admin.login.post') }}">
    @csrf
    <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" value="{{ old('email') }}" class="form-control" required autofocus></div>
    <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
    <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="remember" id="r"><label class="form-check-label" for="r">Remember me</label></div>
    <button class="btn btn-brand w-100">Sign in</button>
</form>
<p class="text-center mt-3 mb-0 small"><a href="{{ route('admin.password.request') }}">Forgot password?</a></p>
@endsection
