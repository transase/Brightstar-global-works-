@extends('layouts.admin')
@php $editing = $product->exists; @endphp
@section('title', $editing ? 'Edit product' : 'Add product')
@section('content')
<h1 class="h4 fw-bold mb-3">{{ $editing ? 'Edit product' : 'Add product' }}</h1>
<form method="post" enctype="multipart/form-data" action="{{ $editing ? route('admin.products.update', $product) : route('admin.products.store') }}">
    @csrf @if($editing) @method('PUT') @endif
    <div class="row g-3">
        <div class="col-lg-8"><div class="card card-body">
            <div class="mb-3"><label class="form-label">Product name *</label><input class="form-control" name="name" value="{{ old('name', $product->name) }}" required maxlength="150"></div>
            <div class="mb-3"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="5">{{ old('description', $product->description) }}</textarea></div>
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label">Selling price (₦) *</label><input type="number" step="0.01" min="0" class="form-control" name="price" value="{{ old('price', $product->price) }}" required></div>
                <div class="col-md-6"><label class="form-label">Old price (₦, optional)</label><input type="number" step="0.01" min="0" class="form-control" name="old_price" value="{{ old('old_price', $product->old_price) }}"></div>
                <div class="col-md-6"><label class="form-label">Dimensions</label><input class="form-control" name="dimensions" value="{{ old('dimensions', $product->dimensions) }}" placeholder="e.g. 210cm x 90cm x 85cm"></div>
                <div class="col-md-6"><label class="form-label">Material</label><input class="form-control" name="material" value="{{ old('material', $product->material) }}"></div>
                <div class="col-md-6"><label class="form-label">Colours (comma separated)</label><input class="form-control" name="colours" value="{{ old('colours', $product->colours) }}" placeholder="Grey, Cream"></div>
                <div class="col-md-6"><label class="form-label">Sizes (comma separated)</label><input class="form-control" name="sizes" value="{{ old('sizes', $product->sizes) }}" placeholder="Queen, King"></div>
            </div>
        </div>
        <div class="card card-body mt-3">
            <label class="form-label">Images (JPG, PNG or WebP, up to 5 MB each, max 8 at a time)</label>
            <input type="file" class="form-control" name="images[]" accept="image/jpeg,image/png,image/webp" multiple>
            <input class="form-control mt-2" name="image_alt" placeholder="Image description for accessibility/SEO (optional)">
            @if($editing && $product->images->isNotEmpty())
                <div class="d-flex flex-wrap gap-3 mt-3">
                    @foreach($product->images as $img)
                        <div class="text-center"><img src="{{ $img->url }}" width="110" height="82" style="object-fit:cover;border-radius:6px" alt="{{ $img->alt }}">
                            <button type="submit" class="btn btn-link btn-sm text-danger d-block mx-auto" form="del-{{ $img->id }}" onclick="return confirm('Remove this image?')">Remove</button></div>
                    @endforeach
                </div>
            @endif
        </div>
        <div class="card card-body mt-3">
            <h2 class="h6 fw-bold">SEO (optional)</h2>
            <input class="form-control mb-2" name="seo_title" value="{{ old('seo_title', $product->seo_title) }}" placeholder="Page title">
            <textarea class="form-control" name="seo_description" rows="2" maxlength="300" placeholder="Meta description">{{ old('seo_description', $product->seo_description) }}</textarea>
        </div></div>

        <div class="col-lg-4"><div class="card card-body">
            <div class="mb-3"><label class="form-label">Category *</label>
                <select class="form-select" name="category_id" required><option value="">Choose…</option>
                    @foreach($categories as $c)<option value="{{ $c->id }}" @selected(old('category_id', $product->category_id) == $c->id)>{{ $c->name }}</option>@endforeach
                </select></div>
            <div class="mb-3"><label class="form-label">Availability *</label>
                <select class="form-select" name="availability">@foreach(\App\Models\Product::AVAILABILITY as $k => $l)<option value="{{ $k }}" @selected(old('availability', $product->availability) === $k)>{{ $l }}</option>@endforeach</select></div>
            @foreach(['is_active'=>'Visible on website','is_featured'=>'Featured product','is_new'=>'New arrival','is_on_sale'=>'On sale / special offer','track_stock'=>'Track stock quantity'] as $f => $l)
                <div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" role="switch" name="{{ $f }}" id="{{ $f }}" value="1" @checked(old($f, $product->{$f}))><label class="form-check-label" for="{{ $f }}">{{ $l }}</label></div>
            @endforeach
            <div class="mt-2"><label class="form-label">Stock quantity</label><input type="number" min="0" class="form-control" name="stock_qty" value="{{ old('stock_qty', $product->stock_qty ?? 0) }}"></div>
            <button class="btn btn-brand w-100 mt-3">{{ $editing ? 'Save changes' : 'Create product' }}</button>
            <a class="btn btn-link w-100" href="{{ route('admin.products.index') }}">Cancel</a>
        </div></div>
    </div>
</form>
@if($editing)
    @foreach($product->images as $img)
        <form id="del-{{ $img->id }}" method="post" action="{{ route('admin.products.images.destroy', [$product, $img]) }}">@csrf @method('DELETE')</form>
    @endforeach
@endif
@endsection
