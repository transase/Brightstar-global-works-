@extends('layouts.admin')
@section('title', 'Products')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4 fw-bold mb-0">Products</h1>
    <a class="btn btn-brand" href="{{ route('admin.products.create') }}"><i class="bi bi-plus-lg"></i> Add product</a>
</div>
<form class="row g-2 mb-3" method="get">
    <div class="col-8 col-md-4"><input class="form-control" name="q" value="{{ request('q') }}" placeholder="Search products"></div>
    <div class="col-4 col-md-3"><select class="form-select" name="category"><option value="">All categories</option>@foreach($categories as $c)<option value="{{ $c->id }}" @selected(request('category') == $c->id)>{{ $c->name }}</option>@endforeach</select></div>
    <div class="col-auto"><button class="btn btn-outline-secondary">Filter</button></div>
</form>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th></th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Flags</th><th></th></tr></thead>
    <tbody>
    @forelse($products as $p)
        <tr>
            <td><img src="{{ $p->image_url }}" width="56" height="42" style="object-fit:cover;border-radius:4px" alt=""></td>
            <td class="fw-semibold">{{ $p->name }} @unless($p->is_active)<span class="badge text-bg-secondary">Hidden</span>@endunless</td>
            <td>{{ $p->category->name }}</td>
            <td>{{ naira($p->price) }}</td>
            <td>{{ $p->track_stock ? $p->stock_qty : $p->availability_label }}</td>
            <td>@if($p->is_featured)<span class="badge text-bg-primary">Featured</span>@endif @if($p->is_new)<span class="badge text-bg-danger">New</span>@endif @if($p->is_on_sale)<span class="badge" style="background:#F2DF00;color:#202020">Sale</span>@endif</td>
            <td class="text-end text-nowrap">
                <a class="btn btn-sm btn-outline-secondary" href="{{ route('admin.products.edit', $p) }}">Edit</a>
                <form class="d-inline" method="post" action="{{ route('admin.products.destroy', $p) }}" onsubmit="return confirm('Delete this product? This cannot be undone.')">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Delete</button></form>
            </td>
        </tr>
    @empty <tr><td colspan="7" class="text-center text-muted py-4">No products yet.</td></tr> @endforelse
    </tbody></table></div></div>
<div class="mt-3">{{ $products->links() }}</div>
@endsection
