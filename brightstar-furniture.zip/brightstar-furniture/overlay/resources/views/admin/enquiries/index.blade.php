@extends('layouts.admin')
@section('title', 'Enquiries')
@section('content')
<h1 class="h4 fw-bold mb-3">Enquiries</h1>
@forelse($enquiries as $e)
    <div class="card card-body mb-2 {{ $e->is_read ? '' : 'border-danger' }}">
        <div class="d-flex justify-content-between flex-wrap gap-2">
            <div><strong>{{ $e->name }}</strong>
                <span class="text-muted small">{{ collect([$e->email, $e->phone])->filter()->implode(' · ') }}</span>
                @unless($e->is_read)<span class="badge text-bg-danger">New</span>@endunless</div>
            <div class="small text-muted">{{ $e->created_at->format('d M Y, H:i') }}</div>
        </div>
        <p class="my-2">{!! nl2br(e($e->message)) !!}</p>
        <div class="d-flex gap-2">
            @unless($e->is_read)<form method="post" action="{{ route('admin.enquiries.read', $e) }}">@csrf @method('PATCH')<button class="btn btn-sm btn-outline-secondary">Mark as read</button></form>@endunless
            <form method="post" action="{{ route('admin.enquiries.destroy', $e) }}" onsubmit="return confirm('Delete this enquiry?')">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Delete</button></form>
        </div>
    </div>
@empty <p class="text-muted">No enquiries yet.</p> @endforelse
{{ $enquiries->links() }}
@endsection
