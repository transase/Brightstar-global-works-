@extends('layouts.admin')
@section('title', 'Dashboard')
@section('content')
<h1 class="h4 fw-bold mb-3">Dashboard</h1>
<div class="row g-3 mb-4">
    @foreach($stats as $label => $value)
        <div class="col-6 col-lg-2"><div class="stat"><div class="small text-muted">{{ $label }}</div><div class="n">{{ $value }}</div></div></div>
    @endforeach
</div>
<div class="card"><div class="card-header bg-white fw-bold">Recent orders</div>
<div class="table-responsive"><table class="table table-sm align-middle mb-0">
    <thead><tr><th>Order</th><th>Customer</th><th>Date</th><th class="text-end">Total</th><th>Status</th></tr></thead>
    <tbody>
    @forelse($recent as $o)
        <tr><td><a href="{{ route('admin.orders.show', $o) }}">{{ $o->order_number }}</a></td><td>{{ $o->customer_name }}</td>
            <td>{{ $o->created_at->format('d M Y, H:i') }}</td><td class="text-end">{{ naira($o->total) }}</td>
            <td><span class="badge text-bg-secondary">{{ $o->status_label }}</span></td></tr>
    @empty <tr><td colspan="5" class="text-center text-muted py-3">No orders yet.</td></tr> @endforelse
    </tbody></table></div></div>
@endsection
