<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Order extends Model
{
    public const STATUSES = [
        'pending' => 'Pending',
        'confirmed' => 'Confirmed',
        'processing' => 'Processing',
        'ready_for_delivery' => 'Ready for Delivery',
        'shipped' => 'Shipped / Out for Delivery',
        'delivered' => 'Delivered',
        'cancelled' => 'Cancelled',
    ];

    public const PAYMENT_STATUSES = [
        'unpaid' => 'Unpaid', 'paid' => 'Paid', 'failed' => 'Failed', 'refunded' => 'Refunded',
    ];

    protected $fillable = [
        'order_number', 'public_token', 'customer_name', 'phone', 'email', 'address', 'notes',
        'subtotal', 'delivery_charge', 'total', 'payment_method', 'payment_status', 'status',
    ];

    protected $casts = ['subtotal' => 'decimal:2', 'delivery_charge' => 'decimal:2', 'total' => 'decimal:2'];

    public function items() { return $this->hasMany(OrderItem::class); }
    public function payments() { return $this->hasMany(Payment::class); }

    public function getStatusLabelAttribute(): string { return self::STATUSES[$this->status] ?? $this->status; }
    public function getPaymentStatusLabelAttribute(): string { return self::PAYMENT_STATUSES[$this->payment_status] ?? $this->payment_status; }
    public function getPaymentMethodLabelAttribute(): string { return $this->payment_method === 'paystack' ? 'Online (Paystack)' : 'WhatsApp'; }

    public static function generateNumber(): string
    {
        do {
            $n = 'BSG-'.now()->format('ymd').'-'.strtoupper(Str::random(4));
        } while (static::where('order_number', $n)->exists());
        return $n;
    }
}
