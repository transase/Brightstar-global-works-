<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Product extends Model
{
    public const AVAILABILITY = [
        'in_stock' => 'In Stock',
        'made_to_order' => 'Made to Order',
        'out_of_stock' => 'Out of Stock',
    ];

    protected $fillable = [
        'category_id', 'name', 'slug', 'description', 'price', 'old_price', 'dimensions', 'material',
        'colours', 'sizes', 'availability', 'is_featured', 'is_new', 'is_on_sale', 'is_active',
        'track_stock', 'stock_qty', 'seo_title', 'seo_description',
    ];

    protected $casts = [
        'price' => 'decimal:2', 'old_price' => 'decimal:2',
        'is_featured' => 'boolean', 'is_new' => 'boolean', 'is_on_sale' => 'boolean',
        'is_active' => 'boolean', 'track_stock' => 'boolean',
    ];

    public function category() { return $this->belongsTo(Category::class); }
    public function images() { return $this->hasMany(ProductImage::class)->orderBy('sort_order')->orderBy('id'); }

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true)
            ->whereHas('category', fn ($c) => $c->where('is_active', true));
    }

    public function getImageUrlAttribute(): string
    {
        $img = $this->relationLoaded('images') ? $this->images->first() : $this->images()->first();
        return media_url($img?->path);
    }

    public function getHasDiscountAttribute(): bool
    {
        return $this->old_price !== null && (float) $this->old_price > (float) $this->price;
    }

    public function getDiscountPercentAttribute(): int
    {
        return $this->has_discount ? (int) round((1 - $this->price / $this->old_price) * 100) : 0;
    }

    public function getIsAvailableAttribute(): bool
    {
        if ($this->availability === 'out_of_stock') return false;
        if ($this->track_stock && $this->stock_qty < 1) return false;
        return true;
    }

    public function getAvailabilityLabelAttribute(): string
    {
        if (! $this->is_available) return self::AVAILABILITY['out_of_stock'];
        return self::AVAILABILITY[$this->availability] ?? 'In Stock';
    }

    public function getColourListAttribute(): array { return self::splitList($this->colours); }
    public function getSizeListAttribute(): array { return self::splitList($this->sizes); }

    public static function splitList(?string $v): array
    {
        return collect(explode(',', (string) $v))->map(fn ($s) => trim($s))->filter()->unique()->values()->all();
    }

    public static function uniqueSlug(string $name, ?int $ignoreId = null): string
    {
        $base = Str::slug($name) ?: 'product';
        $slug = $base; $i = 2;
        while (static::where('slug', $slug)->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))->exists()) {
            $slug = $base.'-'.$i++;
        }
        return $slug;
    }
}
