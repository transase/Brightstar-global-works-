<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class Paystack
{
    private const API = 'https://api.paystack.co';

    public static function secretKey(): ?string
    {
        $stored = setting('paystack_secret_key');
        if ($stored) {
            try { return Crypt::decryptString($stored); } catch (\Throwable) { /* fall through */ }
        }
        return config('services.paystack.secret') ?: null;
    }

    public static function publicKey(): ?string
    {
        return setting('paystack_public_key') ?: (config('services.paystack.public') ?: null);
    }

    public static function enabled(): bool
    {
        return setting('payments_enabled', '0') === '1' && self::secretKey() !== null;
    }

    /** Create a pending payment and ask Paystack for a checkout URL. Returns the authorization URL. */
    public function initialize(Order $order): string
    {
        $reference = 'BSG'.strtoupper(Str::random(14));

        $res = Http::withToken(self::secretKey())->acceptJson()->timeout(20)
            ->post(self::API.'/transaction/initialize', [
                'email' => $order->email,
                'amount' => (int) round($order->total * 100), // kobo
                'currency' => 'NGN',
                'reference' => $reference,
                'callback_url' => route('paystack.callback'),
                'metadata' => ['order_number' => $order->order_number],
            ]);

        if (! $res->successful() || ! data_get($res->json(), 'data.authorization_url')) {
            throw new \RuntimeException('Could not start the online payment. Please try again or order via WhatsApp.');
        }

        Payment::create([
            'order_id' => $order->id, 'gateway' => 'paystack', 'reference' => $reference,
            'amount' => $order->total, 'currency' => 'NGN', 'status' => 'pending',
        ]);

        return $res->json('data.authorization_url');
    }

    /** Server-side verification against Paystack. Returns the `data` array or null on failure. */
    public function verify(string $reference): ?array
    {
        $res = Http::withToken(self::secretKey())->acceptJson()->timeout(20)
            ->get(self::API.'/transaction/verify/'.urlencode($reference));

        if (! $res->successful() || $res->json('status') !== true) return null;
        return $res->json('data');
    }

    public static function validSignature(string $rawBody, ?string $signature): bool
    {
        $secret = self::secretKey();
        if (! $secret || ! $signature) return false;
        return hash_equals(hash_hmac('sha512', $rawBody, $secret), $signature);
    }

    /**
     * Verify with Paystack and, only if everything matches, mark payment + order paid.
     * Idempotent. Returns the Payment.
     */
    public function settle(string $reference): ?Payment
    {
        $payment = Payment::where('reference', $reference)->where('gateway', 'paystack')->first();
        if (! $payment) return null;
        if ($payment->status === 'success') return $payment;

        $data = $this->verify($reference);

        return DB::transaction(function () use ($payment, $data) {
            $payment = Payment::whereKey($payment->id)->lockForUpdate()->first();
            if ($payment->status === 'success') return $payment;

            $ok = $data
                && ($data['status'] ?? null) === 'success'
                && ($data['currency'] ?? 'NGN') === $payment->currency
                && (int) ($data['amount'] ?? 0) === (int) round($payment->amount * 100);

            if ($ok) {
                $payment->update(['status' => 'success', 'paid_at' => now(), 'gateway_response' => $data]);
                $payment->order()->update(['payment_status' => 'paid']);
            } elseif ($data && in_array($data['status'] ?? null, ['failed', 'reversed'], true)) {
                $payment->update(['status' => 'failed', 'gateway_response' => $data]);
                $payment->order()->where('payment_status', '!=', 'paid')->update(['payment_status' => 'failed']);
            }
            return $payment->fresh();
        });
    }
}
