<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Product;
use App\Models\StockMovement;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class OrderService
{
    /**
     * Create an order from cart lines. Prices/names are snapshotted.
     * Throws ValidationException when an item is unavailable / short on stock.
     */
    public function create(array $customer, Collection $lines, string $method): Order
    {
        return DB::transaction(function () use ($customer, $lines, $method) {
            // Lock rows and re-check availability.
            $products = Product::whereIn('id', $lines->pluck('product.id'))->lockForUpdate()->get()->keyBy('id');
            $needed = $lines->groupBy('product.id')->map(fn ($g) => $g->sum('qty'));

            foreach ($needed as $pid => $qty) {
                $p = $products[$pid] ?? null;
                if (! $p || ! $p->is_active || $p->availability === 'out_of_stock'
                    || ($p->track_stock && $p->stock_qty < $qty)) {
                    throw ValidationException::withMessages([
                        'cart' => ($p->name ?? 'An item').' is no longer available in the quantity requested. Please update your cart.',
                    ]);
                }
            }

            $subtotal = round($lines->sum(fn ($l) => $products[$l->product->id]->price * $l->qty), 2);
            $delivery = round((float) setting('delivery_fee', 0), 2);

            $order = Order::create([
                'order_number' => Order::generateNumber(),
                'public_token' => Str::random(40),
                'customer_name' => $customer['customer_name'],
                'phone' => $customer['phone'],
                'email' => $customer['email'] ?? null,
                'address' => $customer['address'],
                'notes' => $customer['notes'] ?? null,
                'subtotal' => $subtotal,
                'delivery_charge' => $delivery,
                'total' => $subtotal + $delivery,
                'payment_method' => $method,
                'payment_status' => 'unpaid',
                'status' => 'pending',
            ]);

            foreach ($lines as $l) {
                $p = $products[$l->product->id];
                $order->items()->create([
                    'product_id' => $p->id,
                    'product_name' => $p->name,
                    'colour' => $l->colour, 'size' => $l->size,
                    'unit_price' => $p->price,
                    'quantity' => $l->qty,
                    'line_total' => round($p->price * $l->qty, 2),
                ]);
            }

            foreach ($needed as $pid => $qty) {
                $p = $products[$pid];
                if ($p->track_stock) {
                    $p->decrement('stock_qty', $qty);
                    StockMovement::create(['product_id' => $pid, 'order_id' => $order->id, 'change' => -$qty, 'reason' => 'Order '.$order->order_number]);
                }
            }

            return $order;
        });
    }

    /** Cancel an order and return stock (only once). */
    public function cancel(Order $order, string $reason = 'Order cancelled'): void
    {
        DB::transaction(function () use ($order, $reason) {
            $order = Order::whereKey($order->id)->lockForUpdate()->first();
            if ($order->status === 'cancelled') return;

            foreach ($order->items as $item) {
                $p = $item->product_id ? Product::lockForUpdate()->find($item->product_id) : null;
                if ($p && $p->track_stock) {
                    $p->increment('stock_qty', $item->quantity);
                    StockMovement::create(['product_id' => $p->id, 'order_id' => $order->id, 'change' => $item->quantity, 'reason' => $reason.' '.$order->order_number]);
                }
            }
            $order->update(['status' => 'cancelled']);
        });
    }
}
