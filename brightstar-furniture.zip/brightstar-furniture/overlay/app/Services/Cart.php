<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Collection;

/** Session-based shopping cart. */
class Cart
{
    private const KEY = 'cart';

    private function raw(): array { return session()->get(self::KEY, []); }

    public static function lineKey(int $productId, ?string $colour, ?string $size): string
    {
        return md5($productId.'|'.$colour.'|'.$size);
    }

    public function add(Product $product, int $qty, ?string $colour = null, ?string $size = null): void
    {
        $cart = $this->raw();
        $key = self::lineKey($product->id, $colour, $size);
        $existing = $cart[$key]['qty'] ?? 0;
        $cart[$key] = ['product_id' => $product->id, 'qty' => min(99, $existing + max(1, $qty)), 'colour' => $colour, 'size' => $size];
        session()->put(self::KEY, $cart);
    }

    public function update(string $key, int $qty): void
    {
        $cart = $this->raw();
        if (! isset($cart[$key])) return;
        if ($qty < 1) { unset($cart[$key]); } else { $cart[$key]['qty'] = min(99, $qty); }
        session()->put(self::KEY, $cart);
    }

    public function remove(string $key): void
    {
        $cart = $this->raw();
        unset($cart[$key]);
        session()->put(self::KEY, $cart);
    }

    public function clear(): void { session()->forget(self::KEY); }

    public function count(): int
    {
        return (int) collect($this->raw())->sum('qty');
    }

    /**
     * Cart lines with live product data. Inactive / deleted products are skipped.
     * @return Collection<int, object{key:string,product:Product,qty:int,colour:?string,size:?string,unit_price:float,line_total:float}>
     */
    public function lines(): Collection
    {
        $raw = $this->raw();
        if (! $raw) return collect();

        $products = Product::active()->with('images')
            ->whereIn('id', collect($raw)->pluck('product_id'))->get()->keyBy('id');

        return collect($raw)->map(function ($row, $key) use ($products) {
            $p = $products->get($row['product_id']);
            if (! $p) return null;
            $unit = (float) $p->price;
            return (object) [
                'key' => $key, 'product' => $p, 'qty' => (int) $row['qty'],
                'colour' => $row['colour'] ?? null, 'size' => $row['size'] ?? null,
                'unit_price' => $unit, 'line_total' => round($unit * (int) $row['qty'], 2),
            ];
        })->filter()->values();
    }

    public function subtotal(): float
    {
        return round($this->lines()->sum('line_total'), 2);
    }
}
