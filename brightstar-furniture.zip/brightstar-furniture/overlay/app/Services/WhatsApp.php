<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Product;

class WhatsApp
{
    /** Normalise a Nigerian number to international digits (e.g. 08012345678 -> 2348012345678). */
    public static function number(): string
    {
        $n = preg_replace('/\D+/', '', (string) setting('whatsapp', ''));
        if ($n === '') return '';
        if (str_starts_with($n, '0')) $n = '234'.substr($n, 1);
        return $n;
    }

    public static function url(string $message): string
    {
        $n = self::number();
        $base = $n !== '' ? "https://wa.me/{$n}" : 'https://wa.me/';
        return $base.'?text='.rawurlencode($message);
    }

    private static function company(): string { return (string) setting('company_name', 'BRIGHTSTAR GLOBAL FURNITURE'); }

    public static function general(): string
    {
        return self::url('Hello '.self::company().', I would like to make an enquiry.');
    }

    public static function forProduct(Product $p, int $qty = 1): string
    {
        $msg = 'Hello '.self::company().", I would like to order the following item:\n\n"
            ."Product: {$p->name}\nQuantity: {$qty}\nPrice: ".naira($p->price)."\n\n"
            .'Total: '.naira($p->price * $qty)."\n\n"
            .'Please confirm availability, delivery charges and payment details.';
        return self::url($msg);
    }

    public static function forOrder(Order $order): string
    {
        $order->loadMissing('items');
        $msg = 'Hello '.self::company().", I would like to order the following items:\n\n";
        foreach ($order->items as $i) {
            $msg .= "Product: {$i->product_name}\n";
            if ($i->colour) $msg .= "Colour: {$i->colour}\n";
            if ($i->size) $msg .= "Size: {$i->size}\n";
            $msg .= "Quantity: {$i->quantity}\nPrice: ".naira($i->unit_price)."\n\n";
        }
        $msg .= 'Total: '.naira($order->total)."\n";
        $msg .= "Order No: {$order->order_number}\n\n";
        $msg .= "Name: {$order->customer_name}\nPhone: {$order->phone}\n";
        if ($order->email) $msg .= "Email: {$order->email}\n";
        $msg .= "Delivery address: {$order->address}\n";
        if ($order->notes) $msg .= "Notes: {$order->notes}\n";
        $msg .= "\nPlease confirm availability, delivery charges and payment details.";
        return self::url($msg);
    }
}
