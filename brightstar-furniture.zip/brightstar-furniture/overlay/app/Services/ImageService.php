<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/** Validates, resizes and re-encodes uploaded images (strips metadata, shrinks mobile-data cost). */
class ImageService
{
    public function store(UploadedFile $file, string $dir, int $maxSide = 1400): string
    {
        $path = $file->getRealPath();
        $info = @getimagesize($path);
        if (! $info || ! function_exists('imagecreatetruecolor')) {
            // No GD or unreadable: fall back to Laravel's safe store (validation already checked mime).
            return $file->store($dir, 'public');
        }

        $src = match ($info[2]) {
            IMAGETYPE_JPEG => @imagecreatefromjpeg($path),
            IMAGETYPE_PNG => @imagecreatefrompng($path),
            IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : false,
            default => false,
        };
        if (! $src) return $file->store($dir, 'public');

        [$w, $h] = [imagesx($src), imagesy($src)];
        $scale = min(1, $maxSide / max($w, $h));
        $nw = max(1, (int) round($w * $scale)); $nh = max(1, (int) round($h * $scale));

        $dst = imagecreatetruecolor($nw, $nh);
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 255, 255, 255, 127));
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);

        ob_start();
        if (function_exists('imagewebp')) { imagewebp($dst, null, 82); $ext = 'webp'; }
        else { imagejpeg($dst, null, 85); $ext = 'jpg'; }
        $data = ob_get_clean();

        $name = trim($dir, '/').'/'.Str::random(40).'.'.$ext;
        Storage::disk('public')->put($name, $data);
        return $name;
    }

    public function delete(?string $path): void
    {
        if ($path) Storage::disk('public')->delete($path);
    }
}
