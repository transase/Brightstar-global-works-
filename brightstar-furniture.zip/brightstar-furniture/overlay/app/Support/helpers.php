<?php

use App\Models\Setting;

if (! function_exists('setting')) {
    function setting(string $key, $default = null)
    {
        return Setting::get($key, $default);
    }
}

if (! function_exists('naira')) {
    function naira($amount): string
    {
        $amount = (float) $amount;
        $symbol = setting('currency_symbol', '₦');
        return $symbol.number_format($amount, fmod($amount, 1) == 0.0 ? 0 : 2);
    }
}

if (! function_exists('media_url')) {
    /** Public URL for an uploaded file (or fallback). */
    function media_url(?string $path, string $fallback = 'images/placeholder.svg'): string
    {
        return $path ? asset('storage/'.$path) : asset($fallback);
    }
}
