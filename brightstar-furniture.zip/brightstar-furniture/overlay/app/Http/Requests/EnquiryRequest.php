<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EnquiryRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:120'],
            'email' => ['nullable', 'required_without:phone', 'email:rfc', 'max:150'],
            'phone' => ['nullable', 'required_without:email', 'string', 'max:30'],
            'message' => ['required', 'string', 'max:3000'],
        ];
    }
}
