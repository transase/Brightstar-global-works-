<?php

namespace App\Http\Controllers;

use App\Services\Cart;
use App\Services\Paystack;
use Illuminate\Http\Request;

class PaystackController extends Controller
{
    /** Browser return. Never trusted: we verify with Paystack server-side before showing "paid". */
    public function callback(Request $request, Paystack $paystack, Cart $cart)
    {
        $reference = (string) ($request->query('reference') ?: $request->query('trxref'));
        abort_if($reference === '', 404);

        $payment = $paystack->settle($reference);
        abort_unless($payment, 404);

        if ($payment->status === 'success') {
            $cart->clear();
        }

        return redirect()->route('order.thanks', $payment->order->public_token);
    }

    /** Server-to-server webhook, authenticated by HMAC-SHA512 signature. */
    public function webhook(Request $request, Paystack $paystack)
    {
        if (! Paystack::validSignature($request->getContent(), $request->header('x-paystack-signature'))) {
            return response('Invalid signature', 401);
        }

        $event = $request->json('event');
        $reference = $request->json('data.reference');

        if ($event === 'charge.success' && $reference) {
            $paystack->settle($reference); // re-verifies with Paystack before marking paid
        }

        return response('OK', 200);
    }
}
