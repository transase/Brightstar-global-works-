<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Support\Facades\Cache;

class SeoController extends Controller
{
    public function sitemap()
    {
        $xml = Cache::remember('sitemap.xml', 3600, function () {
            $urls = [[url('/'), null], [route('shop'), null], [route('about'), null], [route('contact'), null]];
            foreach (Category::active()->get() as $c) $urls[] = [route('category', $c->slug), $c->updated_at];
            foreach (Product::active()->get(['slug', 'updated_at']) as $p) $urls[] = [route('product', $p->slug), $p->updated_at];

            $out = '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
            foreach ($urls as [$loc, $mod]) {
                $out .= '  <url><loc>'.e($loc).'</loc>'.($mod ? '<lastmod>'.$mod->toAtomString().'</lastmod>' : '').'</url>'."\n";
            }
            return $out.'</urlset>';
        });

        return response($xml, 200, ['Content-Type' => 'application/xml']);
    }

    public function robots()
    {
        $txt = "User-agent: *\nDisallow: /admin\nDisallow: /cart\nAllow: /\n\nSitemap: ".url('/sitemap.xml')."\n";
        return response($txt, 200, ['Content-Type' => 'text/plain']);
    }
}
