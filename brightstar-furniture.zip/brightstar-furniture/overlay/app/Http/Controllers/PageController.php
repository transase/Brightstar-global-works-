<?php

namespace App\Http\Controllers;

use App\Http\Requests\EnquiryRequest;
use App\Models\Enquiry;

class PageController extends Controller
{
    public function about() { return view('pages.about'); }
    public function contact() { return view('pages.contact'); }
    public function privacy() { return view('pages.policy', ['title' => 'Privacy Policy', 'body' => setting('privacy_policy')]); }
    public function terms() { return view('pages.policy', ['title' => 'Terms and Conditions', 'body' => setting('terms')]); }

    public function enquiry(EnquiryRequest $request)
    {
        // Honeypot: bots fill the hidden field.
        if ($request->filled('website')) {
            return back()->with('success', 'Thank you! We will get back to you shortly.');
        }
        Enquiry::create($request->validated());
        return back()->with('success', 'Thank you! We will get back to you shortly.');
    }
}
