<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;

class HomeController extends Controller
{
    public function index()
    {
        $card = fn () => Product::active()->with('images');

        return view('home', [
            'categories' => Category::active()->get(),
            'featured' => $card()->where('is_featured', true)->latest()->take(8)->get(),
            // Recently added products, automatically (admin "New" flag only adds a badge / forces inclusion).
            'newArrivals' => $card()->orderByDesc('is_new')->latest('id')->take(8)->get(),
            'offers' => $card()->where('is_on_sale', true)->latest()->take(8)->get(),
        ]);
    }
}
