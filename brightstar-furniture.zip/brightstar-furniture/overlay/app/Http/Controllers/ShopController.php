<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function index(Request $request, ?Category $category = null)
    {
        $request->validate([
            'q' => ['nullable', 'string', 'max:100'],
            'category' => ['nullable', 'string', 'max:150'],
            'min_price' => ['nullable', 'numeric', 'min:0'],
            'max_price' => ['nullable', 'numeric', 'min:0'],
            'sort' => ['nullable', 'in:newest,price_asc,price_desc'],
        ]);

        $categories = Category::active()->get();
        $activeCategory = $category ?: $categories->firstWhere('slug', $request->query('category'));

        $products = Product::active()->with('images')
            ->when($request->filled('q'), fn ($q) => $q->where('name', 'like', '%'.addcslashes($request->q, '%_\\').'%'))
            ->when($activeCategory, fn ($q) => $q->where('category_id', $activeCategory->id))
            ->when($request->filled('min_price'), fn ($q) => $q->where('price', '>=', $request->min_price))
            ->when($request->filled('max_price'), fn ($q) => $q->where('price', '<=', $request->max_price))
            ->when($request->sort === 'price_asc', fn ($q) => $q->orderBy('price'))
            ->when($request->sort === 'price_desc', fn ($q) => $q->orderByDesc('price'))
            ->when(! in_array($request->sort, ['price_asc', 'price_desc']), fn ($q) => $q->latest('id'))
            ->paginate(12)->withQueryString();

        return view('shop.index', compact('products', 'categories', 'activeCategory'));
    }

    public function show(string $slug)
    {
        $product = Product::active()->with(['images', 'category'])->where('slug', $slug)->firstOrFail();

        $related = Product::active()->with('images')
            ->where('category_id', $product->category_id)->where('id', '!=', $product->id)
            ->inRandomOrder()->take(4)->get();

        return view('shop.show', compact('product', 'related'));
    }
}
