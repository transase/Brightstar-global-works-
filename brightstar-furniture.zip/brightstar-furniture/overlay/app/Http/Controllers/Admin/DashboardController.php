<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;

class DashboardController extends Controller
{
    public function index()
    {
        return view('admin.dashboard', [
            'stats' => [
                'Total products' => Product::count(),
                'Total categories' => Category::count(),
                'Total orders' => Order::count(),
                'Pending orders' => Order::where('status', 'pending')->count(),
                'Completed orders' => Order::where('status', 'delivered')->count(),
                'Sales (verified payments)' => naira(Payment::where('status', 'success')->sum('amount')),
            ],
            'recent' => Order::latest()->take(8)->get(),
        ]);
    }
}
