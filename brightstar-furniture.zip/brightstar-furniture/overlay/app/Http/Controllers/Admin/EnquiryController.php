<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Enquiry;

class EnquiryController extends Controller
{
    public function index() { return view('admin.enquiries.index', ['enquiries' => Enquiry::latest()->paginate(20)]); }

    public function markRead(Enquiry $enquiry)
    {
        $enquiry->update(['is_read' => true]);
        return back();
    }

    public function destroy(Enquiry $enquiry)
    {
        $enquiry->delete();
        return back()->with('success', 'Enquiry deleted.');
    }
}
