<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ProductRequest;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use App\Services\ImageService;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function __construct(private ImageService $images) {}

    public function index(Request $request)
    {
        $products = Product::with(['category', 'images'])
            ->when($request->filled('q'), fn ($q) => $q->where('name', 'like', '%'.addcslashes($request->q, '%_\\').'%'))
            ->when($request->filled('category'), fn ($q) => $q->where('category_id', $request->category))
            ->latest('id')->paginate(15)->withQueryString();

        return view('admin.products.index', ['products' => $products, 'categories' => Category::orderBy('name')->get()]);
    }

    public function create()
    {
        return view('admin.products.form', ['product' => new Product(['availability' => 'in_stock', 'is_active' => true]), 'categories' => Category::orderBy('name')->get()]);
    }

    public function store(ProductRequest $request)
    {
        $product = Product::create($this->payload($request) + ['slug' => Product::uniqueSlug($request->name)]);
        $this->saveImages($request, $product);
        return redirect()->route('admin.products.index')->with('success', 'Product created.');
    }

    public function edit(Product $product)
    {
        $product->load('images');
        return view('admin.products.form', ['product' => $product, 'categories' => Category::orderBy('name')->get()]);
    }

    public function update(ProductRequest $request, Product $product)
    {
        $product->update($this->payload($request) + [
            'slug' => $product->name === $request->name ? $product->slug : Product::uniqueSlug($request->name, $product->id),
        ]);
        $this->saveImages($request, $product);
        return redirect()->route('admin.products.index')->with('success', 'Product updated.');
    }

    public function destroy(Product $product)
    {
        // Order items keep their own name/price snapshot (product_id becomes NULL), so orders stay intact.
        foreach ($product->images as $img) $this->images->delete($img->path);
        $product->delete();
        return redirect()->route('admin.products.index')->with('success', 'Product deleted.');
    }

    public function destroyImage(Product $product, ProductImage $image)
    {
        abort_unless($image->product_id === $product->id, 404);
        $this->images->delete($image->path);
        $image->delete();
        return back()->with('success', 'Image removed.');
    }

    private function payload(ProductRequest $request): array
    {
        $d = $request->safe()->except(['images', 'image_alt']);
        $d['is_featured'] = $request->boolean('is_featured');
        $d['is_new'] = $request->boolean('is_new');
        $d['is_on_sale'] = $request->boolean('is_on_sale');
        $d['is_active'] = $request->boolean('is_active');
        $d['track_stock'] = $request->boolean('track_stock');
        $d['stock_qty'] = (int) ($d['stock_qty'] ?? 0);
        // Keep the "on sale" flag meaningful: needs an old price to show a discount.
        return $d;
    }

    private function saveImages(ProductRequest $request, Product $product): void
    {
        $order = (int) $product->images()->max('sort_order');
        foreach ((array) $request->file('images') as $file) {
            $product->images()->create([
                'path' => $this->images->store($file, 'products'),
                'alt' => $request->input('image_alt') ?: $product->name,
                'sort_order' => ++$order,
            ]);
        }
    }
}
