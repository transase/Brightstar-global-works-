<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Services\ImageService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class SettingController extends Controller
{
    public const TEXT_FIELDS = [
        'company_name', 'company_description', 'phone', 'whatsapp', 'email', 'address', 'business_hours',
        'maps_embed_url', 'facebook', 'instagram', 'twitter', 'tiktok',
        'hero_title', 'hero_subtitle', 'hero_btn1_text', 'hero_btn2_text', 'promo_banner_text', 'promo_banner_link',
        'currency_symbol', 'paystack_public_key', 'delivery_fee', 'delivery_info', 'footer_text',
        'seo_title', 'seo_description', 'about_title', 'about_body', 'about_values', 'privacy_policy', 'terms',
    ];
    public const FILE_FIELDS = ['logo', 'favicon', 'hero_image', 'about_image'];

    public function edit() { return view('admin.settings.edit'); }

    public function update(Request $request, ImageService $images)
    {
        $request->validate([
            'company_name' => ['required', 'string', 'max:150'],
            'email' => ['nullable', 'email', 'max:150'],
            'phone' => ['nullable', 'string', 'max:40'],
            'whatsapp' => ['nullable', 'string', 'max:20', 'regex:/^[0-9+\s\-()]{7,20}$/'],
            'delivery_fee' => ['nullable', 'numeric', 'min:0', 'max:100000000'],
            'currency_symbol' => ['nullable', 'string', 'max:5'],
            'facebook' => ['nullable', 'url', 'max:255'], 'instagram' => ['nullable', 'url', 'max:255'],
            'twitter' => ['nullable', 'url', 'max:255'], 'tiktok' => ['nullable', 'url', 'max:255'],
            'promo_banner_link' => ['nullable', 'string', 'max:255'],
            'maps_embed_url' => ['nullable', 'url', 'max:1000', 'regex:#^https://(www\.google\.com|maps\.google\.com)/maps#'],
            'paystack_public_key' => ['nullable', 'string', 'max:120'],
            'paystack_secret_key' => ['nullable', 'string', 'max:120'],
            'seo_description' => ['nullable', 'string', 'max:300'],
            'logo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:3072'],
            'favicon' => ['nullable', 'file', 'mimes:png,ico,jpg,jpeg,webp', 'max:512'],
            'hero_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:6144'],
            'about_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:6144'],
        ]);

        $values = [];
        foreach (self::TEXT_FIELDS as $f) {
            $values[$f] = $request->input($f);
        }
        $values['payments_enabled'] = $request->boolean('payments_enabled') ? '1' : '0';

        // Secret key: only replace when a new value is supplied; stored encrypted.
        if ($request->filled('paystack_secret_key')) {
            $values['paystack_secret_key'] = Crypt::encryptString($request->input('paystack_secret_key'));
        }

        foreach (self::FILE_FIELDS as $f) {
            if ($request->hasFile($f)) {
                $images->delete(setting($f));
                $values[$f] = $f === 'favicon'
                    ? $request->file($f)->store('branding', 'public')
                    : $images->store($request->file($f), 'branding', $f === 'logo' ? 600 : 1800);
            }
        }

        Setting::putMany($values);
        return back()->with('success', 'Settings saved.');
    }

    public function password(Request $request)
    {
        $data = $request->validate([
            'current_password' => ['required', 'current_password'],
            'password' => ['required', 'confirmed', Password::min(10)->letters()->numbers()],
        ]);
        $request->user()->forceFill(['password' => Hash::make($data['password'])])->save();
        return back()->with('success', 'Password changed.');
    }
}
