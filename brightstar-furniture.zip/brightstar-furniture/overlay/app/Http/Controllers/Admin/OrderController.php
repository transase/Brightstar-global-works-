<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $request->validate([
            'status' => ['nullable', Rule::in(array_keys(Order::STATUSES))],
            'payment_status' => ['nullable', Rule::in(array_keys(Order::PAYMENT_STATUSES))],
            'from' => ['nullable', 'date'], 'to' => ['nullable', 'date'], 'q' => ['nullable', 'string', 'max:100'],
        ]);

        $orders = Order::query()
            ->when($request->filled('q'), function ($q) use ($request) {
                $term = '%'.addcslashes($request->q, '%_\\').'%';
                $q->where(fn ($w) => $w->where('order_number', 'like', $term)->orWhere('customer_name', 'like', $term)
                    ->orWhere('phone', 'like', $term)->orWhere('email', 'like', $term));
            })
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->status))
            ->when($request->filled('payment_status'), fn ($q) => $q->where('payment_status', $request->payment_status))
            ->when($request->filled('from'), fn ($q) => $q->whereDate('created_at', '>=', $request->from))
            ->when($request->filled('to'), fn ($q) => $q->whereDate('created_at', '<=', $request->to))
            ->latest()->paginate(20)->withQueryString();

        return view('admin.orders.index', compact('orders'));
    }

    public function show(Order $order)
    {
        $order->load(['items', 'payments']);
        return view('admin.orders.show', compact('order'));
    }

    public function receipt(Order $order)
    {
        $order->load('items');
        return view('admin.orders.receipt', compact('order'));
    }

    public function updateStatus(Request $request, Order $order, OrderService $orders)
    {
        $data = $request->validate(['status' => ['required', Rule::in(array_keys(Order::STATUSES))]]);

        if ($order->status === 'cancelled' && $data['status'] !== 'cancelled') {
            return back()->withErrors(['status' => 'A cancelled order cannot be reopened. Ask the customer to place a new order.']);
        }

        if ($data['status'] === 'cancelled') {
            $orders->cancel($order, 'Order cancelled');
        } else {
            $order->update(['status' => $data['status']]);
        }
        return back()->with('success', 'Order status updated.');
    }

    /** Payment status is separate from order status. Manual "paid" is recorded as an admin-verified payment. */
    public function updatePayment(Request $request, Order $order)
    {
        $data = $request->validate(['payment_status' => ['required', Rule::in(array_keys(Order::PAYMENT_STATUSES))]]);

        if ($data['payment_status'] === 'paid' && $order->payment_status !== 'paid') {
            $order->payments()->firstOrCreate(
                ['reference' => 'MANUAL-'.$order->order_number],
                ['gateway' => 'manual', 'amount' => $order->total, 'currency' => 'NGN', 'status' => 'success', 'paid_at' => now()]
            );
        }
        if ($data['payment_status'] !== 'paid') {
            // Anything no longer "paid" must not count towards verified sales.
            $order->payments()->where('gateway', 'manual')->where('status', 'success')->update(['status' => 'failed']);
        }

        $order->update(['payment_status' => $data['payment_status']]);
        return back()->with('success', 'Payment status updated.');
    }
}
