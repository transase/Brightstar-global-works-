<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Models\Category;
use App\Services\ImageService;

class CategoryController extends Controller
{
    public function __construct(private ImageService $images) {}

    public function index()
    {
        return view('admin.categories.index', ['categories' => Category::withCount('products')->orderBy('sort_order')->orderBy('name')->get()]);
    }

    public function create() { return view('admin.categories.form', ['category' => new Category(['is_active' => true, 'sort_order' => 0])]); }

    public function store(CategoryRequest $request)
    {
        $data = $request->safe()->except('image');
        $data['slug'] = Category::uniqueSlug($request->name);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);
        $data['is_active'] = $request->boolean('is_active');
        if ($request->hasFile('image')) $data['image'] = $this->images->store($request->file('image'), 'categories', 900);
        Category::create($data);
        return redirect()->route('admin.categories.index')->with('success', 'Category created.');
    }

    public function edit(Category $category) { return view('admin.categories.form', compact('category')); }

    public function update(CategoryRequest $request, Category $category)
    {
        $data = $request->safe()->except('image');
        $data['slug'] = $category->name === $request->name ? $category->slug : Category::uniqueSlug($request->name, $category->id);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);
        $data['is_active'] = $request->boolean('is_active');
        if ($request->hasFile('image')) {
            $this->images->delete($category->image);
            $data['image'] = $this->images->store($request->file('image'), 'categories', 900);
        }
        $category->update($data);
        return redirect()->route('admin.categories.index')->with('success', 'Category updated.');
    }

    public function destroy(Category $category)
    {
        if ($category->products()->exists()) {
            return back()->withErrors(['category' => 'This category still has products. Move or delete them first, or deactivate the category instead.']);
        }
        $this->images->delete($category->image);
        $category->delete();
        return redirect()->route('admin.categories.index')->with('success', 'Category deleted.');
    }
}
