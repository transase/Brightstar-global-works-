<?php

namespace App\Http\Controllers;

use App\Http\Requests\CheckoutRequest;
use App\Models\Order;
use App\Models\Product;
use App\Services\Cart;
use App\Services\OrderService;
use App\Services\Paystack;
use App\Services\WhatsApp;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class CartController extends Controller
{
    public function __construct(private Cart $cart) {}

    public function index()
    {
        return view('cart.index', [
            'lines' => $this->cart->lines(),
            'subtotal' => $this->cart->subtotal(),
            'deliveryFee' => (float) setting('delivery_fee', 0),
            'paystackEnabled' => Paystack::enabled(),
        ]);
    }

    public function add(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer'],
            'qty' => ['nullable', 'integer', 'min:1', 'max:99'],
            'colour' => ['nullable', 'string', 'max:60'],
            'size' => ['nullable', 'string', 'max:60'],
        ]);

        $product = Product::active()->findOrFail($data['product_id']);

        if (! $product->is_available) {
            return back()->withErrors(['cart' => 'Sorry, this product is currently unavailable.']);
        }
        if ($product->colour_list && ! in_array($data['colour'] ?? null, $product->colour_list, true)) {
            return back()->withErrors(['colour' => 'Please choose a colour.'])->withInput();
        }
        if ($product->size_list && ! in_array($data['size'] ?? null, $product->size_list, true)) {
            return back()->withErrors(['size' => 'Please choose a size.'])->withInput();
        }

        $this->cart->add($product, (int) ($data['qty'] ?? 1), $data['colour'] ?? null, $data['size'] ?? null);

        return redirect()->route('cart.index')->with('success', $product->name.' added to your cart.');
    }

    public function update(Request $request)
    {
        $data = $request->validate(['key' => ['required', 'string'], 'qty' => ['required', 'integer', 'min:0', 'max:99']]);
        $this->cart->update($data['key'], (int) $data['qty']);
        return redirect()->route('cart.index');
    }

    public function remove(Request $request)
    {
        $this->cart->remove($request->validate(['key' => ['required', 'string']])['key']);
        return redirect()->route('cart.index');
    }

    public function checkout(CheckoutRequest $request, OrderService $orders, Paystack $paystack)
    {
        $lines = $this->cart->lines();
        if ($lines->isEmpty()) {
            return redirect()->route('cart.index')->withErrors(['cart' => 'Your cart is empty.']);
        }

        $method = $request->validated('method');
        if ($method === 'paystack' && ! Paystack::enabled()) {
            return back()->withInput()->withErrors(['method' => 'Online payment is currently unavailable. Please order via WhatsApp.']);
        }

        try {
            $order = $orders->create($request->safe()->except('method'), $lines, $method);
        } catch (ValidationException $e) {
            return back()->withInput()->withErrors($e->errors());
        }

        if ($method === 'whatsapp') {
            $this->cart->clear();
            return redirect()->away(WhatsApp::forOrder($order));
        }

        try {
            $url = $paystack->initialize($order);
        } catch (\Throwable $e) {
            report($e);
            $orders->cancel($order, 'Payment could not start');
            return back()->withInput()->withErrors(['method' => 'Could not start the online payment. Please try again or order via WhatsApp.']);
        }

        return redirect()->away($url);
    }

    public function thanks(string $token)
    {
        $order = Order::with('items')->where('public_token', $token)->firstOrFail();
        return view('cart.thanks', ['order' => $order, 'waUrl' => WhatsApp::forOrder($order)]);
    }
}
