<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $names = [
            'Sofas and Living Room Furniture', 'Beds and Bedroom Furniture', 'Dining Tables and Chairs',
            'Wardrobes and Storage', 'Office Furniture', 'TV Stands and Consoles', 'Centre Tables',
            'Outdoor Furniture', 'Other Furniture',
        ];
        foreach ($names as $i => $name) {
            Category::firstOrCreate(['slug' => \Illuminate\Support\Str::slug($name)], ['name' => $name, 'sort_order' => $i + 1, 'is_active' => true]);
        }
    }
}
