<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;

/** SAMPLE DATA ONLY: placeholder pictures, fictional prices. Replace from the admin panel. */
class DemoProductSeeder extends Seeder
{
    public function run(): void
    {
        $cat = fn ($name) => Category::where('name', 'like', $name.'%')->value('id');

        $items = [
            ['Modern 3-Seater Sofa', 'Sofas', 350000, 420000, 'Comfortable 3-seater with soft cushions.', '210cm x 90cm x 85cm', 'Fabric, wood frame', 'Grey, Cream', null, true, true, true],
            ['L-Shaped Sectional Sofa', 'Sofas', 620000, null, 'Spacious sectional for large living rooms.', '280cm x 200cm', 'Leather-look upholstery', 'Brown, Black', null, true, false, false],
            ['Queen Size Bed Frame', 'Beds', 280000, null, 'Sturdy upholstered bed frame with headboard.', null, 'Wood, fabric', null, 'Queen, King', true, true, false],
            ['Bedside Drawer Set', 'Beds', 65000, 80000, 'Pair of bedside drawers.', '45cm x 40cm x 50cm', 'Engineered wood', null, null, false, true, true],
            ['6-Seater Dining Set', 'Dining', 410000, null, 'Dining table with six cushioned chairs.', '180cm x 90cm table', 'Wood, fabric', 'Walnut', null, true, false, false],
            ['3-Door Wardrobe', 'Wardrobes', 240000, 290000, 'Roomy wardrobe with hanging space and shelves.', '150cm x 55cm x 200cm', 'Engineered wood', 'White, Oak', null, false, true, true],
            ['Executive Office Desk', 'Office', 185000, null, 'Large desk with drawers.', '160cm x 80cm', 'Wood veneer', null, null, true, false, false],
            ['Ergonomic Office Chair', 'Office', 95000, null, 'Adjustable chair with lumbar support.', null, 'Mesh, metal', 'Black', null, false, true, false],
            ['Modern TV Stand', 'TV Stands', 120000, 145000, 'TV console with storage drawers.', '160cm x 40cm x 50cm', 'Engineered wood', 'Oak, Black', null, false, false, true],
            ['Round Centre Table', 'Centre Tables', 55000, null, 'Round coffee table with metal legs.', '80cm diameter', 'Wood, metal', null, null, false, true, false],
            ['Outdoor Lounge Set', 'Outdoor', 330000, null, 'Weather-resistant outdoor seating set.', null, 'Rattan, aluminium', null, null, true, false, false],
            ['Storage Ottoman', 'Other', 45000, null, 'Padded ottoman with hidden storage.', '60cm x 40cm', 'Fabric', 'Grey, Blue', null, false, true, false],
        ];

        foreach ($items as [$name, $catPrefix, $price, $old, $desc, $dim, $mat, $colours, $sizes, $featured, $new, $sale]) {
            $categoryId = $cat($catPrefix);
            if (! $categoryId) continue;
            Product::firstOrCreate(['slug' => \Illuminate\Support\Str::slug($name)], [
                'category_id' => $categoryId, 'name' => $name, 'description' => $desc,
                'price' => $price, 'old_price' => $old, 'dimensions' => $dim, 'material' => $mat,
                'colours' => $colours, 'sizes' => $sizes, 'availability' => 'in_stock',
                'is_featured' => $featured, 'is_new' => $new, 'is_on_sale' => $sale && $old, 'is_active' => true,
            ]);
        }
    }
}
