<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([AdminSeeder::class, SettingsSeeder::class, CategorySeeder::class]);

        // Demo products use placeholder pictures and sample prices. Skip in production:
        //   SEED_DEMO_PRODUCTS=false
        if (filter_var(env('SEED_DEMO_PRODUCTS', true), FILTER_VALIDATE_BOOLEAN)) {
            $this->call(DemoProductSeeder::class);
        }
    }
}
