<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        $email = env('ADMIN_EMAIL', 'admin@example.com');
        if (User::where('email', $email)->exists()) return;

        $password = env('ADMIN_PASSWORD') ?: Str::password(14, symbols: false);

        $user = new User(['name' => 'Administrator', 'email' => $email, 'password' => Hash::make($password)]);
        $user->is_admin = true;
        $user->save();

        $this->command?->warn("Admin created: {$email} / {$password}  (change it after first login)");
    }
}
