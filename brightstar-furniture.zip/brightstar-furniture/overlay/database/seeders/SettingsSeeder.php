<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingsSeeder extends Seeder
{
    public function run(): void
    {
        $defaults = [
            'company_name' => 'BRIGHTSTAR GLOBAL FURNITURE',
            'company_description' => 'Stylish, comfortable and affordable furniture for homes and offices.',
            'phone' => '',
            'whatsapp' => '',          // set in Admin > Settings, e.g. 08012345678
            'email' => '',
            'address' => '',
            'business_hours' => 'Mon - Sat: 9:00 AM - 6:00 PM',
            'hero_title' => 'Quality Furniture for Every Home',
            'hero_subtitle' => 'Discover stylish, comfortable and affordable furniture designed to make your home and office beautiful.',
            'hero_btn1_text' => 'Shop Furniture',
            'hero_btn2_text' => 'Chat with Us on WhatsApp',
            'currency_symbol' => '₦',
            'payments_enabled' => '0',
            'delivery_fee' => '0',
            'delivery_info' => 'Delivery charges depend on your location and will be confirmed before dispatch.',
            'footer_text' => '',
            'seo_title' => 'BRIGHTSTAR GLOBAL FURNITURE | Quality Furniture in Nigeria',
            'seo_description' => 'Shop sofas, beds, dining sets, wardrobes, office furniture and more. Order easily on WhatsApp or pay online.',
            'about_title' => 'About BRIGHTSTAR GLOBAL FURNITURE',
            'about_body' => "BRIGHTSTAR GLOBAL FURNITURE supplies stylish and comfortable furniture for homes and offices.\n\nEdit this text from Admin > Settings to tell your story.",
            'about_values' => "Quality\nCustomer care\nHonest pricing",
            'privacy_policy' => "We collect only the information needed to process your orders and enquiries (name, phone, email, delivery address). We do not sell your information. Card payments are handled by our payment provider; we never store your card details.\n\nReplace this text with your final privacy policy.",
            'terms' => "By placing an order you agree that prices and availability are confirmed by us before dispatch, and that delivery charges depend on your location.\n\nReplace this text with your final terms and conditions.",
        ];

        foreach ($defaults as $k => $v) {
            Setting::firstOrCreate(['key' => $k], ['value' => $v]);
        }
        \Illuminate\Support\Facades\Cache::forget('settings.all');
    }
}
