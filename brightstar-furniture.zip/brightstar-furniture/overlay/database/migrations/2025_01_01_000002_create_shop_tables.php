<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('slug')->unique();
            $t->text('description')->nullable();
            $t->string('image')->nullable();
            $t->unsignedInteger('sort_order')->default(0);
            $t->boolean('is_active')->default(true);
            $t->timestamps();
            $t->index(['is_active', 'sort_order']);
        });

        Schema::create('products', function (Blueprint $t) {
            $t->id();
            $t->foreignId('category_id')->constrained()->restrictOnDelete();
            $t->string('name');
            $t->string('slug')->unique();
            $t->text('description')->nullable();
            $t->decimal('price', 12, 2);
            $t->decimal('old_price', 12, 2)->nullable();
            $t->string('dimensions')->nullable();
            $t->string('material')->nullable();
            $t->string('colours')->nullable();   // comma separated
            $t->string('sizes')->nullable();     // comma separated
            $t->string('availability', 20)->default('in_stock'); // in_stock|out_of_stock|made_to_order
            $t->boolean('is_featured')->default(false);
            $t->boolean('is_new')->default(false);
            $t->boolean('is_on_sale')->default(false);
            $t->boolean('is_active')->default(true);
            $t->boolean('track_stock')->default(false);
            $t->unsignedInteger('stock_qty')->default(0);
            $t->string('seo_title')->nullable();
            $t->string('seo_description', 300)->nullable();
            $t->timestamps();
            $t->index(['is_active', 'category_id']);
            $t->index(['is_active', 'is_featured']);
            $t->index(['is_active', 'is_on_sale']);
            $t->index('price');
        });

        Schema::create('product_images', function (Blueprint $t) {
            $t->id();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->string('path');
            $t->string('alt')->nullable();
            $t->unsignedInteger('sort_order')->default(0);
            $t->timestamps();
        });

        Schema::create('orders', function (Blueprint $t) {
            $t->id();
            $t->string('order_number')->unique();
            $t->string('public_token', 40)->unique();
            $t->string('customer_name');
            $t->string('phone', 30);
            $t->string('email')->nullable();
            $t->text('address');
            $t->text('notes')->nullable();
            $t->decimal('subtotal', 12, 2);
            $t->decimal('delivery_charge', 12, 2)->default(0);
            $t->decimal('total', 12, 2);
            $t->string('payment_method', 20);                     // whatsapp|paystack
            $t->string('payment_status', 20)->default('unpaid');  // unpaid|paid|failed|refunded
            $t->string('status', 30)->default('pending');
            $t->timestamps();
            $t->index('status');
            $t->index('payment_status');
            $t->index('created_at');
        });

        Schema::create('order_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('order_id')->constrained()->cascadeOnDelete();
            $t->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
            $t->string('product_name');        // snapshot
            $t->string('colour')->nullable();
            $t->string('size')->nullable();
            $t->decimal('unit_price', 12, 2);  // snapshot
            $t->unsignedInteger('quantity');
            $t->decimal('line_total', 12, 2);
            $t->timestamps();
        });

        Schema::create('payments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('order_id')->constrained()->cascadeOnDelete();
            $t->string('gateway', 20);         // paystack|manual
            $t->string('reference')->unique();
            $t->decimal('amount', 12, 2);
            $t->string('currency', 3)->default('NGN');
            $t->string('status', 20)->default('pending'); // pending|success|failed
            $t->json('gateway_response')->nullable();
            $t->timestamp('paid_at')->nullable();
            $t->timestamps();
            $t->index('status');
        });

        Schema::create('enquiries', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('email')->nullable();
            $t->string('phone', 30)->nullable();
            $t->text('message');
            $t->boolean('is_read')->default(false);
            $t->timestamps();
        });

        Schema::create('settings', function (Blueprint $t) {
            $t->id();
            $t->string('key')->unique();
            $t->longText('value')->nullable();
            $t->timestamps();
        });

        Schema::create('stock_movements', function (Blueprint $t) {
            $t->id();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->foreignId('order_id')->nullable()->constrained()->nullOnDelete();
            $t->integer('change');
            $t->string('reason');
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['stock_movements','settings','enquiries','payments','order_items','orders','product_images','products','categories'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
