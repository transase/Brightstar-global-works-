#!/usr/bin/env bash
# Usage: ./install.sh [target-directory]   (default: ./brightstar-app)
# Requires: PHP 8.2+ (with gd, pdo_mysql, mbstring), Composer, MySQL.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="${1:-brightstar-app}"

if [ ! -f "$APP/artisan" ]; then
  echo ">> Creating fresh Laravel project in $APP"
  composer create-project laravel/laravel "$APP"
fi

echo ">> Copying BRIGHTSTAR application files"
cp -R "$HERE/overlay/." "$APP/"
rm -f "$APP/public/robots.txt"   # served dynamically with the sitemap URL

cd "$APP"
if ! grep -q "BRIGHTSTAR" .env 2>/dev/null; then
  echo ">> Merging environment settings into .env (edit DB credentials before migrating)"
  grep -v '^\(APP_NAME\|APP_ENV\|APP_DEBUG\|APP_URL\|DB_\|SESSION_DRIVER\|CACHE_STORE\|QUEUE_CONNECTION\|MAIL_\)' .env > .env.tmp || true
  cat .env.tmp ".env.example.brightstar" > .env && rm .env.tmp
  php artisan key:generate --force
fi

echo ">> Linking storage"
php artisan storage:link || true

cat <<MSG

Done. Next steps:
  1. Edit .env  (database credentials, APP_URL, ADMIN_EMAIL, mail settings)
  2. php artisan migrate --seed
  3. php artisan serve        -> http://localhost:8000   (admin: /admin/login)
  4. php artisan test         -> run the automated tests
MSG
