<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use App\Services\Paystack;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\Support\MakesShop;
use Tests\TestCase;

class AdminTest extends TestCase
{
    use RefreshDatabase, MakesShop;

    public function test_guests_are_redirected_to_login(): void
    {
        foreach (['/admin', '/admin/products', '/admin/orders', '/admin/settings'] as $url) {
            $this->get($url)->assertRedirect('/admin/login');
        }
    }

    public function test_non_admin_users_are_forbidden(): void
    {
        $user = User::forceCreate(['name' => 'Cust', 'email' => 'c@test.com', 'password' => bcrypt('x'), 'is_admin' => false]);
        $this->actingAs($user)->get('/admin')->assertForbidden();
        $this->actingAs($user)->post('/admin/products', [])->assertForbidden();
    }

    public function test_admin_login_and_dashboard(): void
    {
        $this->makeAdmin();
        $this->post('/admin/login', ['email' => 'admin@test.com', 'password' => 'wrong'])->assertSessionHasErrors('email');
        $this->post('/admin/login', ['email' => 'admin@test.com', 'password' => 'Secret12345'])->assertRedirect('/admin');
        $this->get('/admin')->assertOk()->assertSee('Total products');
    }

    public function test_non_admin_cannot_log_in_to_admin(): void
    {
        User::forceCreate(['name' => 'Cust', 'email' => 'c@test.com', 'password' => bcrypt('Secret12345'), 'is_admin' => false]);
        $this->post('/admin/login', ['email' => 'c@test.com', 'password' => 'Secret12345'])->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_admin_can_create_category_and_product_with_images(): void
    {
        Storage::fake('public');
        $admin = $this->makeAdmin();

        $this->actingAs($admin)->post('/admin/categories', ['name' => 'Beds', 'sort_order' => 2, 'is_active' => 1])->assertRedirect();
        $cat = Category::where('slug', 'beds')->firstOrFail();

        $this->actingAs($admin)->post('/admin/products', [
            'name' => 'King Bed', 'category_id' => $cat->id, 'price' => 280000, 'old_price' => 320000,
            'availability' => 'in_stock', 'is_on_sale' => 1, 'is_active' => 1,
            'images' => [UploadedFile::fake()->image('a.jpg', 800, 600), UploadedFile::fake()->image('b.png', 800, 600)],
        ])->assertRedirect('/admin/products');

        $p = Product::with('images')->where('slug', 'king-bed')->firstOrFail();
        $this->assertTrue($p->is_on_sale);
        $this->assertCount(2, $p->images);
        foreach ($p->images as $img) Storage::disk('public')->assertExists($img->path);
    }

    public function test_product_validation_and_unsafe_uploads_are_rejected(): void
    {
        Storage::fake('public');
        $admin = $this->makeAdmin();
        $cat = $this->makeCategory();

        $this->actingAs($admin)->post('/admin/products', ['name' => '', 'price' => -5])
            ->assertSessionHasErrors(['name', 'category_id', 'price']);

        $this->actingAs($admin)->post('/admin/products', [
            'name' => 'Bad', 'category_id' => $cat->id, 'price' => 100, 'availability' => 'in_stock',
            'images' => [UploadedFile::fake()->create('shell.php', 10, 'application/x-php')],
        ])->assertSessionHasErrors('images.0');

        $this->actingAs($admin)->post('/admin/products', [
            'name' => 'Odd', 'category_id' => $cat->id, 'price' => 500, 'old_price' => 100, 'availability' => 'in_stock',
        ])->assertSessionHasErrors('old_price');

        $this->assertSame(0, Product::count());
    }

    public function test_category_with_products_cannot_be_deleted(): void
    {
        $admin = $this->makeAdmin();
        $p = $this->makeProduct();

        $this->actingAs($admin)->delete('/admin/categories/'.$p->category_id)->assertSessionHasErrors('category');
        $this->assertDatabaseHas('categories', ['id' => $p->category_id]);

        $empty = Category::create(['name' => 'Empty', 'slug' => 'empty']);
        $this->actingAs($admin)->delete('/admin/categories/'.$empty->id)->assertRedirect();
        $this->assertDatabaseMissing('categories', ['id' => $empty->id]);
    }

    public function test_deleting_a_product_keeps_existing_orders_intact(): void
    {
        $admin = $this->makeAdmin();
        $p = $this->makeProduct();
        $this->withSession($this->cartSession($p))->post('/checkout', $this->customer(['method' => 'whatsapp']));

        $this->actingAs($admin)->delete('/admin/products/'.$p->id)->assertRedirect();

        $item = Order::firstOrFail()->items()->firstOrFail();
        $this->assertNull($item->product_id);
        $this->assertSame('Modern Sofa', $item->product_name);
    }

    public function test_admin_updates_order_status_and_cancel_restores_stock(): void
    {
        $admin = $this->makeAdmin();
        $p = $this->makeProduct(['track_stock' => true, 'stock_qty' => 5]);
        $this->withSession($this->cartSession($p, 2))->post('/checkout', $this->customer(['method' => 'whatsapp']));
        $order = Order::firstOrFail();
        $this->assertSame(3, $p->fresh()->stock_qty);

        $this->actingAs($admin)->patch("/admin/orders/{$order->id}/status", ['status' => 'confirmed'])->assertRedirect();
        $this->assertSame('confirmed', $order->fresh()->status);

        $this->actingAs($admin)->patch("/admin/orders/{$order->id}/status", ['status' => 'cancelled']);
        $this->assertSame('cancelled', $order->fresh()->status);
        $this->assertSame(5, $p->fresh()->stock_qty);

        // Cancelling twice must not restock twice; reopening is refused.
        $this->actingAs($admin)->patch("/admin/orders/{$order->id}/status", ['status' => 'cancelled']);
        $this->actingAs($admin)->patch("/admin/orders/{$order->id}/status", ['status' => 'pending'])->assertSessionHasErrors('status');
        $this->assertSame(5, $p->fresh()->stock_qty);

        $this->actingAs($admin)->patch("/admin/orders/{$order->id}/status", ['status' => 'bogus'])->assertSessionHasErrors('status');
    }

    public function test_payment_status_is_separate_and_manual_paid_counts_as_sale(): void
    {
        $admin = $this->makeAdmin();
        $p = $this->makeProduct();
        $this->withSession($this->cartSession($p))->post('/checkout', $this->customer(['method' => 'whatsapp']));
        $order = Order::firstOrFail();

        $this->actingAs($admin)->get('/admin')->assertSee('₦0');

        $this->actingAs($admin)->patch("/admin/orders/{$order->id}/payment", ['payment_status' => 'paid'])->assertRedirect();
        $order->refresh();
        $this->assertSame('paid', $order->payment_status);
        $this->assertSame('pending', $order->status); // untouched

        $this->actingAs($admin)->get('/admin')->assertSee('₦350,000');
    }

    public function test_order_search_filter_and_receipt(): void
    {
        $admin = $this->makeAdmin();
        $p = $this->makeProduct();
        $this->withSession($this->cartSession($p))->post('/checkout', $this->customer(['method' => 'whatsapp']));
        $order = Order::firstOrFail();

        $this->actingAs($admin)->get('/admin/orders?q=Ada')->assertSee($order->order_number);
        $this->actingAs($admin)->get('/admin/orders?q=Nobody')->assertDontSee($order->order_number);
        $this->actingAs($admin)->get('/admin/orders?status=delivered')->assertDontSee($order->order_number);
        $this->actingAs($admin)->get("/admin/orders/{$order->id}/receipt")->assertOk()->assertSee('Receipt');
    }

    public function test_paystack_secret_is_stored_encrypted_and_not_exposed(): void
    {
        $admin = $this->makeAdmin();

        $this->actingAs($admin)->put('/admin/settings', [
            'company_name' => 'BRIGHTSTAR GLOBAL FURNITURE', 'payments_enabled' => 1,
            'paystack_public_key' => 'pk_test_abc', 'paystack_secret_key' => 'sk_test_supersecret',
        ])->assertRedirect();

        $this->assertNotSame('sk_test_supersecret', Setting::where('key', 'paystack_secret_key')->value('value'));
        $this->assertSame('sk_test_supersecret', Paystack::secretKey());
        $this->assertTrue(Paystack::enabled());

        // Public site never contains the secret; admin form never echoes it.
        $this->get('/')->assertDontSee('sk_test_supersecret');
        $this->actingAs($admin)->get('/admin/settings')->assertDontSee('sk_test_supersecret');

        // Blank secret on re-save keeps the existing one; unticking disables payments.
        $this->actingAs($admin)->put('/admin/settings', ['company_name' => 'BRIGHTSTAR GLOBAL FURNITURE']);
        $this->assertSame('sk_test_supersecret', Paystack::secretKey());
        $this->assertFalse(Paystack::enabled());
    }

    public function test_settings_drive_public_site_and_whatsapp_number(): void
    {
        $admin = $this->makeAdmin();
        $this->actingAs($admin)->put('/admin/settings', [
            'company_name' => 'BRIGHTSTAR GLOBAL FURNITURE', 'whatsapp' => '0801 234 5678',
            'hero_title' => 'Custom Headline', 'phone' => '+234 800 000 0000',
        ])->assertRedirect();

        $this->get('/')->assertSee('Custom Headline')->assertSee('wa.me/2348012345678', false);
        $this->get('/contact')->assertSee('+234 800 000 0000');
    }

    public function test_enquiry_is_stored_and_visible_to_admin(): void
    {
        $this->post('/contact', ['name' => 'Chidi', 'email' => 'chidi@example.com', 'message' => 'Do you deliver to Abuja?'])->assertSessionHas('success');
        $this->assertDatabaseHas('enquiries', ['name' => 'Chidi']);

        $this->actingAs($this->makeAdmin())->get('/admin/enquiries')->assertSee('Do you deliver to Abuja?');
    }

    public function test_enquiry_honeypot_discards_bots(): void
    {
        $this->post('/contact', ['name' => 'Bot', 'email' => 'b@x.com', 'message' => 'spam', 'website' => 'http://spam'])->assertSessionHas('success');
        $this->assertDatabaseCount('enquiries', 0);
    }
}
