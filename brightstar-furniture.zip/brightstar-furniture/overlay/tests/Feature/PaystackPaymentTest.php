<?php

namespace Tests\Feature;

use App\Models\Order;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Tests\Support\MakesShop;
use Tests\TestCase;

class PaystackPaymentTest extends TestCase
{
    use RefreshDatabase, MakesShop;

    private function fakeVerify(array $data, int $http = 200): void
    {
        Http::fake(['api.paystack.co/transaction/verify/*' => Http::response(['status' => true, 'data' => $data], $http)]);
    }

    public function test_checkout_creates_pending_order_and_redirects_to_paystack(): void
    {
        $this->enablePaystack();
        $p = $this->makeProduct();
        Http::fake(['api.paystack.co/transaction/initialize' => Http::response([
            'status' => true, 'data' => ['authorization_url' => 'https://checkout.paystack.com/abc123', 'reference' => 'x'],
        ])]);

        $this->withSession($this->cartSession($p))->post('/checkout', $this->customer(['method' => 'paystack']))
            ->assertRedirect('https://checkout.paystack.com/abc123');

        $order = Order::firstOrFail();
        $this->assertSame('unpaid', $order->payment_status);
        $this->assertDatabaseHas('payments', ['order_id' => $order->id, 'status' => 'pending', 'amount' => 350000]);

        Http::assertSent(fn ($r) => $r['amount'] === 35000000 && $r['currency'] === 'NGN');
    }

    public function test_failed_initialisation_cancels_order(): void
    {
        $this->enablePaystack();
        $p = $this->makeProduct(['track_stock' => true, 'stock_qty' => 4]);
        Http::fake(['api.paystack.co/transaction/initialize' => Http::response(['status' => false], 500)]);

        $this->withSession($this->cartSession($p))->post('/checkout', $this->customer(['method' => 'paystack']))
            ->assertSessionHasErrors('method');

        $this->assertSame('cancelled', Order::firstOrFail()->status);
        $this->assertSame(4, $p->fresh()->stock_qty); // stock returned
    }

    public function test_callback_marks_paid_only_after_server_side_verification(): void
    {
        $this->enablePaystack();
        $payment = $this->pendingPayment();
        $this->fakeVerify(['status' => 'success', 'amount' => 35000000, 'currency' => 'NGN']);

        $this->get('/paystack/callback?reference=REF123')->assertRedirect('/order/'.$payment->order->public_token);

        $this->assertSame('paid', $payment->order->fresh()->payment_status);
        $this->assertSame('success', $payment->fresh()->status);
        Http::assertSentCount(1);
    }

    public function test_browser_redirect_with_abandoned_payment_never_marks_paid(): void
    {
        $this->enablePaystack();
        $payment = $this->pendingPayment();
        $this->fakeVerify(['status' => 'abandoned', 'amount' => 0, 'currency' => 'NGN']);

        $this->get('/paystack/callback?reference=REF123&trxref=REF123')->assertRedirect();

        $this->assertSame('unpaid', $payment->order->fresh()->payment_status);
        $this->assertSame('pending', $payment->fresh()->status); // customer may still complete it
    }

    public function test_unreachable_gateway_never_marks_paid(): void
    {
        $this->enablePaystack();
        $payment = $this->pendingPayment();
        $this->fakeVerify([], 500);

        $this->get('/paystack/callback?reference=REF123')->assertRedirect();

        $this->assertSame('unpaid', $payment->order->fresh()->payment_status);
    }

    public function test_failed_payment_is_recorded_as_failed(): void
    {
        $this->enablePaystack();
        $payment = $this->pendingPayment();
        $this->fakeVerify(['status' => 'failed', 'amount' => 35000000, 'currency' => 'NGN']);

        $this->get('/paystack/callback?reference=REF123');

        $this->assertSame('failed', $payment->fresh()->status);
        $this->assertSame('failed', $payment->order->fresh()->payment_status);
    }

    public function test_amount_mismatch_is_rejected(): void
    {
        $this->enablePaystack();
        $payment = $this->pendingPayment();
        $this->fakeVerify(['status' => 'success', 'amount' => 100, 'currency' => 'NGN']);

        $this->get('/paystack/callback?reference=REF123');

        $this->assertSame('unpaid', $payment->order->fresh()->payment_status);
        $this->assertSame('pending', $payment->fresh()->status);
    }

    public function test_unknown_reference_is_404(): void
    {
        $this->enablePaystack();
        $this->get('/paystack/callback?reference=NOPE')->assertNotFound();
    }

    public function test_webhook_rejects_bad_signature(): void
    {
        $this->enablePaystack();
        $payment = $this->pendingPayment();
        $body = json_encode(['event' => 'charge.success', 'data' => ['reference' => 'REF123']]);

        $this->call('POST', '/paystack/webhook', [], [], [], ['CONTENT_TYPE' => 'application/json', 'HTTP_X_PAYSTACK_SIGNATURE' => 'bad'], $body)
            ->assertStatus(401);
        $this->assertSame('unpaid', $payment->order->fresh()->payment_status);
    }

    public function test_webhook_with_valid_signature_marks_paid_and_is_idempotent(): void
    {
        $this->enablePaystack();
        $payment = $this->pendingPayment();
        $this->fakeVerify(['status' => 'success', 'amount' => 35000000, 'currency' => 'NGN']);

        $body = json_encode(['event' => 'charge.success', 'data' => ['reference' => 'REF123']]);
        $sig = hash_hmac('sha512', $body, 'sk_test_secret');
        $server = ['CONTENT_TYPE' => 'application/json', 'HTTP_X_PAYSTACK_SIGNATURE' => $sig];

        $this->call('POST', '/paystack/webhook', [], [], [], $server, $body)->assertOk();
        $this->call('POST', '/paystack/webhook', [], [], [], $server, $body)->assertOk();

        $this->assertSame('paid', $payment->order->fresh()->payment_status);
        $this->assertSame(1, \App\Models\Payment::where('status', 'success')->count());
    }
}
