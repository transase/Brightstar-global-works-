<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\Setting;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Support\MakesShop;
use Tests\TestCase;

class OrderingTest extends TestCase
{
    use RefreshDatabase, MakesShop;

    public function test_storefront_pages_load(): void
    {
        $p = $this->makeProduct(['is_featured' => true]);
        $this->get('/')->assertOk()->assertSee('Modern Sofa');
        $this->get('/shop')->assertOk()->assertSee('Modern Sofa');
        $this->get('/product/'.$p->slug)->assertOk()->assertSee('₦350,000');
        $this->get('/category/sofas')->assertOk();
        $this->get('/about-us')->assertOk();
        $this->get('/contact')->assertOk();
        $this->get('/sitemap.xml')->assertOk()->assertSee('modern-sofa');
        $this->get('/robots.txt')->assertOk()->assertSee('Sitemap:');
    }

    public function test_inactive_product_is_not_public(): void
    {
        $p = $this->makeProduct(['is_active' => false]);
        $this->get('/product/'.$p->slug)->assertNotFound();
    }

    public function test_shop_filters_and_sorting(): void
    {
        $cat = $this->makeCategory();
        $this->makeProduct(['category_id' => $cat->id, 'name' => 'Cheap Stool', 'slug' => 'cheap-stool', 'price' => 10000]);
        $this->makeProduct(['category_id' => $cat->id, 'name' => 'Grand Sofa', 'slug' => 'grand-sofa', 'price' => 900000]);

        $this->get('/shop?q=stool')->assertSee('Cheap Stool')->assertDontSee('Grand Sofa');
        $this->get('/shop?min_price=500000')->assertSee('Grand Sofa')->assertDontSee('Cheap Stool');
        $this->get('/shop?sort=price_desc')->assertSeeInOrder(['Grand Sofa', 'Cheap Stool']);
    }

    public function test_add_to_cart_and_whatsapp_order_creates_order_and_redirects(): void
    {
        Setting::put('whatsapp', '08012345678');
        $p = $this->makeProduct();

        $this->post('/cart/add', ['product_id' => $p->id, 'qty' => 2])->assertRedirect('/cart');

        $res = $this->post('/checkout', $this->customer(['method' => 'whatsapp']));

        $loc = $res->headers->get('Location');
        $this->assertStringStartsWith('https://wa.me/2348012345678?text=', $loc);
        $text = rawurldecode(substr($loc, strpos($loc, 'text=') + 5));
        $this->assertStringContainsString('Product: Modern Sofa', $text);
        $this->assertStringContainsString('Quantity: 2', $text);
        $this->assertStringContainsString('Total: ₦700,000', $text);

        $order = Order::with('items')->firstOrFail();
        $this->assertEquals(700000, $order->total);
        $this->assertSame('whatsapp', $order->payment_method);
        $this->assertSame('unpaid', $order->payment_status);
        $this->assertSame('pending', $order->status);
        $this->assertSame(0, app(\App\Services\Cart::class)->count());
    }

    public function test_order_items_are_snapshots(): void
    {
        $p = $this->makeProduct();
        $this->withSession($this->cartSession($p))->post('/checkout', $this->customer(['method' => 'whatsapp']));

        $p->update(['name' => 'Renamed', 'price' => 1]);

        $item = Order::firstOrFail()->items()->firstOrFail();
        $this->assertSame('Modern Sofa', $item->product_name);
        $this->assertEquals(350000, $item->unit_price);
    }

    public function test_checkout_validates_customer_details(): void
    {
        $p = $this->makeProduct();
        $this->withSession($this->cartSession($p))
            ->post('/checkout', ['method' => 'whatsapp'])
            ->assertSessionHasErrors(['customer_name', 'phone', 'address']);
        $this->assertSame(0, Order::count());
    }

    public function test_empty_cart_cannot_checkout(): void
    {
        $this->post('/checkout', $this->customer(['method' => 'whatsapp']))->assertSessionHasErrors('cart');
        $this->assertSame(0, Order::count());
    }

    public function test_cannot_order_more_than_tracked_stock_and_stock_is_reduced(): void
    {
        $p = $this->makeProduct(['track_stock' => true, 'stock_qty' => 3]);

        $this->withSession($this->cartSession($p, 5))->post('/checkout', $this->customer(['method' => 'whatsapp']))
            ->assertSessionHasErrors('cart');
        $this->assertSame(0, Order::count());

        $this->withSession($this->cartSession($p, 2))->post('/checkout', $this->customer(['method' => 'whatsapp']));
        $this->assertSame(1, $p->fresh()->stock_qty);
        $this->assertDatabaseHas('stock_movements', ['product_id' => $p->id, 'change' => -2]);
    }

    public function test_out_of_stock_product_cannot_be_added(): void
    {
        $p = $this->makeProduct(['availability' => 'out_of_stock']);
        $this->post('/cart/add', ['product_id' => $p->id, 'qty' => 1])->assertSessionHasErrors('cart');
    }

    public function test_online_payment_is_blocked_when_disabled(): void
    {
        $p = $this->makeProduct();
        $this->withSession($this->cartSession($p))
            ->post('/checkout', $this->customer(['method' => 'paystack']))
            ->assertSessionHasErrors('method');
        $this->assertSame(0, Order::count());
    }

    public function test_online_payment_requires_email(): void
    {
        $this->enablePaystack();
        $p = $this->makeProduct();
        $this->withSession($this->cartSession($p))
            ->post('/checkout', $this->customer(['method' => 'paystack', 'email' => '']))
            ->assertSessionHasErrors('email');
    }

    public function test_product_page_hides_blank_specs_and_shows_provided_ones(): void
    {
        $p = $this->makeProduct(['material' => 'Teak']);
        $this->get('/product/'.$p->slug)->assertSee('Material')->assertSee('Teak')->assertDontSee('Dimensions');
    }
}
