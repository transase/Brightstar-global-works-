<?php

namespace Tests\Support;

use App\Models\Category;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use App\Services\Cart;
use Illuminate\Support\Facades\Crypt;

trait MakesShop
{
    protected function makeAdmin(): User
    {
        return User::forceCreate(['name' => 'Admin', 'email' => 'admin@test.com', 'password' => bcrypt('Secret12345'), 'is_admin' => true]);
    }

    protected function makeCategory(array $o = []): Category
    {
        return Category::create($o + ['name' => 'Sofas', 'slug' => 'sofas', 'is_active' => true]);
    }

    protected function makeProduct(array $o = []): Product
    {
        $cat = $o['category_id'] ?? $this->makeCategory()->id;
        unset($o['category_id']);
        return Product::create($o + [
            'category_id' => $cat, 'name' => 'Modern Sofa', 'slug' => 'modern-sofa',
            'price' => 350000, 'availability' => 'in_stock', 'is_active' => true,
        ]);
    }

    /** Session payload holding $qty of $product. */
    protected function cartSession(Product $p, int $qty = 1): array
    {
        return ['cart' => [Cart::lineKey($p->id, null, null) => ['product_id' => $p->id, 'qty' => $qty, 'colour' => null, 'size' => null]]];
    }

    protected function customer(array $o = []): array
    {
        return $o + ['customer_name' => 'Ada Obi', 'phone' => '08031234567', 'email' => 'ada@example.com', 'address' => '12 Allen Ave, Ikeja, Lagos'];
    }

    protected function enablePaystack(): void
    {
        Setting::putMany(['payments_enabled' => '1', 'paystack_secret_key' => Crypt::encryptString('sk_test_secret')]);
    }

    protected function pendingPayment(float $total = 350000): Payment
    {
        $order = Order::create([
            'order_number' => 'BSG-TEST-0001', 'public_token' => str_repeat('a', 40), 'customer_name' => 'Ada', 'phone' => '0803',
            'address' => 'Lagos', 'subtotal' => $total, 'delivery_charge' => 0, 'total' => $total,
            'payment_method' => 'paystack', 'payment_status' => 'unpaid', 'status' => 'pending',
        ]);
        return Payment::create(['order_id' => $order->id, 'gateway' => 'paystack', 'reference' => 'REF123', 'amount' => $total, 'currency' => 'NGN', 'status' => 'pending']);
    }
}
