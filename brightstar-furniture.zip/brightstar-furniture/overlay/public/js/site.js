// Product gallery thumbnails
document.querySelectorAll('[data-thumb]').forEach(function (t) {
  t.addEventListener('click', function () {
    var main = document.getElementById('gallery-main');
    if (main) { main.src = t.dataset.thumb; main.alt = t.alt; }
    document.querySelectorAll('[data-thumb]').forEach(function (x) { x.classList.remove('active'); });
    t.classList.add('active');
  });
});

// Product page: keep the WhatsApp link in sync with quantity / colour / size
(function () {
  var btn = document.getElementById('wa-product-btn');
  if (!btn) return;
  var qty = document.getElementById('qty');
  var fmt = function (n) { return btn.dataset.symbol + Number(n).toLocaleString('en-NG', { maximumFractionDigits: 2 }); };
  function build() {
    var q = Math.max(1, parseInt(qty ? qty.value : 1, 10) || 1);
    var unit = parseFloat(btn.dataset.price);
    var colour = document.querySelector('[name=colour]:checked, select[name=colour]');
    var size = document.querySelector('[name=size]:checked, select[name=size]');
    var m = 'Hello ' + btn.dataset.company + ', I would like to order the following item:\n\n' +
      'Product: ' + btn.dataset.name + '\n' +
      (colour && colour.value ? 'Colour: ' + colour.value + '\n' : '') +
      (size && size.value ? 'Size: ' + size.value + '\n' : '') +
      'Quantity: ' + q + '\nPrice: ' + fmt(unit) + '\n\nTotal: ' + fmt(unit * q) +
      '\n\nPlease confirm availability, delivery charges and payment details.';
    btn.href = btn.dataset.base + '?text=' + encodeURIComponent(m);
  }
  document.querySelectorAll('#qty, [name=colour], [name=size]').forEach(function (el) {
    el.addEventListener('input', build); el.addEventListener('change', build);
  });
  build();
})();
